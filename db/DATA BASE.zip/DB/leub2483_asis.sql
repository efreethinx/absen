-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 26, 2024 at 09:09 AM
-- Server version: 10.3.39-MariaDB-cll-lve
-- PHP Version: 8.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leub2483_asis`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `tentang` text DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telpon` varchar(25) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `youtube` varchar(100) DEFAULT NULL,
  `google` varchar(100) DEFAULT NULL,
  `gambar` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `nama`, `tentang`, `alamat`, `telpon`, `email`, `facebook`, `twitter`, `youtube`, `google`, `gambar`) VALUES
(1, 'Kids Life', 'Happy Kids Life comes with powerful theme options, which empowers you to quickly and easily build incredible store.', '4318 Mansion House, Greenland \r\nUnited States', '(000) 233 - 3236', 'kontak@perlubantuan.com', 'https://www.facebook.com/', 'https://twitter.com/', 'https://youtube.com/', 'https://google.com/', 'ddf3b76bf908fb08a2ff8757236ed12a.png');

-- --------------------------------------------------------

--
-- Table structure for table `absen`
--

CREATE TABLE `absen` (
  `id_absen` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_tahun_ajaran` int(11) DEFAULT NULL,
  `keterangan` enum('SAKIT','IZIN','ALPA') DEFAULT NULL,
  `alasan` varchar(100) DEFAULT NULL,
  `id_guru` int(11) DEFAULT NULL,
  `tanggal_absen` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `agenda`
--

CREATE TABLE `agenda` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `tgl_mulai` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `agenda`
--

INSERT INTO `agenda` (`id`, `judul`, `keterangan`, `icon`, `gambar`, `tgl_mulai`) VALUES
(7, 'English Summer Camp', 'Nam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....', 'fa fa-glass', '8c6d515af3a9b9141ef9d3d32e93fdee.jpg', '2016-05-01'),
(8, 'Sports Camp', 'English Summer Camp\r\nNam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....\r\nDrawing & Painting\r\nNam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....\r\nSwimming Camp\r\nNam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....\r\nSports Camp\r\nNam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....', 'fa fa-tachometer', '8625a6cfd405fe576f42b94db12ad100.jpg', '0000-00-00'),
(9, 'Drawing & Painting', 'Nam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....', 'fa fa-pencil', 'c1f9de3cee60042a796d90f63bce9a6a.jpg', '0000-00-00'),
(10, 'Swimming Camp', 'Nam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....', 'fa fa-bullseye', '2d446d19d367c776110b5120226a03f6.jpg', '0000-00-00'),
(11, 'Personalizing', 'Nam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....', 'fa fa-magic', 'af1acac30f709473b2bc93d7410fba75.jpg', '0000-00-00'),
(12, 'Sing & Dance', 'Nam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, inst tibulum nisl ligula....', 'fa fa-music', 'da415da6aa86552768d63876fa1225c7.jpg', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `agenda_display`
--

CREATE TABLE `agenda_display` (
  `id_agenda` int(11) NOT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `nama_agenda` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `agenda_display`
--

INSERT INTO `agenda_display` (`id_agenda`, `tanggal_mulai`, `tanggal_selesai`, `nama_agenda`) VALUES
(1, '2021-06-03', '2021-06-03', 'Rapat PPDB'),
(2, '2021-06-03', '2021-06-03', 'Rapat Kelulusan 2020/2021');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `aktif` enum('Y','N') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `keterangan`, `url`, `gambar`, `aktif`) VALUES
(3, 'sgsgx', 'sdgsgc', 'af406bf6c044f54e074b6b094b69c26f.png', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `barangsita_siswa`
--

CREATE TABLE `barangsita_siswa` (
  `id_barangsita_siswa` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `keterangan_sita` varchar(200) DEFAULT NULL,
  `tanggal_sita` date DEFAULT NULL,
  `tahun_ajaran` varchar(10) DEFAULT NULL,
  `id_penginput` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `barangsita_siswa`
--

INSERT INTO `barangsita_siswa` (`id_barangsita_siswa`, `id_siswa`, `id_kelas`, `keterangan_sita`, `tanggal_sita`, `tahun_ajaran`, `id_penginput`) VALUES
(1, 2, 10, 'Smartphone', '2021-08-20', '2020/2021', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bukutamu`
--

CREATE TABLE `bukutamu` (
  `id_tamu` int(11) NOT NULL,
  `nama_tamu` varchar(100) DEFAULT NULL,
  `asal` varchar(250) DEFAULT NULL,
  `alamat` varchar(250) DEFAULT NULL,
  `keperluan` varchar(250) DEFAULT NULL,
  `no_telepon` varchar(15) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bukutamu`
--

INSERT INTO `bukutamu` (`id_tamu`, `nama_tamu`, `asal`, `alamat`, `keperluan`, `no_telepon`, `tanggal`) VALUES
(0, 'Agih Agiana', 'SMKN 1 Japara', 'Japara', 'Koordinasi', '-', '2022-04-07 03:45:45'),
(0, 'Dwiyanuar', 'Perum. Bumi Gandamekar', 'Cigandamekar', 'Membagikan brosur perumahan', '', '2022-04-07 03:51:34'),
(0, 'asep', 'lmd', 'Blok Kamis', 'monitoring', '2121', '2022-05-23 01:57:54');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_akademik`
--

CREATE TABLE `calendar_akademik` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `calendar_akademik`
--

INSERT INTO `calendar_akademik` (`id`, `title`, `start`, `end`, `year`) VALUES
(1, 'Rapat', '2020-04-02', '2020-04-02', '2020');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_arsip`
--

CREATE TABLE `calendar_arsip` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `calendar_keuangan`
--

CREATE TABLE `calendar_keuangan` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `calendar_perpustakaan`
--

CREATE TABLE `calendar_perpustakaan` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `calendar_poinpelanggaran`
--

CREATE TABLE `calendar_poinpelanggaran` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `calendar_poinpelanggaran`
--

INSERT INTO `calendar_poinpelanggaran` (`id`, `title`, `start`, `end`, `year`) VALUES
(2, 'sielvi febriana, tengku anggun, vicky, wahyu dan farisya dian terlambat mengumpulkan handphone', '2019-08-01', '2019-08-01', '2019'),
(3, 'Adenia izin pulang sekolah karena radangnya kambuh', '2019-08-13', '2019-08-13', '2019'),
(4, 'razia atribut', '2019-08-14', '2019-08-14', '2019'),
(5, 'pengecekan atribut sekolah setelah apel', '2019-08-26', '2019-08-26', '2019'),
(6, 'LIBUR', '2020-04-07', '2020-04-07', '2020');

-- --------------------------------------------------------

--
-- Table structure for table `das`
--

CREATE TABLE `das` (
  `id_das` int(11) NOT NULL,
  `id_das_kategori` int(11) NOT NULL,
  `kegiatan` text NOT NULL,
  `total` double DEFAULT NULL,
  `saldo` double DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` char(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `das_bendahara`
--

CREATE TABLE `das_bendahara` (
  `id_das_bendahara` int(11) NOT NULL,
  `id_das_kategori` int(11) DEFAULT NULL,
  `kegiatan` text DEFAULT NULL,
  `total` double DEFAULT NULL,
  `saldo` double DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` char(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `das_kategori`
--

CREATE TABLE `das_kategori` (
  `id_das_kategori` int(11) NOT NULL,
  `jenis_dana` varchar(50) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `dana` double DEFAULT NULL,
  `sisa_dana` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `das_sisa`
--

CREATE TABLE `das_sisa` (
  `id_das_sisa` int(11) NOT NULL,
  `jenis_dana` text DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `dana` double DEFAULT NULL,
  `sisa_dana` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `das_sisa_output`
--

CREATE TABLE `das_sisa_output` (
  `id_das_sisa_output` int(11) NOT NULL,
  `id_das_sisa` int(11) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `ada_nota` char(1) NOT NULL DEFAULT '0',
  `ada_bku` char(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Triggers `das_sisa_output`
--
DELIMITER $$
CREATE TRIGGER `das_sisa_delete` AFTER DELETE ON `das_sisa_output` FOR EACH ROW BEGIN
	UPDATE das_sisa SET sisa_dana = sisa_dana + OLD.jumlah WHERE id_das_sisa = OLD.id_das_sisa;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `das_sisa_insert` AFTER INSERT ON `das_sisa_output` FOR EACH ROW BEGIN
	UPDATE das_sisa SET sisa_dana = sisa_dana - NEW.jumlah WHERE id_das_sisa = NEW.id_das_sisa;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `das_sumber_dana`
--

CREATE TABLE `das_sumber_dana` (
  `id_das_sumber_dana` int(11) NOT NULL,
  `jenis_dana_masuk` varchar(100) DEFAULT NULL,
  `jumlah_dana` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `das_user`
--

CREATE TABLE `das_user` (
  `id_das_user` int(11) NOT NULL,
  `id_das` int(11) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `total_terima` double DEFAULT NULL,
  `sisa_saldo` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `no_das` varchar(25) NOT NULL,
  `status_das_user` char(1) NOT NULL DEFAULT '0',
  `open` char(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `das_user_bendahara`
--

CREATE TABLE `das_user_bendahara` (
  `id_das_user_bendahara` int(11) NOT NULL,
  `id_das_bendahara` int(11) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `total_terima` double DEFAULT NULL,
  `sisa_saldo` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `no_das` varchar(25) DEFAULT NULL,
  `status_das_user` char(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `das_user_bendahara_output`
--

CREATE TABLE `das_user_bendahara_output` (
  `id_das_user_bendahara_output` int(11) NOT NULL,
  `id_das_user_bendahara` int(11) DEFAULT NULL,
  `jenis_das` varchar(15) DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `ada_nota` char(1) DEFAULT '0',
  `ada_bku` char(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Triggers `das_user_bendahara_output`
--
DELIMITER $$
CREATE TRIGGER `das_bendahara_delete` AFTER DELETE ON `das_user_bendahara_output` FOR EACH ROW BEGIN
UPDATE das_user_bendahara SET sisa_saldo = sisa_saldo + OLD.jumlah WHERE id_das_user_bendahara = OLD.id_das_user_bendahara;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `das_bendahara_insert` AFTER INSERT ON `das_user_bendahara_output` FOR EACH ROW BEGIN
UPDATE das_user_bendahara SET sisa_saldo = sisa_saldo - NEW.jumlah WHERE id_das_user_bendahara = NEW.id_das_user_bendahara;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `das_user_output`
--

CREATE TABLE `das_user_output` (
  `id_das_user_output` int(11) NOT NULL,
  `id_das_user` int(11) DEFAULT NULL,
  `jenis_das` varchar(50) NOT NULL,
  `jumlah` double DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `ada_nota` char(1) NOT NULL DEFAULT '0',
  `ada_bku` char(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Triggers `das_user_output`
--
DELIMITER $$
CREATE TRIGGER `das_saya_delete` AFTER DELETE ON `das_user_output` FOR EACH ROW BEGIN
	UPDATE das_user SET sisa_saldo = sisa_saldo + OLD.jumlah WHERE id_das_user = OLD.id_das_user;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `das_saya_insert` AFTER INSERT ON `das_user_output` FOR EACH ROW BEGIN
UPDATE das_user SET sisa_saldo = sisa_saldo - NEW.jumlah WHERE id_das_user = NEW.id_das_user;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `dokumen`
--

CREATE TABLE `dokumen` (
  `id_dokumen` int(11) NOT NULL,
  `id_jenis_dokumen` int(11) DEFAULT NULL,
  `id_lemari` int(11) NOT NULL,
  `id_ruangan` int(11) DEFAULT NULL,
  `id_rak` int(11) DEFAULT NULL,
  `id_box` int(11) DEFAULT NULL,
  `id_map` int(11) DEFAULT NULL,
  `id_urut` int(11) DEFAULT NULL,
  `nomor_dokumen` varchar(30) DEFAULT NULL,
  `nama_dokumen` varchar(150) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `file_dokumen` varchar(100) DEFAULT NULL,
  `tanggal_dokumen` date NOT NULL,
  `tanggal` date DEFAULT NULL,
  `tahun_ajaran` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dokumen`
--

INSERT INTO `dokumen` (`id_dokumen`, `id_jenis_dokumen`, `id_lemari`, `id_ruangan`, `id_rak`, `id_box`, `id_map`, `id_urut`, `nomor_dokumen`, `nama_dokumen`, `deskripsi`, `file_dokumen`, `tanggal_dokumen`, `tanggal`, `tahun_ajaran`) VALUES
(2, 2, 2, 3, 3, 1, 3, 1, '01', '01', '01', 'kelulusan_import_(1).xlsx', '2020-04-07', '2020-04-07', '2019/2020'),
(0, 1, 2, 3, 3, 2, 3, 1, '1111', 'surat starla', 'surat untuk starla', 'TIDAK_ADA_LAMPIRAN_DOKUMEN.docx', '2022-11-09', '2022-11-09', '2020/2021'),
(0, 0, 2, 3, 3, 1, 3, 1, '1', 'SELI RAHMAWATI', '10 AKL 3', 'SELI_RAHMAWATI_X_AKL_7_(SURAT_KETERANGAN_PINDAH_SEKOLAH).pdf', '2023-02-01', '2023-02-27', '2020/2021');

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `lokasi` varchar(250) DEFAULT NULL,
  `tgl_upload` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `tgl_posting` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `judul`, `keterangan`, `tgl_posting`) VALUES
(1, 'bisnis ajax', 'haha c', '2016-04-30'),
(2, 'hmm', 'haha', '2016-05-05'),
(3, 'ahah', 'dfhfd', '2016-05-20');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_pelajaran`
--

CREATE TABLE `jadwal_pelajaran` (
  `id_jadwal_pelajaran` int(11) NOT NULL,
  `id_guru` int(11) DEFAULT NULL,
  `id_mapel` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_tahun_ajaran` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `jadwal_pelajaran`
--

INSERT INTO `jadwal_pelajaran` (`id_jadwal_pelajaran`, `id_guru`, `id_mapel`, `id_kelas`, `id_tahun_ajaran`) VALUES
(1, 1, 4, 9, 3),
(2, 2, 5, 10, 3),
(3, 34, 5, 9, 3);

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_sholat`
--

CREATE TABLE `jadwal_sholat` (
  `id` int(11) NOT NULL,
  `subuh` varchar(5) DEFAULT NULL,
  `dzuhur` varchar(5) DEFAULT NULL,
  `ashar` varchar(5) DEFAULT NULL,
  `magrib` varchar(5) DEFAULT NULL,
  `isya` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `jadwal_sholat`
--

INSERT INTO `jadwal_sholat` (`id`, `subuh`, `dzuhur`, `ashar`, `magrib`, `isya`) VALUES
(1, '04:45', '12:15', '18:10', '18:10', '19:30');

-- --------------------------------------------------------

--
-- Table structure for table `katamutiara`
--

CREATE TABLE `katamutiara` (
  `id_katamutiara` int(11) NOT NULL,
  `kata` varchar(250) DEFAULT NULL,
  `penemu` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `katamutiara`
--

INSERT INTO `katamutiara` (`id_katamutiara`, `kata`, `penemu`) VALUES
(4, 'Sesungguhnya yang takut kepada Allah di antara hamba-hamba-Nya, hanyalah para ulama (orang-orang yang berilmu).', '(Q.S Fathir: 28)');

-- --------------------------------------------------------

--
-- Table structure for table `kategori_file`
--

CREATE TABLE `kategori_file` (
  `id_kategori` int(11) NOT NULL,
  `kategori_file` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kategori_file`
--

INSERT INTO `kategori_file` (`id_kategori`, `kategori_file`) VALUES
(10, 'Ebook'),
(11, 'Anggota');

-- --------------------------------------------------------

--
-- Table structure for table `kategori_post`
--

CREATE TABLE `kategori_post` (
  `id_kategori` int(11) NOT NULL,
  `kategori_post` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kategori_post`
--

INSERT INTO `kategori_post` (`id_kategori`, `kategori_post`) VALUES
(1, 'Play School'),
(2, 'Competition');

-- --------------------------------------------------------

--
-- Table structure for table `kelulusan_siswa`
--

CREATE TABLE `kelulusan_siswa` (
  `id_kelulusan` int(11) NOT NULL,
  `no_ujian` varchar(30) DEFAULT NULL,
  `nama_siswa` varchar(70) DEFAULT NULL,
  `jurusan` varchar(100) DEFAULT NULL,
  `nilai_indo` double DEFAULT NULL,
  `nilai_mtk` double DEFAULT NULL,
  `nilai_eng` double DEFAULT NULL,
  `nilai_kejurusan` double DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kelulusan_siswa`
--

INSERT INTO `kelulusan_siswa` (`id_kelulusan`, `no_ujian`, `nama_siswa`, `jurusan`, `nilai_indo`, `nilai_mtk`, `nilai_eng`, `nilai_kejurusan`, `status`) VALUES
(1, '2200530011500018', 'ADITYA FIRMANSYAH', '', 82.25, 77, 81.6, 78.8, 'LULUS'),
(2, '2200530011500027', 'AHMAD GHOZI', '', 77.5, 76.2, 77.2, 77, 'LULUS'),
(3, '2200530011500036', 'AHMAD SYAIFUL RIZAL', '', 75.25, 75.2, 75.8, 75.2, 'LULUS'),
(4, '2200530011500045', 'ANDRE EKA KURNIAWAN', '', 78.5, 76.4, 77.4, 77.2, 'LULUS'),
(5, '2200530011500054', 'HARI WAHYUDI', '', 82.5, 77.4, 79.2, 75.4, 'LULUS'),
(6, '2200530011500063', 'IHYA\' ULUMUDDIN', '', 85.75, 82.2, 73.6, 79.6, 'LULUS'),
(7, '2200530011500072', 'JAKFAR SODIQ', '', 78.5, 80, 80.4, 78.8, 'LULUS'),
(8, '2200530011500089', 'KHOIRUL ANAM             ', '', 84.75, 77.4, 81.2, 80.4, 'LULUS'),
(9, '2200530011500125', 'MOCHAMMAD RENDI IRVAN EFENDI', '', 78.5, 80, 80.4, 78.8, 'LULUS'),
(10, '2200530011500098', 'MUHAMAD IRFAN ARDIANSYAH', '', 77.5, 78, 79.4, 76.4, 'LULUS'),
(11, '2200530011500107', 'MUHAMMAD AFANDI', '', 79, 75.2, 74.6, 77, 'LULUS'),
(12, '2200530011500116', 'MUHAMMAD ARIEF SOBRI', '', 80, 77, 78.2, 76.2, 'LULUS'),
(13, '2200530011500134', 'MUHAMMAD RIZQI MAULANA', '', 75, 76.8, 78.2, 73.2, 'LULUS'),
(14, '2200530011500143', 'YUSRIL IHZA MAHENDRA', '', 93.75, 85, 85, 84.2, 'LULUS'),
(15, '2200530011500152', 'ALISIA FILDA SANJAYA', '', 81.4, 77, 81.6, 78.8, 'LULUS'),
(16, '2200530011500169', 'ANIS ARISKA', '', 82.8, 80, 80.2, 80.8, 'LULUS'),
(17, '2200530011500178', 'EKA MAULIDINA', '', 85.2, 81.2, 82.8, 83.6, 'LULUS'),
(18, '2200530011500187', 'FARDATUS SOLEHA', '', 78.4, 76.4, 77.4, 77.2, 'LULUS'),
(19, '2200530011500196', 'FITRIA', '', 83.8, 80.8, 82.2, 80.6, 'LULUS'),
(20, '2200530011500205', 'INKA NUR INDRIYANI', '', 84.2, 80.4, 79, 80.4, 'LULUS'),
(21, '2200530011500214', 'MILATUL HASANAH', '', 82.6, 81, 84.2, 81.2, 'LULUS'),
(22, '2200530011500223', 'MUMTAZA KHOIROTUL MAGFIROH', '', 83.4, 77.4, 81.2, 80.4, 'LULUS'),
(23, '2200530011500232', 'NOVIYATUL HALIMAH', '', 78.8, 75.2, 74.6, 77, 'LULUS'),
(24, '2200530011500249', 'NUR AFIFAH', '', 94.6, 89.2, 87.8, 88, 'LULUS'),
(25, '2200530011500258', 'NUR SAIDA', '', 83, 81.8, 81.2, 81.8, 'LULUS'),
(26, '2200530011500267', 'ROBIATUL MAHMUDA        ', '', 82.6, 80, 82.4, 80.4, 'LULUS'),
(27, '2200530011500276', 'SAFIATUN', '', 83.2, 81.8, 81.4, 80.8, 'LULUS'),
(28, '2200530011500285', 'SEPTIA DWI WAHYU NURSANTI', '', 85.2, 80.6, 80.4, 81, 'LULUS'),
(29, '2200530011500294', 'SITI AISYAH', '', 79.2, 81, 81.2, 81.6, 'LULUS'),
(30, '2200530011500303', 'SITI HOTIJAH', '', 85.75, 84.25, 85.5, 86.5, 'LULUS'),
(31, '2200530011500312', 'SITI NUR HASANAH', '', 81.4, 82.4, 84.2, 80.6, 'LULUS'),
(32, '2200530011500329', 'SOFIANA', '', 79.2, 81, 81.2, 81.6, 'LULUS'),
(33, '2200530011500338', 'SURYANI AGUSTIN', '', 85.75, 84.25, 85.5, 86.5, 'LULUS'),
(34, '2200530011500347', 'YULI KHOIRIYAH', '', 81.4, 82.4, 84.2, 80.6, 'LULUS'),
(35, '2200530011500356', 'ZAHROTUL JANNATI', '', 84.2, 82.4, 82.4, 80.8, 'LULUS'),
(36, '412093784378414', 'smp1', '999726262', 70, 95, 90, 85, 'LULUS'),
(37, '412389458495894518', 'smp2', '999723233', 30, 80, 98, 78, 'TIDAK LULUS');

-- --------------------------------------------------------

--
-- Table structure for table `log_login`
--

CREATE TABLE `log_login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `ipaddress` varchar(25) DEFAULT NULL,
  `hak_akses` varchar(55) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `log_login`
--

INSERT INTO `log_login` (`id`, `username`, `ipaddress`, `hak_akses`, `tanggal`) VALUES
(3, 'Admin Utama', '::1', 'admin', '2020-04-02 15:27:08'),
(4, 'Admin Utama', '::1', 'admin', '2020-04-07 06:42:01'),
(5, 'Admin Utama', '::1', 'admin', '2020-04-07 07:15:08'),
(6, 'Admin Utama', '::1', 'admin', '2020-04-07 07:26:47'),
(7, 'Admin Utama', '::1', 'admin', '2020-04-07 07:27:16'),
(8, 'Admin Utama', '::1', 'admin', '2020-04-07 09:01:35'),
(9, 'Admin Utama', '::1', 'admin', '2020-04-16 09:44:14'),
(10, 'Admin Utama', '::1', 'admin', '2020-04-16 09:47:19'),
(11, 'Admin Utama', '::1', 'admin', '2020-04-16 09:48:14'),
(12, 'Admin Utama', '::1', 'admin', '2020-04-16 09:54:04'),
(13, 'Admin Utama', '36.77.208.86', 'admin', '2020-04-16 17:21:19'),
(14, 'Admin Utama', '36.77.208.86', 'admin', '2020-04-16 18:34:14'),
(15, 'Admin Utama', '36.77.208.86', 'admin', '2020-04-16 18:49:29'),
(16, 'Admin Utama', '180.244.234.30', 'admin', '2020-04-17 05:08:42'),
(17, 'Admin Utama', '180.244.234.30', 'admin', '2020-04-17 05:08:58'),
(18, 'Admin Utama', '180.244.234.30', 'admin', '2020-04-17 07:07:17'),
(19, 'Admin Utama', '180.244.234.30', 'admin', '2020-04-17 07:18:32'),
(20, 'Admin Utama', '180.244.234.30', 'admin', '2020-04-17 17:42:53'),
(21, 'Admin Utama', '180.244.234.30', 'admin', '2020-04-17 23:38:31'),
(22, 'Admin Utama', '180.244.234.30', 'admin', '2020-04-18 08:30:20'),
(23, 'Admin Utama', '36.77.208.166', 'admin', '2020-04-22 17:35:41'),
(24, 'Admin Utama', '36.77.208.166', 'admin', '2020-04-22 17:52:23'),
(25, 'Admin Utama', '182.1.231.65', 'admin', '2020-04-23 13:45:23'),
(26, 'Admin Utama', '114.124.161.2', 'admin', '2020-04-24 03:36:01'),
(27, 'Admin Utama', '36.79.104.152', 'admin', '2020-05-03 04:58:13'),
(28, 'Admin Utama', '180.244.235.112', 'admin', '2020-05-16 02:44:00'),
(29, 'Admin Utama', '125.162.58.32', 'admin', '2020-05-16 03:33:07'),
(30, 'Admin Utama', '36.79.255.233', 'admin', '2020-05-16 04:30:56'),
(31, 'Admin Utama', '116.206.14.49', 'admin', '2020-05-16 04:33:04'),
(32, 'Admin Utama', '116.206.14.49', 'admin', '2020-05-16 04:39:10'),
(33, 'Admin Utama', '36.79.255.233', 'admin', '2020-05-16 04:40:50'),
(34, 'Admin Utama', '223.130.23.251', 'admin', '2020-05-16 04:57:28'),
(35, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 08:58:40'),
(36, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:03:16'),
(37, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:04:52'),
(38, 'nana', '111.94.41.40', 'guru', '2020-05-16 09:05:14'),
(39, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:05:43'),
(40, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:08:31'),
(41, 'Admin PPDB', '111.94.41.40', 'admin', '2020-05-16 09:09:26'),
(42, 'Kepses', '111.94.41.40', 'dasview', '2020-05-16 09:09:40'),
(43, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:11:40'),
(44, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:16:29'),
(45, 'Kepses', '111.94.41.40', 'dasview', '2020-05-16 09:52:03'),
(46, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:52:54'),
(47, 'Admin BK', '111.94.41.40', 'gurubk', '2020-05-16 09:53:36'),
(48, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:54:55'),
(49, 'Admin Utama', '180.244.235.112', 'admin', '2020-05-16 09:55:13'),
(50, 'Admin Utama', '180.244.235.112', 'admin', '2020-05-16 09:56:06'),
(51, 'aa', '111.94.41.40', 'gurubk', '2020-05-16 09:56:26'),
(52, 'Admin Utama', '180.244.235.112', 'admin', '2020-05-16 09:56:54'),
(53, 'Kepses', '111.94.41.40', 'dasview', '2020-05-16 09:56:55'),
(54, 'Admin Utama', '111.94.41.40', 'admin', '2020-05-16 09:58:16'),
(55, 'Admin Utama', '180.244.235.112', 'admin', '2020-05-17 02:49:58'),
(56, 'Admin Utama', '125.166.118.170', 'admin', '2020-05-17 02:50:48'),
(57, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-20 19:48:18'),
(58, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-20 20:23:19'),
(59, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-20 20:33:52'),
(60, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-20 20:42:02'),
(61, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-20 20:43:54'),
(62, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-20 20:45:39'),
(63, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-21 00:48:16'),
(64, 'Admin Utama', '180.244.234.80', 'admin', '2020-05-21 01:03:13'),
(65, 'Admin Utama', '114.124.161.21', 'admin', '2020-05-21 01:06:12'),
(66, 'Admin Utama', '36.79.254.161', 'admin', '2020-05-21 02:38:22'),
(67, 'Admin Utama', '114.124.231.218', 'admin', '2020-05-21 06:17:22'),
(68, 'Admin Utama', '107.181.177.131', 'admin', '2020-05-21 08:13:45'),
(69, 'Admin Utama', '180.244.232.52', 'admin', '2020-05-21 11:48:42'),
(70, 'Admin KASIR', '180.244.232.52', 'kasir', '2020-05-21 11:50:40'),
(71, 'Admin Utama', '180.244.232.52', 'admin', '2020-05-21 11:53:29'),
(72, 'Yayasan', '180.244.232.52', 'dasview', '2020-05-21 11:55:19'),
(73, 'Admin Utama', '125.161.131.28', 'admin', '2020-05-22 01:41:49'),
(74, 'Admin Utama', '125.161.131.28', 'admin', '2020-05-22 01:43:03'),
(75, 'Admin Utama', '180.244.171.216', 'admin', '2020-05-22 03:37:54'),
(76, 'Admin Utama', '180.244.171.216', 'admin', '2020-05-22 04:12:18'),
(77, 'Admin Utama', '180.244.232.52', 'admin', '2020-05-22 04:20:04'),
(78, 'Admin Utama', '180.244.232.52', 'admin', '2020-05-22 04:20:36'),
(79, 'Admin Utama', '120.188.84.70', 'admin', '2020-05-22 08:53:23'),
(80, 'Admin Utama', '180.244.232.52', 'admin', '2020-05-22 08:53:48'),
(81, 'Admin Utama', '120.188.84.70', 'admin', '2020-05-22 08:54:10'),
(82, 'Admin Utama', '180.244.171.216', 'admin', '2020-05-22 11:25:44'),
(83, 'Admin Utama', '118.96.86.186', 'admin', '2020-05-23 03:22:15'),
(84, 'Admin Utama', '140.213.35.6', 'admin', '2020-05-23 04:37:09'),
(85, 'Admin Utama', '118.96.86.186', 'admin', '2020-05-23 09:29:21'),
(86, 'Admin Utama', '180.244.232.114', 'admin', '2020-05-23 12:32:03'),
(87, 'Admin Utama', '180.244.232.114', 'admin', '2020-05-23 12:38:16'),
(88, 'Admin Utama', '36.81.172.81', 'admin', '2020-05-23 13:33:34'),
(89, 'Admin Utama', '36.81.172.81', 'admin', '2020-05-23 13:34:48'),
(90, 'Admin Utama', '118.96.86.186', 'admin', '2020-05-23 14:29:32'),
(91, 'Admin Utama', '118.96.86.186', 'admin', '2020-05-23 14:29:32'),
(92, 'Admin Utama', '118.96.86.186', 'admin', '2020-05-24 01:54:06'),
(93, 'Admin Utama', '180.244.232.114', 'admin', '2020-05-24 09:45:21'),
(94, 'Admin Utama', '180.244.232.114', 'admin', '2020-05-24 10:49:43'),
(95, 'Admin Utama', '180.244.232.114', 'admin', '2020-05-24 10:58:02'),
(96, 'Admin Utama', '36.82.90.215', 'admin', '2020-05-24 11:10:51'),
(97, 'Admin Utama', '180.244.232.114', 'admin', '2020-05-24 11:48:40'),
(98, 'Admin Utama', '180.244.233.177', 'admin', '2020-05-24 12:33:18'),
(99, 'Admin Utama', '118.96.86.186', 'admin', '2020-05-24 17:54:41'),
(100, 'Admin Utama', '180.244.232.114', 'admin', '2020-05-24 23:28:46'),
(101, 'Admin Utama', '125.166.40.145', 'admin', '2020-05-25 00:14:43'),
(102, 'Admin Utama', '125.166.40.145', 'admin', '2020-05-25 11:14:06'),
(103, 'Admin Utama', '125.166.40.145', 'admin', '2020-05-25 11:14:07'),
(104, 'Admin Utama', '125.166.40.145', 'admin', '2020-05-25 17:11:23'),
(105, 'Admin Utama', '36.72.217.137', 'admin', '2020-05-26 04:42:34'),
(106, 'Admin Utama', '36.72.217.137', 'admin', '2020-05-26 04:44:12'),
(107, 'Admin Utama', '36.72.217.137', 'admin', '2020-05-26 04:51:14'),
(108, 'Admin Utama', '125.166.40.145', 'admin', '2020-05-26 05:32:32'),
(109, 'Admin Utama', '36.77.222.179', 'admin', '2020-05-26 06:47:27'),
(110, 'Admin Utama', '125.166.40.145', 'admin', '2020-05-26 13:09:24'),
(111, 'Admin Utama', '180.244.250.213', 'admin', '2020-05-27 16:45:38'),
(112, 'Admin Utama', '180.244.250.213', 'admin', '2020-05-28 02:52:48'),
(113, 'Admin Utama', '36.77.222.179', 'admin', '2020-05-28 03:30:36'),
(114, 'Admin Utama', '36.77.222.179', 'admin', '2020-05-28 03:41:46'),
(115, 'Admin Utama', '36.77.222.179', 'admin', '2020-05-28 04:01:31'),
(116, 'Admin Utama', '180.244.235.246', 'admin', '2020-05-28 06:03:12'),
(117, 'Admin Utama', '180.244.235.246', 'admin', '2020-05-28 10:51:28'),
(118, 'Admin Utama', '180.244.235.246', 'admin', '2020-05-28 12:51:56'),
(119, 'Admin Utama', '180.244.235.246', 'admin', '2020-05-28 16:01:47'),
(120, 'Admin Utama', '114.125.108.117', 'admin', '2020-05-29 04:06:41'),
(121, 'Admin Utama', '114.125.108.66', 'admin', '2020-05-29 04:47:22'),
(122, 'Admin Utama', '180.244.235.246', 'admin', '2020-05-29 05:09:14'),
(123, 'Admin Utama', '110.138.151.118', 'admin', '2020-05-29 06:18:33'),
(124, 'Admin Utama', '114.125.125.7', 'admin', '2020-05-29 09:23:22'),
(125, 'Admin Utama', '114.125.125.24', 'admin', '2020-05-29 10:59:07'),
(126, 'Admin Utama', '110.138.151.118', 'admin', '2020-05-30 03:13:21'),
(127, 'Admin Utama', '114.125.81.81', 'admin', '2020-05-30 12:50:02'),
(128, 'Admin Utama', '125.160.117.179', 'admin', '2020-05-30 13:27:44'),
(129, 'Admin Utama', '125.160.117.179', 'admin', '2020-05-30 18:22:31'),
(130, 'Admin Utama', '182.1.99.118', 'admin', '2020-05-31 06:59:14'),
(131, 'Admin Utama', '182.1.99.234', 'admin', '2020-05-31 06:59:20'),
(132, 'Admin Utama', '114.125.108.184', 'admin', '2020-05-31 09:12:05'),
(133, 'Admin Utama', '114.125.127.38', 'admin', '2020-05-31 09:20:29'),
(134, 'Admin Utama', '125.160.117.179', 'admin', '2020-05-31 10:41:36'),
(135, 'Admin Utama', '114.125.81.86', 'admin', '2020-05-31 13:18:53'),
(136, 'Admin Utama', '114.125.81.86', 'admin', '2020-05-31 13:26:06'),
(137, 'Admin Utama', '125.160.117.179', 'admin', '2020-05-31 14:52:54'),
(138, 'Admin Utama', '110.138.252.89', 'admin', '2020-06-01 00:48:37'),
(139, 'Admin Utama', '114.124.161.43', 'admin', '2020-06-01 01:28:18'),
(140, 'Admin Utama', '114.124.161.43', 'admin', '2020-06-01 01:30:22'),
(141, 'Admin Utama', '114.124.161.43', 'admin', '2020-06-01 01:33:31'),
(142, 'Admin Utama', '180.244.232.101', 'admin', '2020-06-01 06:14:44'),
(143, 'Admin Utama', '180.244.232.101', 'admin', '2020-06-01 06:26:37'),
(144, 'Admin Utama', '109.169.23.79', 'admin', '2020-06-01 06:41:01'),
(145, 'Admin Utama', '110.138.150.13', 'admin', '2020-06-01 10:57:49'),
(146, 'Admin Utama', '114.125.81.79', 'admin', '2020-06-01 13:16:18'),
(147, 'Admin PPDB', '114.125.81.79', 'admin', '2020-06-01 13:28:51'),
(148, 'Admin Utama', '114.125.81.79', 'admin', '2020-06-01 13:29:47'),
(149, 'Admin Utama', '114.125.81.79', 'admin', '2020-06-01 13:31:07'),
(150, 'Admin Utama', '114.125.81.79', 'admin', '2020-06-01 13:33:09'),
(151, 'Admin Utama', '114.125.81.79', 'admin', '2020-06-01 13:33:11'),
(152, 'Admin Utama', '114.125.81.79', 'admin', '2020-06-01 13:36:15'),
(153, 'Admin Utama', '114.125.81.79', 'admin', '2020-06-01 13:37:42'),
(154, 'Admin Utama', '110.138.150.13', 'admin', '2020-06-01 16:01:14'),
(155, 'Admin Utama', '114.125.81.73', 'admin', '2020-06-02 15:09:36'),
(156, 'Admin Utama', '114.125.81.73', 'admin', '2020-06-02 15:13:11'),
(157, 'Admin Utama', '114.125.81.73', 'admin', '2020-06-02 15:20:02'),
(158, 'Admin PPDB', '114.125.81.73', 'admin', '2020-06-02 15:28:42'),
(159, 'Admin Utama', '114.125.81.73', 'admin', '2020-06-02 15:31:03'),
(160, 'Admin Utama', '114.125.81.73', 'admin', '2020-06-02 15:36:15'),
(161, 'Admin Utama', '114.125.81.73', 'admin', '2020-06-02 15:39:09'),
(162, 'Admin Utama', '114.125.81.73', 'admin', '2020-06-02 16:01:33'),
(163, 'Admin Utama', '36.71.173.186', 'admin', '2020-06-02 17:55:36'),
(164, 'Admin Utama', '36.71.173.186', 'admin', '2020-06-02 18:08:29'),
(165, 'Admin Utama', '125.162.252.56', 'admin', '2020-06-02 18:08:46'),
(166, 'Admin Utama', '114.125.81.83', 'admin', '2020-06-02 23:49:01'),
(167, 'Admin Utama', '114.125.81.83', 'admin', '2020-06-02 23:52:30'),
(168, 'Admin Utama', '36.73.243.27', 'admin', '2020-06-03 10:51:48'),
(169, 'Admin Utama', '36.73.243.27', 'admin', '2020-06-03 10:51:49'),
(170, 'Admin Utama', '36.73.243.27', 'admin', '2020-06-03 10:51:51'),
(171, 'Admin Utama', '36.74.13.201', 'admin', '2020-06-03 23:27:48'),
(172, 'Admin Utama', '182.1.114.215', 'admin', '2020-06-04 13:29:52'),
(173, 'Admin Utama', '36.71.59.38', 'admin', '2020-06-05 00:38:54'),
(174, 'Admin Utama', '180.244.232.143', 'admin', '2020-06-05 00:39:18'),
(175, 'Admin Utama', '36.71.16.64', 'admin', '2020-06-05 06:30:25'),
(176, 'Admin Utama', '114.125.111.249', 'admin', '2020-06-05 06:43:07'),
(177, 'Admin PPDB', '114.125.111.85', 'admin', '2020-06-05 06:46:04'),
(178, 'Admin Utama', '114.125.111.105', 'admin', '2020-06-05 06:50:36'),
(179, 'Admin Utama', '180.244.66.106', 'admin', '2020-06-05 07:00:51'),
(180, 'Admin Utama', '180.244.66.106', 'admin', '2020-06-05 07:00:53'),
(181, 'Admin Utama', '114.125.81.78', 'admin', '2020-06-05 12:17:47'),
(182, 'Admin Utama', '114.125.81.78', 'admin', '2020-06-05 13:24:20'),
(183, 'Admin Utama', '36.71.16.64', 'admin', '2020-06-05 13:26:56'),
(184, 'Usmiati', '36.71.16.64', 'guru', '2020-06-05 13:44:44'),
(185, 'Admin Utama', '36.71.16.64', 'admin', '2020-06-05 13:45:35'),
(186, 'Admin Utama', '114.125.81.87', 'admin', '2020-06-05 21:16:25'),
(187, 'Admin Utama', '36.77.123.220', 'admin', '2020-06-06 02:59:47'),
(188, 'Admin Utama', '36.71.16.64', 'admin', '2020-06-06 03:41:47'),
(189, 'Admin Utama', '36.71.16.64', 'admin', '2020-06-06 03:43:48'),
(190, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:25:53'),
(191, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:25:54'),
(192, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:25:55'),
(193, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:25:57'),
(194, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:25:58'),
(195, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:26:01'),
(196, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:26:02'),
(197, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:26:02'),
(198, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:26:03'),
(199, 'Admin Utama', '114.125.81.67', 'admin', '2020-06-06 09:26:04'),
(200, 'Admin Utama', '36.71.16.64', 'admin', '2020-06-06 15:54:48'),
(201, 'Admin Utama', '114.125.81.76', 'admin', '2020-06-07 01:34:56'),
(202, 'Admin Utama', '114.125.81.76', 'admin', '2020-06-07 01:34:57'),
(203, 'Admin Utama', '114.125.124.155', 'admin', '2020-06-07 03:42:21'),
(204, 'nana', '::1', 'siswa', '2020-06-07 10:31:23'),
(205, 'Admin Utama', '::1', 'admin', '2020-06-07 10:32:25'),
(206, 'Nana', '::1', 'guru', '2020-06-07 10:32:57'),
(207, 'Nana', '::1', 'guru', '2020-06-07 10:35:13'),
(208, 'Admin Utama', '::1', 'admin', '2020-06-07 10:44:52'),
(209, 'Nana', '::1', 'guru', '2020-06-07 10:49:45'),
(210, 'Usmiati', '::1', 'guru', '2020-06-07 10:50:10'),
(211, 'abdullah', '::1', 'siswa', '2020-06-07 10:50:59'),
(212, 'Nana', '::1', 'guru', '2020-06-07 10:51:28'),
(213, 'Admin Utama', '::1', 'admin', '2020-06-07 10:57:12'),
(214, 'Admin Utama', '::1', 'admin', '2020-06-07 10:58:21'),
(215, 'Nana', '::1', 'guru', '2020-06-07 11:01:10'),
(216, 'Usmiati', '::1', 'guru', '2020-06-07 11:01:24'),
(217, 'Admin Utama', '::1', 'admin', '2020-06-07 11:02:29'),
(218, 'Nana', '::1', 'guru', '2020-06-07 11:03:10'),
(219, 'Admin Utama', '::1', 'admin', '2020-06-07 11:04:38'),
(220, 'Admin Utama', '::1', 'admin', '2020-06-07 11:17:13'),
(221, 'Nana', '::1', 'guru', '2020-06-07 11:20:40'),
(222, 'abdullah', '::1', 'siswa', '2020-06-07 12:42:02'),
(223, 'abdullah', '::1', 'siswa', '2020-06-07 13:46:44'),
(224, 'Admin Utama', '::1', 'admin', '2020-06-07 15:49:39'),
(225, 'nana', '::1', 'siswa', '2020-06-07 19:25:06'),
(226, 'abdullah', '::1', 'siswa', '2020-06-07 20:27:28'),
(227, 'nana', '::1', 'siswa', '2020-06-07 20:28:17'),
(228, 'Admin Utama', '::1', 'admin', '2020-06-08 02:15:58'),
(229, 'nana', '::1', 'siswa', '2020-06-08 02:17:15'),
(230, 'nana', '::1', 'siswa', '2020-06-08 10:05:29'),
(231, 'Admin Utama', '::1', 'admin', '2020-06-08 10:05:57'),
(232, 'abdullah', '::1', 'siswa', '2020-06-08 14:04:57'),
(233, 'nana', '::1', 'siswa', '2020-06-08 14:11:58'),
(234, 'nana', '::1', 'siswa', '2020-06-08 14:14:00'),
(235, 'nana', '::1', 'siswa', '2020-06-08 14:15:25'),
(236, 'nana', '::1', 'siswa', '2020-06-08 14:16:19'),
(237, 'Admin Utama', '::1', 'admin', '2020-06-08 14:19:11'),
(238, 'Nana', '::1', 'guru', '2020-06-08 14:26:21'),
(239, 'admin1', '::1', 'admin', '2020-06-08 14:40:06'),
(240, 'Admin Utama', '::1', 'admin', '2020-06-11 05:28:46'),
(241, 'Admin Utama', '::1', 'admin', '2020-06-11 05:29:51'),
(242, 'Admin Utama', '::1', 'admin', '2020-06-11 06:02:37'),
(243, 'operator', '::1', 'admin', '2020-06-11 06:25:17'),
(244, 'Admin Utama', '::1', 'admin', '2020-06-11 06:29:35'),
(245, 'operator', '::1', 'admin', '2020-06-11 06:36:32'),
(246, 'Admin Utama', '::1', 'admin', '2020-06-11 06:38:45'),
(247, 'Admin Utama', '::1', 'admin', '2020-06-11 06:41:58'),
(248, 'staff tu', '::1', 'admin', '2020-06-11 06:44:49'),
(249, 'Admin Utama', '::1', 'admin', '2020-06-11 06:48:31'),
(250, 'ksksk', '::1', 'admin', '2020-06-11 07:06:03'),
(251, 'nana', '::1', 'admin', '2020-06-11 07:06:22'),
(252, 'Ika Fitriah', '::1', 'admin', '2020-06-11 07:10:47'),
(253, 'nana', '::1', 'admin', '2020-06-11 07:14:06'),
(254, 'nana', '::1', 'admin', '2020-06-11 07:20:45'),
(255, 'staff tu', '::1', 'admin', '2020-06-11 07:21:18'),
(256, 'nana', '::1', 'admin', '2020-06-11 07:21:36'),
(257, 'nana', '::1', 'admin', '2020-06-11 07:22:33'),
(258, '99', '::1', 'admin', '2020-06-11 07:23:37'),
(259, 'Admin Utama', '::1', 'admin', '2020-06-11 07:25:04'),
(260, 'Fahyur (Kepala Sekolah)', '::1', 'dasview', '2020-06-11 07:46:33'),
(261, 'Admin Utama', '::1', 'admin', '2020-06-11 07:47:23'),
(262, 'Fahyur (Kepala Sekolah)', '::1', 'dasview', '2020-06-11 07:47:39'),
(263, 'Fahyur (Kepala Sekolah)', '::1', 'dasview', '2020-06-11 07:51:19'),
(264, 'Admin Utama', '::1', 'admin', '2020-06-11 07:51:38'),
(265, 'Admin Utama', '::1', 'admin', '2020-06-11 07:55:46'),
(266, 'Fahyur (Kepala Sekolah)', '::1', 'dasview', '2020-06-11 07:56:03'),
(267, 'Admin Utama', '::1', 'admin', '2020-06-11 08:19:28'),
(268, 'Fahyur (Kepala Sekolah)', '::1', 'dasview', '2020-06-11 08:19:59'),
(269, 'Fahyur (Kepala Sekolah)', '::1', 'admin', '2020-06-11 08:20:58'),
(270, 'nana', '::1', 'admin', '2020-06-11 08:21:30'),
(271, 'staff tu', '::1', 'admin', '2020-06-11 08:27:11'),
(272, 'Admin Utama', '::1', 'admin', '2020-06-11 08:27:24'),
(273, 'Fahyur (Kepala Sekolah)', '::1', 'admin', '2020-06-11 08:27:42'),
(274, 'Admin Utama', '::1', 'admin', '2020-06-11 08:30:05'),
(275, 'Fahyur (Kepala Sekolah)', '::1', 'admin', '2020-06-11 08:30:25'),
(276, 'nana', '::1', 'admin', '2020-06-11 08:30:50'),
(277, 'staff tu', '::1', 'admin', '2020-06-11 08:31:04'),
(278, 'Fahyur (Kepala Sekolah)', '::1', 'admin', '2020-06-11 08:32:16'),
(279, 'dodi', '::1', 'admin', '2020-06-11 08:36:27'),
(280, 'dodi', '::1', 'admin', '2020-06-11 08:36:45'),
(281, 'Admin Utama', '::1', 'admin', '2020-06-11 08:40:14'),
(282, 'Admin Utama', '::1', 'admin', '2020-06-11 08:41:11'),
(283, 'Admin Utama', '::1', 'admin', '2020-06-12 13:52:37'),
(284, 'Admin Utama', '::1', 'admin', '2020-06-12 14:39:22'),
(285, 'Admin Utama', '::1', 'admin', '2020-06-12 15:51:05'),
(286, 'nana', '::1', 'siswa', '2020-06-12 15:51:21'),
(287, 'Admin Utama', '::1', 'admin', '2020-06-12 15:59:55'),
(288, 'Nana', '::1', 'guru', '2020-06-12 16:36:03'),
(289, 'Admin Utama', '::1', 'admin', '2020-06-12 16:36:33'),
(290, 'Nana', '::1', 'guru', '2020-06-12 16:38:22'),
(291, 'Admin Utama', '::1', 'admin', '2020-06-12 16:40:03'),
(292, 'Nana', '::1', 'guru', '2020-06-12 16:44:55'),
(293, 'Admin Utama', '::1', 'admin', '2020-06-12 16:53:11'),
(294, 'Usmiati', '::1', 'guru', '2020-06-12 16:53:37'),
(295, 'Admin Utama', '::1', 'admin', '2020-06-12 16:54:08'),
(296, 'Nana', '::1', 'guru', '2020-06-12 17:05:11'),
(297, 'Admin Utama', '::1', 'admin', '2020-06-12 17:08:25'),
(298, 'Nana', '::1', 'guru', '2020-06-12 17:10:36'),
(299, 'Admin Utama', '::1', 'admin', '2020-06-12 17:11:03'),
(300, 'Nana', '::1', 'guru', '2020-06-12 17:33:10'),
(301, 'Admin Utama', '::1', 'admin', '2020-06-12 17:33:33'),
(302, 'Nana', '::1', 'guru', '2020-06-12 17:38:32'),
(303, 'Admin Utama', '::1', 'admin', '2020-06-13 03:19:38'),
(304, 'Admin Utama', '::1', 'admin', '2020-06-13 03:59:20'),
(305, 'admin3', '::1', 'admin', '2020-06-13 04:02:22'),
(306, 'Admin Utama', '::1', 'admin', '2020-06-13 06:55:40'),
(307, 'hass', '::1', 'admin', '2020-06-13 07:44:33'),
(308, 'admin3', '::1', 'admin', '2020-06-13 07:52:47'),
(309, 'admin3', '::1', 'admin', '2020-06-13 07:56:51'),
(310, 'nana', '::1', 'admin', '2020-06-13 08:49:55'),
(311, 'nana', '::1', 'admin', '2020-06-13 08:51:04'),
(312, 'Admin Utama', '::1', 'admin', '2020-06-13 09:35:10'),
(313, 'admin3', '::1', 'admin', '2020-06-13 09:35:33'),
(314, 'Nana', '::1', 'guru', '2020-06-13 09:50:28'),
(315, 'Nana', '::1', 'guru', '2020-06-13 10:04:38'),
(316, 'Nana', '::1', 'guru', '2020-06-13 10:08:37'),
(317, 'Admin Utama', '::1', 'admin', '2020-06-13 10:16:58'),
(318, 'Usmiati', '::1', 'guru', '2020-06-13 10:18:27'),
(319, 'Admin Utama', '::1', 'admin', '2020-06-13 10:22:28'),
(320, 'Usmiati', '::1', 'guru', '2020-06-13 10:23:21'),
(321, 'Admin Utama', '::1', 'admin', '2020-06-14 03:00:44'),
(322, 'ads', '::1', 'admin', '2020-06-14 03:36:42'),
(323, 'gurumapelcek', '::1', 'guru', '2020-06-14 03:38:55'),
(324, NULL, '::1', 'admin', '2020-06-14 03:41:24'),
(325, 'gurumapelcek', '::1', 'gurubk', '2020-06-14 03:43:55'),
(326, NULL, '::1', 'admin', '2020-06-14 03:44:45'),
(327, NULL, '::1', 'admin', '2020-06-14 03:45:14'),
(328, 'Admin Utama', '::1', 'admin', '2020-06-14 03:48:42'),
(329, 'dana', '::1', 'adminakademik', '2020-06-14 03:54:43'),
(330, 'Admin Utama', '::1', 'admin', '2020-06-14 03:55:14'),
(331, 'Admin Utama', '::1', 'admin', '2020-06-14 03:57:13'),
(332, 'sarjo', '::1', 'guru', '2020-06-14 03:59:05'),
(333, 'sarjo', '::1', 'guru', '2020-06-14 04:14:06'),
(334, 'Nana', '::1', 'guru', '2020-06-14 04:20:30'),
(335, 'Admin Utama', '::1', 'admin', '2020-06-14 04:20:44'),
(336, 'dania', '::1', 'gurubk', '2020-06-14 04:24:58'),
(337, 'Admin Utama', '::1', 'admin', '2020-06-14 04:25:42'),
(338, 'Admin Utama', '::1', 'admin', '2020-06-14 17:26:24'),
(339, 'Admin Utama', '::1', 'admin', '2020-06-15 02:44:58'),
(340, 'Admin Utama', '::1', 'admin', '2020-06-15 05:51:07'),
(341, 'Admin Utama', '::1', 'admin', '2020-06-15 13:00:37'),
(342, 'Admin Utama', '::1', 'admin', '2020-06-16 05:35:34'),
(343, 'Admin Utama', '::1', 'admin', '2020-06-17 06:51:33'),
(344, '100', '::1', 'guru', '2020-06-17 07:28:16'),
(345, 'Admin Utama', '192.168.100.20', 'admin', '2020-06-17 07:30:12'),
(346, 'Admin Utama', '::1', 'admin', '2020-06-17 07:31:48'),
(347, 'DODI LAZUARDI, S. Kom', '192.168.100.20', 'guru', '2020-06-17 07:32:27'),
(348, 'Admin Utama', '192.168.100.20', 'admin', '2020-06-17 07:33:43'),
(349, 'Admin Utama', '192.168.100.20', 'admin', '2020-06-17 07:53:31'),
(350, 'DODI LAZUARDI, S. Kom', '192.168.100.20', 'guru', '2020-06-17 07:53:57'),
(351, 'DODI LAZUARDI, S. Kom', '::1', 'guru', '2020-06-17 07:54:24'),
(352, 'DODI LAZUARDI, S. Kom', '192.168.100.20', 'guru', '2020-06-17 08:01:42'),
(353, 'Admin Utama', '::1', 'admin', '2020-06-17 08:03:08'),
(354, 'MUHAMMAD', '192.168.100.20', 'siswa', '2020-06-17 08:03:36'),
(355, 'Admin Utama', '::1', 'admin', '2020-06-17 17:10:16'),
(356, 'nana', '::1', 'siswa', '2020-06-17 17:10:40'),
(357, 'Admin Utama', '::1', 'admin', '2020-06-17 18:13:04'),
(358, 'nana', '::1', 'siswa', '2020-06-17 18:16:51'),
(359, 'Admin Utama', '::1', 'admin', '2020-06-17 18:22:30'),
(360, 'nana', '::1', 'siswa', '2020-06-17 18:30:13'),
(361, 'Admin Utama', '::1', 'admin', '2020-06-17 18:31:21'),
(362, 'nana', '::1', 'siswa', '2020-06-17 18:32:20'),
(363, 'Admin Utama', '::1', 'admin', '2020-06-17 18:34:00'),
(364, 'nana', '::1', 'siswa', '2020-06-17 18:35:46'),
(365, 'Admin Utama', '::1', 'admin', '2020-06-17 18:38:56'),
(366, 'nana', '::1', 'siswa', '2020-06-17 18:46:31'),
(367, 'nana', '::1', 'siswa', '2020-06-18 12:58:57'),
(368, 'Admin Utama', '::1', 'admin', '2020-06-19 11:32:22'),
(369, 'Admin Utama', '::1', 'admin', '2020-06-19 12:01:11'),
(370, 'nana', '::1', 'siswa', '2020-06-19 14:32:57'),
(371, 'Admin Utama', '::1', 'admin', '2020-06-20 02:20:16'),
(372, 'MUHAMMAD', '::1', 'siswa', '2020-06-20 03:45:53'),
(373, 'Admin Utama', '::1', 'admin', '2020-06-20 03:53:18'),
(374, 'nana', '::1', 'siswa', '2020-06-20 03:56:13'),
(375, 'Admin Utama', '::1', 'admin', '2020-06-20 08:32:23'),
(376, 'Admin Utama', '::1', 'admin', '2020-06-20 10:38:21'),
(377, 'admincek', '::1', 'admin', '2020-06-20 10:48:12'),
(378, 'Admin Utama', '::1', 'admin', '2020-06-20 12:07:33'),
(379, 'Admin Utama', '::1', 'admin', '2020-06-21 02:38:29'),
(380, 'Admin Utama', '::1', 'admin', '2020-06-22 15:15:24'),
(381, 'Admin Utama', '::1', 'admin', '2020-06-22 16:18:37'),
(382, 'Nana', '::1', 'guru', '2020-06-22 18:37:36'),
(383, 'MUHAMMAD', '::1', 'siswa', '2020-06-22 18:40:35'),
(384, 'Admin Utama', '::1', 'admin', '2020-06-23 02:16:11'),
(385, 'MUHAMMAD', '::1', 'siswa', '2020-06-23 02:18:41'),
(386, 'Admin Utama', '::1', 'admin', '2020-06-23 02:23:01'),
(387, 'Admin Utama', '::1', 'admin', '2021-02-18 04:40:05'),
(388, 'Admin Utama', '::1', 'admin', '2021-02-18 05:06:00'),
(389, 'Admin Utama', '::1', 'admin', '2021-02-19 02:40:08'),
(390, 'Admin Utama', '::1', 'admin', '2021-02-19 02:52:05'),
(391, 'Admin Utama', '::1', 'admin', '2021-02-19 02:56:48'),
(392, 'Admin Utama', '::1', 'admin', '2021-02-19 03:02:33'),
(393, 'admincek', '::1', 'admin', '2021-02-19 03:03:02'),
(394, 'admincek', '::1', 'admin', '2021-02-19 03:03:46'),
(395, 'admincek', '::1', 'admin', '2021-02-19 03:04:58'),
(396, 'Admin Utama', '::1', 'admin', '2021-02-19 03:09:07'),
(397, 'admincek', '::1', 'admin', '2021-02-19 03:09:16'),
(398, 'admincek', '::1', 'admin', '2021-02-19 03:10:29'),
(399, 'Admin Utama', '::1', 'admin', '2021-02-19 03:14:36'),
(400, 'Admin Utama', '::1', 'admin', '2021-02-19 03:22:05'),
(401, 'Admin Utama', '::1', 'admin', '2021-02-19 03:22:34'),
(402, 'Admin Utama', '::1', 'admin', '2021-02-19 03:27:22'),
(403, 'Admin Perpus', '::1', 'admin', '2021-02-19 03:28:28'),
(404, 'Admin Utama', '::1', 'admin', '2021-02-19 03:28:58'),
(405, 'Admin Utama', '::1', 'admin', '2021-03-01 02:10:00'),
(406, 'Admin Utama', '::1', 'admin', '2021-03-01 02:10:25'),
(407, 'Admin Utama', '::1', 'admin', '2021-03-01 02:38:19'),
(408, 'Admin Utama', '::1', 'admin', '2021-03-01 04:16:25'),
(409, 'Admin Utama', '::1', 'admin', '2021-03-01 04:32:43'),
(410, 'Admin Utama', '::1', 'admin', '2021-04-19 03:37:28'),
(411, 'Admin Utama', '::1', 'admin', '2021-05-18 04:42:14'),
(412, 'Admin Utama', '::1', 'admin', '2021-05-18 04:51:08'),
(413, 'Admin Utama', '::1', 'admin', '2021-05-18 04:53:41'),
(414, 'Admin Utama', '::1', 'admin', '2021-06-03 01:54:55'),
(415, 'Admin Utama', '::1', 'admin', '2021-06-03 02:54:46'),
(416, 'Admin Utama', '::1', 'admin', '2021-06-18 10:44:35'),
(417, 'Admin Utama', '::1', 'admin', '2021-07-11 07:06:17'),
(418, 'Admin Utama', '::1', 'admin', '2021-07-26 01:41:03'),
(419, 'Admin Utama', '::1', 'admin', '2021-07-26 02:06:50'),
(420, 'Admin Utama', '::1', 'admin', '2021-07-26 02:07:02'),
(421, 'Admin Utama', '::1', 'admin', '2021-07-26 02:44:39'),
(422, 'Admin Utama', '::1', 'admin', '2021-07-26 02:44:50'),
(423, 'Admin Utama', '::1', 'admin', '2021-07-26 02:45:20'),
(424, 'Admin Utama', '::1', 'admin', '2021-08-20 04:02:56'),
(425, 'Admin Utama', '::1', 'admin', '2021-08-20 04:26:28'),
(426, 'Admin Utama', '::1', 'admin', '2021-08-20 04:28:09'),
(427, 'Admin Utama', '::1', 'admin', '2021-08-21 04:25:55'),
(428, 'Admin Utama', '::1', 'admin', '2021-08-21 04:34:53'),
(429, 'Admin Utama', '::1', 'admin', '2021-08-21 04:39:32'),
(430, 'Admin Perpus', '::1', 'admin', '2021-08-21 05:03:02'),
(431, 'Admin Utama', '::1', 'admin', '2021-08-21 05:08:32'),
(432, 'Admin Utama', '::1', 'admin', '2021-08-21 05:10:17'),
(433, 'Admin Utama', '::1', 'admin', '2021-08-21 05:14:30'),
(434, 'Admin Utama', '::1', 'admin', '2021-08-21 05:26:52'),
(435, 'Admin Utama', '::1', 'admin', '2021-08-21 05:27:37'),
(436, 'Admin Utama', '::1', 'admin', '2021-08-21 05:35:07'),
(437, 'Admin Utama', '::1', 'admin', '2021-08-26 08:12:59'),
(438, 'Admin Utama', '::1', 'admin', '2022-01-24 06:27:06'),
(439, 'Admin Utama', '180.253.182.169', 'admin', '2022-01-24 07:02:49'),
(440, 'Admin Utama', '180.253.182.169', 'admin', '2022-01-24 07:03:00'),
(441, 'Admin Utama', '180.253.182.169', 'admin', '2022-01-24 07:03:24'),
(442, 'admin1', '180.253.182.169', 'admin', '2022-01-24 07:05:28'),
(443, 'Admin Utama', '180.253.182.169', 'admin', '2022-01-24 07:06:10'),
(444, 'Admin Utama', '180.253.182.169', 'admin', '2022-01-24 07:09:07'),
(445, 'Admin Utama', '180.253.182.169', 'admin', '2022-01-24 07:15:31'),
(446, 'Admin Utama', '180.253.182.169', 'admin', '2022-01-24 07:22:09'),
(447, 'Admin Utama', '36.72.95.141', 'admin', '2022-02-01 14:43:51'),
(448, 'Admin Utama', '36.72.142.87', 'admin', '2022-02-18 07:05:16'),
(449, 'Admin Utama', '36.72.142.87', 'admin', '2022-02-18 07:08:36'),
(450, 'Admin Utama', '36.72.142.87', 'admin', '2022-02-18 08:21:42'),
(451, 'Admin Utama', '180.241.242.156', 'admin', '2022-02-19 05:02:07'),
(452, NULL, '180.241.241.74', 'admin', '2022-02-19 05:03:11'),
(453, 'ads', '180.241.240.246', 'admin', '2022-02-19 05:04:44'),
(454, 'Usmiati', '180.241.240.246', 'guru', '2022-02-19 05:05:21'),
(455, 'abdullah', '180.241.243.56', 'siswa', '2022-02-19 05:07:37'),
(456, 'Guru Piket', '180.241.243.56', 'admin', '2022-02-19 05:14:12'),
(457, 'Guru Piket', '180.241.243.56', 'admin', '2022-02-19 05:23:16'),
(458, 'Guru Piket', '180.241.241.74', 'admin', '2022-02-19 05:25:32'),
(459, 'Guru Piket', '180.241.243.56', 'admin', '2022-02-19 05:27:11'),
(460, 'Admin Utama', '180.241.240.246', 'admin', '2022-02-19 05:46:49'),
(461, 'Admin Utama', '36.72.106.6', 'admin', '2022-03-15 05:09:38'),
(462, 'Admin Utama', '36.72.106.6', 'admin', '2022-03-15 05:14:29'),
(463, 'Admin Utama', '180.241.243.172', 'admin', '2022-03-31 09:35:34'),
(0, 'Admin Utama', '36.90.200.67', 'admin', '2022-04-04 06:12:51'),
(0, 'Guru Piket', '36.90.200.67', 'admin', '2022-04-04 06:14:03'),
(0, 'Admin Utama', '36.90.200.67', 'admin', '2022-04-04 06:14:18'),
(0, 'Guru Piket', '36.90.200.67', 'admin', '2022-04-04 06:21:04'),
(0, 'Guru Piket', '36.90.200.67', 'admin', '2022-04-04 06:21:49'),
(0, 'Admin Utama', '36.90.200.67', 'admin', '2022-04-04 06:21:49'),
(0, 'Admin Utama', '36.90.200.67', 'admin', '2022-04-04 06:22:24'),
(0, 'Guru Piket', '36.90.200.67', 'admin', '2022-04-04 06:26:29'),
(0, 'Guru Piket', '36.90.200.67', 'admin', '2022-04-04 06:29:07'),
(0, 'Guru Piket', '36.72.124.169', 'admin', '2022-04-07 03:41:14'),
(0, 'Guru Piket', '36.72.124.169', 'admin', '2022-04-07 03:43:50'),
(0, 'Guru Piket', '36.72.124.169', 'admin', '2022-04-07 03:49:33'),
(0, 'Guru Piket', '36.72.124.169', 'admin', '2022-04-07 04:22:31'),
(0, 'Guru Piket', '36.72.124.169', 'admin', '2022-04-07 04:37:57'),
(0, 'Guru Piket', '103.175.46.77', 'admin', '2022-05-08 11:37:18'),
(0, 'Admin Utama', '36.72.91.100', 'admin', '2022-05-18 06:58:43'),
(0, 'Admin Utama', '36.72.91.100', 'admin', '2022-05-18 07:10:28'),
(0, 'Guru Piket', '36.72.91.100', 'admin', '2022-05-18 07:11:04'),
(0, 'Guru Piket', '36.72.91.100', 'admin', '2022-05-18 07:15:00'),
(0, 'Admin Utama', '36.72.91.100', 'admin', '2022-05-18 07:15:20'),
(0, 'Admin Utama', '36.72.91.100', 'admin', '2022-05-18 07:18:10'),
(0, 'Admin Utama', '140.213.37.70', 'admin', '2022-05-18 09:08:32'),
(0, 'Admin Utama', '140.213.37.70', 'admin', '2022-05-18 09:09:11'),
(0, 'Admin Utama', '140.213.37.70', 'admin', '2022-05-18 09:10:36'),
(0, 'Admin Utama', '140.213.0.116', 'admin', '2022-05-19 08:20:06'),
(0, 'Admin Utama', '36.72.98.19', 'admin', '2022-05-23 01:57:24'),
(0, 'Admin Utama', '36.72.189.241', 'admin', '2022-07-07 02:59:18'),
(0, 'Admin Utama', '36.72.189.241', 'admin', '2022-07-08 07:25:30'),
(0, 'Admin Utama', '36.72.190.123', 'admin', '2022-11-09 14:05:02'),
(0, 'Admin Utama', '114.5.215.59', 'admin', '2022-11-09 14:06:23'),
(0, 'Admin Utama', '2001:448a:3001:42d2:85cb:', 'admin', '2023-02-27 07:39:00'),
(0, 'Admin Utama', '2001:448a:3001:42d2:85cb:', 'admin', '2023-02-27 07:49:42'),
(0, 'Admin Utama', '2001:448a:3001:42d2:85cb:', 'admin', '2023-02-27 07:50:52'),
(0, 'Admin Utama', '2001:448a:3001:42d2:85cb:', 'admin', '2023-02-27 07:51:37'),
(0, 'Admin Utama', '103.172.70.163', 'admin', '2023-07-15 08:05:04'),
(0, 'Admin Utama', '36.72.130.184', 'admin', '2023-10-09 02:30:33'),
(0, 'Admin Utama', '180.253.178.8', 'admin', '2023-12-21 07:45:34');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `id_parent` int(11) DEFAULT NULL,
  `posisi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id_menu`, `nama`, `url`, `id_parent`, `posisi`) VALUES
(1, 'Home', 'http://localhost/supercms/', 0, 1),
(3, 'kontak', 'http://localhost/supercms/web/kontak', 0, 7),
(4, 'Direktori Guru', 'http://localhost/ass/webpanel/web/staff', 20, 1),
(5, 'Gallery', 'http://localhost/supercms/web/gallery', 0, 4),
(6, 'download', '#', 0, 6),
(7, 'berita', 'http://localhost/ass/webpanel/web/berita', 0, 5),
(14, 'visi dan misi', 'http://localhost/supercms/web/page/detail/2/visi-dan-misi', 17, 2),
(17, 'profil', '#', 0, 2),
(19, 'struktur organisasi', 'http://localhost/supercms/web/page/detail/1/struktur-organisasi', 17, 3),
(20, 'direktori', '#', 0, 3),
(21, 'profile singkat', 'http://localhost/supercms/web/page/detail/3/profile-singkat', 17, 1),
(28, 'Ebook', 'http://localhost/supercms/Web/download/detail/10/Ebook', 6, 0),
(29, 'Anggota', 'http://localhost/supercms/Web/download/detail/11/Anggota', 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mst_admin`
--

CREATE TABLE `mst_admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `tipe` varchar(15) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_admin`
--

INSERT INTO `mst_admin` (`id`, `nama`, `username`, `password`, `tipe`, `foto`) VALUES
(1, 'Admin Utama', 'admin', 'AdminX11!', 'root', NULL),
(8, 'Superadmin', '0008302579', 'wapolking12', 'root', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mst_alumni`
--

CREATE TABLE `mst_alumni` (
  `id_alumni` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `tahun_lulus` varchar(4) DEFAULT NULL,
  `jenis_kelamin` varchar(15) DEFAULT NULL,
  `aktivitas_1` varchar(50) DEFAULT NULL,
  `aktivitas_2` varchar(50) DEFAULT NULL,
  `aktivitas_3` varchar(50) DEFAULT NULL,
  `aktivitas_4` varchar(50) DEFAULT NULL,
  `pernah_bekerja` varchar(15) DEFAULT NULL,
  `lama_dapat_kerja` varchar(25) DEFAULT NULL,
  `bidang_pekerjaan` varchar(50) DEFAULT NULL,
  `tingkat_kemudahan` varchar(50) DEFAULT NULL,
  `jumlah_gaji` varchar(30) DEFAULT NULL,
  `nama_tempat_kerja` varchar(50) DEFAULT NULL,
  `alamat_perusahaan` varchar(150) DEFAULT NULL,
  `kabupaten_perusahaan` varchar(50) DEFAULT NULL,
  `tanggal_mulai_kerja` date DEFAULT NULL,
  `tanggal_selesai_kerja` date DEFAULT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `aktivitas_kuliah` varchar(25) DEFAULT NULL,
  `status_perguruan_tinggi` varchar(25) DEFAULT NULL,
  `nama_perguruan_tinggi` varchar(80) DEFAULT NULL,
  `jenjang_pendidikan` varchar(50) DEFAULT NULL,
  `program_studi` varchar(50) DEFAULT NULL,
  `jalur_masuk` varchar(50) DEFAULT NULL,
  `mulai_kuliah` date DEFAULT NULL,
  `biaya_semester` float DEFAULT NULL,
  `status_kuliah` varchar(15) DEFAULT NULL,
  `nama_perusahaan_wirausaha` varchar(50) DEFAULT NULL,
  `jenis_usaha_1` varchar(50) DEFAULT NULL,
  `jenis_usaha_2` varchar(50) DEFAULT NULL,
  `jenis_usaha_3` varchar(50) DEFAULT NULL,
  `jenis_usaha_4` varchar(50) DEFAULT NULL,
  `mulai_usaha` date DEFAULT NULL,
  `status_wirausaha` varchar(25) DEFAULT NULL,
  `kesesuaiaan_pengetahuan` varchar(50) DEFAULT NULL,
  `bidang_kompetesi_1` varchar(50) DEFAULT NULL,
  `bidang_kompetesi_2` varchar(50) DEFAULT NULL,
  `bidang_kompetesi_3` varchar(50) DEFAULT NULL,
  `bidang_kompetesi_4` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_1` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_2` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_3` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_4` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_5` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_6` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_7` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_8` varchar(50) DEFAULT NULL,
  `bidang_kefarmasian_9` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_1` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_2` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_3` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_4` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_5` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_6` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_7` varchar(50) DEFAULT NULL,
  `bidang_pengetahuan_8` varchar(50) DEFAULT NULL,
  `materi_ditingkatkan` varchar(50) DEFAULT NULL,
  `info_kerja_1` varchar(50) DEFAULT NULL,
  `info_kerja_2` varchar(50) DEFAULT NULL,
  `info_kerja_3` varchar(50) DEFAULT NULL,
  `info_kerja_4` varchar(50) DEFAULT NULL,
  `info_kerja_5` varchar(50) DEFAULT NULL,
  `info_loker` varchar(40) DEFAULT NULL,
  `saran` varchar(50) DEFAULT NULL,
  `kesan` varchar(50) DEFAULT NULL,
  `status_aktif` char(1) NOT NULL DEFAULT '0',
  `tanggal_daftar` timestamp NOT NULL DEFAULT current_timestamp(),
  `angkatan` char(4) NOT NULL,
  `jurusan` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_alumni`
--

INSERT INTO `mst_alumni` (`id_alumni`, `nama`, `email`, `password`, `hp`, `tahun_lulus`, `jenis_kelamin`, `aktivitas_1`, `aktivitas_2`, `aktivitas_3`, `aktivitas_4`, `pernah_bekerja`, `lama_dapat_kerja`, `bidang_pekerjaan`, `tingkat_kemudahan`, `jumlah_gaji`, `nama_tempat_kerja`, `alamat_perusahaan`, `kabupaten_perusahaan`, `tanggal_mulai_kerja`, `tanggal_selesai_kerja`, `jabatan`, `aktivitas_kuliah`, `status_perguruan_tinggi`, `nama_perguruan_tinggi`, `jenjang_pendidikan`, `program_studi`, `jalur_masuk`, `mulai_kuliah`, `biaya_semester`, `status_kuliah`, `nama_perusahaan_wirausaha`, `jenis_usaha_1`, `jenis_usaha_2`, `jenis_usaha_3`, `jenis_usaha_4`, `mulai_usaha`, `status_wirausaha`, `kesesuaiaan_pengetahuan`, `bidang_kompetesi_1`, `bidang_kompetesi_2`, `bidang_kompetesi_3`, `bidang_kompetesi_4`, `bidang_kefarmasian_1`, `bidang_kefarmasian_2`, `bidang_kefarmasian_3`, `bidang_kefarmasian_4`, `bidang_kefarmasian_5`, `bidang_kefarmasian_6`, `bidang_kefarmasian_7`, `bidang_kefarmasian_8`, `bidang_kefarmasian_9`, `bidang_pengetahuan_1`, `bidang_pengetahuan_2`, `bidang_pengetahuan_3`, `bidang_pengetahuan_4`, `bidang_pengetahuan_5`, `bidang_pengetahuan_6`, `bidang_pengetahuan_7`, `bidang_pengetahuan_8`, `materi_ditingkatkan`, `info_kerja_1`, `info_kerja_2`, `info_kerja_3`, `info_kerja_4`, `info_kerja_5`, `info_loker`, `saran`, `kesan`, `status_aktif`, `tanggal_daftar`, `angkatan`, `jurusan`) VALUES
(1, 'Dian Fitoko', 'dianfitoko@gmail.com', '123456789', '087821120464', '2012', 'Laki-Laki', 'Kerja', 'Kuliah', 'Wirausaha', NULL, 'Ya, Pernah', '1 < Bulan', 'Non Kesehatan', 'Sulit', '> Rp 2.000.000', 'FyOs', 'Cirebon', 'Kabupaten Cirebon', '2012-08-21', '2021-08-21', 'CEO', 'Kuliah Sambil Kerja', 'Negeri', 'ITB', 'S2', 'TEKNIK INFORMATIKA', 'Ujian Mandiri', '2020-08-21', 5000000, 'Aktif', 'PT. TIAWAN VALAS', 'Jasa', 'Barang', NULL, NULL, '2014-08-21', 'Aktif', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, 'Internet', NULL, NULL, '', '', '', '1', '2021-08-21 05:14:19', '2010', 'MM'),
(2, 'tester', 'tester@gmail.com', '123456', NULL, NULL, NULL, 'Kerja', 'Kuliah', 'Wirausaha', 'Lainnya', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '2022-02-18 06:03:51', '', 'TKJ'),
(3, 'Rully Septiana', 'rully.septiana203@gmail.com', '123456', NULL, NULL, NULL, 'Kerja', 'Kuliah', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '2022-02-19 05:50:30', '', 'MM');

-- --------------------------------------------------------

--
-- Table structure for table `mst_barang`
--

CREATE TABLE `mst_barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `id_merk` int(11) DEFAULT NULL,
  `id_satuan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mst_box`
--

CREATE TABLE `mst_box` (
  `id_box` int(11) NOT NULL,
  `nama_box` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_box`
--

INSERT INTO `mst_box` (`id_box`, `nama_box`) VALUES
(1, 'A1231'),
(2, 'C.131');

-- --------------------------------------------------------

--
-- Table structure for table `mst_buku`
--

CREATE TABLE `mst_buku` (
  `id_buku` int(11) NOT NULL,
  `kode_buku` varchar(25) DEFAULT NULL,
  `judul_buku` varchar(100) DEFAULT NULL,
  `pengarang` varchar(80) DEFAULT NULL,
  `penerbit` varchar(100) DEFAULT NULL,
  `tahun_terbit` char(4) DEFAULT NULL,
  `tempat_terbit` varchar(80) DEFAULT NULL,
  `total_halaman` int(6) DEFAULT NULL,
  `tinggi_buku` float DEFAULT NULL,
  `ddc` varchar(50) DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `jumlah_buku` int(11) DEFAULT NULL,
  `tanggal_masuk` date DEFAULT NULL,
  `no_inventaris` varchar(25) DEFAULT NULL,
  `lokasi` varchar(15) DEFAULT NULL,
  `deskripsi_buku` text DEFAULT NULL,
  `foto_buku` varchar(100) DEFAULT NULL,
  `id_sumber` int(11) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_buku`
--

INSERT INTO `mst_buku` (`id_buku`, `kode_buku`, `judul_buku`, `pengarang`, `penerbit`, `tahun_terbit`, `tempat_terbit`, `total_halaman`, `tinggi_buku`, `ddc`, `isbn`, `jumlah_buku`, `tanggal_masuk`, `no_inventaris`, `lokasi`, `deskripsi_buku`, `foto_buku`, `id_sumber`, `id_kategori`, `stok`) VALUES
(1, '011', 'PHP Mastah', 'Ian Fytoko', 'FyOs', '2021', 'Cirebon', 128, 30, '099', '211175664852', 21, '2021-02-12', '311', 'Rak Komputer', 'Rak Komputer', NULL, 5, 5, NULL),
(2, '012', 'Codeigniter Framework', 'Ian Fytoko', 'FyOs', '2021', 'Cirebon', 215, 40, '099', '537385666285', 20, '2021-03-10', '215', 'Rak Komputer', 'Rak Komputer', NULL, 4, 5, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mst_bulan`
--

CREATE TABLE `mst_bulan` (
  `id_bulan` int(11) NOT NULL,
  `nama_bulan` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_bulan`
--

INSERT INTO `mst_bulan` (`id_bulan`, `nama_bulan`) VALUES
(2, 'Agustus'),
(10, 'April'),
(6, 'Desember'),
(8, 'Febuari'),
(7, 'Januari'),
(1, 'Juli'),
(12, 'Juni'),
(9, 'Maret'),
(11, 'Mei'),
(5, 'November'),
(4, 'Oktober'),
(3, 'September');

-- --------------------------------------------------------

--
-- Table structure for table `mst_daftar_aplikasi`
--

CREATE TABLE `mst_daftar_aplikasi` (
  `urutan_app` int(2) NOT NULL,
  `nama_app` varchar(255) DEFAULT NULL,
  `deskripsi_app` varchar(255) DEFAULT NULL,
  `icon_app` varchar(255) DEFAULT NULL,
  `warna_app` varchar(255) DEFAULT NULL,
  `jenis_link_app` varchar(255) DEFAULT NULL,
  `link_app` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_daftar_aplikasi`
--

INSERT INTO `mst_daftar_aplikasi` (`urutan_app`, `nama_app`, `deskripsi_app`, `icon_app`, `warna_app`, `jenis_link_app`, `link_app`) VALUES
(1, 'AKADEMIK', 'App Versi 1.2', 'fa-graduation-cap', 'info', 'eksternal', '../akademik'),
(2, 'KESISWAAN', 'App Versi 1.3', 'fa-address-card', 'info', 'eksternal', '../kesiswaan'),
(3, 'KEUANGAN', 'App Versi 2.1', 'fa-money-check-alt', 'info', 'eksternal', '../keuangan'),
(4, 'PERPUSTAKAAN', 'App Versi 1.3', 'fa-book', 'info', 'eksternal', '../perpustakaan'),
(5, 'ALUMNI', 'App Versi 1.5', 'fa-user-graduate', 'purple', 'eksternal', '../alumni'),
(6, 'KELULUSAN', 'App Versi 1.0', 'fa-user-check', 'danger', 'eksternal', '../kelulusan'),
(7, 'SARPRAS', 'App Versi 1.0', 'fa-cube', 'gray', 'eksternal', '../sarpras'),
(8, 'BUKU TAMU', 'App Versi 1.2', 'fa-chalkboard-teacher', 'success', 'eksternal', '../bukutamu'),
(10, 'ARSIP AKREDITASI', 'App Versi 1.0', 'fa-chalkboard-teacher', 'navy', 'eksternal', '../arsip'),
(11, 'PPDB ONLINE', 'App Versi 1.0', 'fa-id-badge', 'teal', 'eksternal', '../ppdb'),
(12, 'E-LEARNING', 'App Versi 1.0', 'fa-laptop', 'orange', 'eksternal', 'http://localhost/jlearning/admin'),
(13, 'CBT', 'App Versi 1.0', 'fa-laptop', 'orange', 'eksternal', 'http://178.128.30.126/cbt/index.php/manager'),
(14, 'TABUNGAN SISWA', 'App Versi 1.0', 'fa-laptop', 'orange', 'eksternal', 'http://localhost/tabungansiswa'),
(15, 'KARTU PELAJAR', 'App Versi 1.0', 'fa-laptop', 'blue', 'eksternal', '../kartusiswa'),
(16, 'WEBSITE SEKOLAH', 'App Versi 1.0', 'fa-laptop', 'yellow', 'eksternal', 'http://localhost/'),
(17, 'SMS ', 'App Versi 1.0', 'fa-laptop', 'green', 'eksternal', 'http://localhost/sms'),
(18, 'ABSENSI', 'App Versi 1.0', 'fa-laptop', 'yellow', 'eksternal', 'http://localhost/absis'),
(19, 'Skensa Chat', 'Skensa Chat V 1.2', 'fa-comments', 'navy', 'internal', '../chat');

-- --------------------------------------------------------

--
-- Table structure for table `mst_guru`
--

CREATE TABLE `mst_guru` (
  `id_guru` int(11) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `nik` varchar(50) NOT NULL,
  `nuptk` varchar(30) DEFAULT NULL,
  `nama_guru` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') NOT NULL,
  `tempat_lahir` varchar(150) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` enum('ISLAM','KATOLIK','PROTESTAN','HINDU','BUDHA','KONGHUCU') NOT NULL,
  `alamat_jalan` varchar(255) NOT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) NOT NULL,
  `kode_pos` int(10) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `hp` varchar(15) NOT NULL,
  `email` varchar(150) NOT NULL,
  `kewarganegaraan` enum('WNI','WNA') NOT NULL,
  `foto` varchar(255) NOT NULL,
  `id_jabatan` int(11) DEFAULT NULL,
  `aktif_guru` char(1) DEFAULT '1',
  `ttd_image` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_guru`
--

INSERT INTO `mst_guru` (`id_guru`, `nip`, `nik`, `nuptk`, `nama_guru`, `password`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat_jalan`, `rt`, `rw`, `kelurahan`, `kecamatan`, `kode_pos`, `telepon`, `hp`, `email`, `kewarganegaraan`, `foto`, `id_jabatan`, `aktif_guru`, `ttd_image`) VALUES
(1, '1', '1', '1', 'Nana', '1', 'Laki-Laki', 'Jakarta', '1989-01-01', 'PROTESTAN', 'Jakarta', NULL, NULL, 'Jakarta', 'Jakarta', NULL, '021', '021', 'johansmart325@gmail.com', 'WNI', '9b5eced506a33a998192985ce6fdcb24.jpg', 2, '1', 'eb73b17f743ecf1a7b01f9ec157ec4dd.jpg'),
(2, '2', '2', '2', 'Usmiati', '2', 'Perempuan', 'Lumajang', '1985-12-22', 'ISLAM', 'Jl. Mlawang', NULL, NULL, 'Mlawang', 'Klakah', NULL, '03344441221', '085257792111', 'usmiati@gmail.com', 'WNI', '0479c95c8b41e2ca95263487f2118513.png', 2, '1', NULL),
(3, '312313134', '312313134', '312313134', 'Coba deh', '312313134', 'Perempuan', 'di mana aja', '1995-08-17', 'PROTESTAN', 'di mana aja', NULL, NULL, 'di mana aja', 'di mana aja', NULL, '08135654646', '08135654646', 'cobaaja@gmail.com', 'WNI', '0de878b59bc0deb0d477c9c8e64dcc0c.jpg', 2, '1', NULL),
(4, '80280820', '820280820', '11', 'test1', '80280820', 'Laki-Laki', 'jakarta', '2020-12-12', 'ISLAM', 'jakarta', NULL, NULL, 'jakarta', 'jakarta', NULL, '0', '0', 'admin@johansoft.com', 'WNI', '', 2, '1', NULL),
(5, '8208028028', '828282', '72792792792', 'dua', '8208028028', 'Laki-Laki', 'jakarta', '2020-12-12', 'ISLAM', 'aa', NULL, NULL, 'aa', 'aa', NULL, '0', '0', 'admin@johansoft.com', 'WNI', '38df3a0d9be466b08cb17027b0a042ea.png', 2, '1', NULL),
(6, '1212121', '12345678', '878787', 'gurumapelcek', '1212121', 'Laki-Laki', 'a', '2019-05-12', 'ISLAM', 'a', NULL, NULL, 'a', 'a', NULL, '9059045904', '099238938', 'admin@johansoft.com', 'WNI', '4c7316d25613e8a45f29ecae47879a75.jpg', 3, '1', NULL),
(7, '910901901', '9109019091', '9109019019', 'sarjo', '910901901', 'Laki-Laki', 'aa', '2020-12-12', 'ISLAM', 'aa', NULL, NULL, 'aa', 'aa', NULL, '0', '0', 'johansmart325@gmail.com', 'WNI', '4459f29ebdf1a8c6faa27498c22c793f.jpg', 2, '1', NULL),
(8, '308308308', '80380380', '80328038038', 'dania', '308308308', 'Laki-Laki', 'aa', '1970-01-01', 'ISLAM', 'aa', NULL, NULL, 'aa', 'aa', NULL, '0', '0', 'admin@johansoft.com', 'WNI', 'c215abd82ad344b8fd26112ca8335b0b.jpg', 3, '1', NULL),
(9, '80280280', '830803', '802808208', 'nana', '80280280', 'Laki-Laki', 'aa', '1970-01-01', 'ISLAM', 'aa', NULL, NULL, 'aa', 'aa', NULL, '0', '081219309346', 'admin@johansoft.com', 'WNI', 'f6b640b4722bc9f716ef02601825db00.png', 3, '1', NULL),
(10, '100', '100', '100', '100', '100', 'Laki-Laki', 'jakarta', '2020-12-12', 'ISLAM', 'jakarta', NULL, NULL, 'jakarta', 'jakarta', NULL, '1', '1', 'admin@johansoft.com', 'WNI', '', 2, '1', NULL),
(11, '2006001', '', NULL, 'RAHMATULLAH, SH', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(12, '2006002', '', NULL, 'RODHIANY AWALIA IR, S.M', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(13, '2006003', '', NULL, 'HJ. SITI RABIAH, S. Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(14, '2006004', '', NULL, 'THIN Z. F, S.Pd.I', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(15, '2006005', '', NULL, 'MAR\'ATUL AZIZAH, S.Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(16, '2006006', '', NULL, 'DEDE RAHMAT, S. Pd', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(17, '2006007', '', NULL, 'SITI MARDHATILLAH, S. Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(18, '2006008', '', NULL, 'SUTINAH, S. T', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(19, '2006009', '', NULL, 'ALLIYAH UMAH, S. Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(20, '2006010', '', NULL, 'SRI WAHYUNI, S. Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(21, '2006011', '', NULL, 'NUR AFIFAH, S. Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(22, '2006012', '', NULL, 'AMELIA WIDIAWATY, S. Sos', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(23, '2006013', '', NULL, 'ARIF ALAMSYAH', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(24, '2006014', '', NULL, 'Drs. MANSYUR', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(25, '2006015', '', NULL, 'MANARUL IMAM D, S. Kom', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(26, '2006016', '', NULL, 'PUJI LESTARI, A. Md', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(27, '2006017', '', NULL, 'NURDIANA, S. Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(28, '2006018', '', NULL, 'ABDUL JAELANI, S. Kom', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(29, '2006019', '', NULL, 'SAICHU SAIFUDDIN, S. Pd.I', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(30, '2006020', '', NULL, 'SUWANDI YUSUF, S. Pd', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(31, '2006021', '', NULL, 'CARLI RUSLANI, S. Pd', '', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(32, '2006022', '', NULL, 'DEDE HANDAYANI, S. Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(33, '2006023', '', NULL, 'NURUL FATMAH, S.Pd', '', 'Perempuan', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', NULL),
(34, '2006024', '', NULL, 'DODI LAZUARDI, S. Kom', '123456', 'Laki-Laki', '', '0000-00-00', 'ISLAM', '', NULL, NULL, NULL, '', NULL, NULL, '', '', 'WNI', '', 2, '1', 'eb73b17f743ecf1a7b01f9ec157ec4dd.jpg'),
(35, '10000000000', '1000000000', '2000000000', 'Mulyani SPd', '10000000000', 'Perempuan', 'jakarta', '1995-09-12', 'ISLAM', 'a', NULL, NULL, 'a', 'a', NULL, '0927832', '085773685687', 'johansmart325@gmail.com', 'WNI', '6f1485af2a83f096a01df06feaf9e8a7.png', 2, '1', 'eb73b17f743ecf1a7b01f9ec157ec4dd.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mst_informasi_keuangan`
--

CREATE TABLE `mst_informasi_keuangan` (
  `id_informasi` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `gambar` varchar(100) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mst_jabatan`
--

CREATE TABLE `mst_jabatan` (
  `id_jabatan` int(5) NOT NULL,
  `nama_jabatan` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `hak_akses` varchar(25) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_jabatan`
--

INSERT INTO `mst_jabatan` (`id_jabatan`, `nama_jabatan`, `keterangan`, `hak_akses`) VALUES
(2, 'Guru Mapel', '', 'guru'),
(3, 'Guru BK', '', 'gurubk'),
(7, 'Staff TU', '', 'staff'),
(8, 'Administrasi', '', 'kasir'),
(9, 'Admin Akademik', '', 'admin'),
(10, 'Admin Keuangan', '', 'admin'),
(11, 'Bendahara', '', 'bendahara'),
(12, 'Kepala Sekolah', '', 'das'),
(13, 'Wakasek Kesiswaan', '', 'das'),
(14, 'Wakasek Akademik', '', 'das'),
(15, 'Wakasek Sarpas', '', 'das'),
(16, 'Wakasek Humas', '', 'das'),
(17, 'Kapala Kejuruan', '', 'das'),
(18, 'Yayasan Cendikia', '', 'dasview'),
(19, 'Kepala Sekolah (DAS)', '', 'admin'),
(20, 'Admin Perpustakaan', '', 'admin'),
(21, 'Admin Alumni', '', 'admin'),
(22, 'Admin Buku Tamu', '', 'admin'),
(23, 'Admin PPDB', '', 'admin'),
(24, 'Admin Kelulusan', '', 'admin'),
(25, 'Operator', 'operator', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mst_jenis_dokumen`
--

CREATE TABLE `mst_jenis_dokumen` (
  `id_jenis_dokumen` int(11) NOT NULL,
  `nama_jenis_dokumen` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_jenis_dokumen`
--

INSERT INTO `mst_jenis_dokumen` (`id_jenis_dokumen`, `nama_jenis_dokumen`) VALUES
(1, 'Surat Keluar'),
(2, 'Surat Masuk'),
(3, 'Ijazah'),
(0, 'SISWA MUTASI KELUAR'),
(0, 'SISWA MUTASI KELUAR'),
(0, 'SISWA MUTASI KELUAR');

-- --------------------------------------------------------

--
-- Table structure for table `mst_jenis_pembayaran`
--

CREATE TABLE `mst_jenis_pembayaran` (
  `id_jenis_pembayaran` int(11) NOT NULL,
  `id_pos_keuangan` int(11) DEFAULT NULL,
  `tipe_pembayaran` enum('Bulanan','Bebas') DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `aktif_jenis_pembayaran` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_jenis_pembayaran`
--

INSERT INTO `mst_jenis_pembayaran` (`id_jenis_pembayaran`, `id_pos_keuangan`, `tipe_pembayaran`, `tahun_ajaran`, `aktif_jenis_pembayaran`) VALUES
(1, 1, 'Bulanan', '2019/2020', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_jurusan`
--

CREATE TABLE `mst_jurusan` (
  `id_jurusan` int(11) NOT NULL,
  `kode_jurusan` varchar(15) DEFAULT NULL,
  `nama_jurusan` varchar(70) DEFAULT NULL,
  `bidang_keahlian` varchar(70) DEFAULT NULL,
  `kompetensi_umum` varchar(70) DEFAULT NULL,
  `kompetensi_khusus` varchar(70) DEFAULT NULL,
  `pejabat` varchar(70) DEFAULT NULL,
  `jabatan` varchar(70) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `aktif_jurusan` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_jurusan`
--

INSERT INTO `mst_jurusan` (`id_jurusan`, `kode_jurusan`, `nama_jurusan`, `bidang_keahlian`, `kompetensi_umum`, `kompetensi_khusus`, `pejabat`, `jabatan`, `keterangan`, `aktif_jurusan`) VALUES
(4, '6054', 'BISNIS DARING DAN PEMASARAN', 'Bisnis dan Manajemen', 'Bisnis dan Manajemen', 'Bisnin Daring dan Pemasaran', 'abc', 'tinggi', 'manajemen', '1'),
(5, '6018', 'AKUNTANSI KEUANGAN DAN LEMBAGA', NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(6, '2063', 'TEKNIK KOMPUTER DAN JARINGAN', NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(7, 'aa01', 'Rekayasa Perankat', 'rpl', 'programming', 'robotic', 'a1', 'iV', 'test keterangan', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_kategori`
--

CREATE TABLE `mst_kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_kategori`
--

INSERT INTO `mst_kategori` (`id_kategori`, `nama_kategori`) VALUES
(4, 'English1'),
(5, 'Komputer');

-- --------------------------------------------------------

--
-- Table structure for table `mst_kategori_barang`
--

CREATE TABLE `mst_kategori_barang` (
  `id_kategori_barang` int(11) NOT NULL,
  `nama_kategori_barang` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mst_kelas`
--

CREATE TABLE `mst_kelas` (
  `id_kelas` int(11) NOT NULL,
  `kode_kelas` varchar(15) NOT NULL,
  `nama_kelas` varchar(50) NOT NULL,
  `aktif_kelas` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_kelas`
--

INSERT INTO `mst_kelas` (`id_kelas`, `kode_kelas`, `nama_kelas`, `aktif_kelas`) VALUES
(9, '3', '10 PEMASARAN - A', '1'),
(10, '2', '10 AKUNTANSI - B', '1'),
(11, '1', '10 AKUNTANSI - A', '1'),
(12, '4', '10 PEMASARAN - B', '1'),
(13, '5', '10 PEMASARAN - C', '1'),
(14, '6', '11 AKUNTANSI - A', '1'),
(15, '7', '11 AKUNTANSI - B', '1'),
(16, '8', '10 TEKKOMJAR - A', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_kelompok_pelajaran`
--

CREATE TABLE `mst_kelompok_pelajaran` (
  `id_kelompok_pelajaran` int(11) NOT NULL,
  `nama_kelompok_pelajaran` varchar(70) DEFAULT NULL,
  `aktif_kelompok_pelajaran` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_kelompok_pelajaran`
--

INSERT INTO `mst_kelompok_pelajaran` (`id_kelompok_pelajaran`, `nama_kelompok_pelajaran`, `aktif_kelompok_pelajaran`) VALUES
(7, 'A. MUATAN NASIONAL', '1'),
(8, 'B. MUATAN WILAYAH', '1'),
(9, 'C. MUATAN PEMINATAN KEJURUAN', '1'),
(10, 'D. DASAR PROGRAM KEAHLIAN', '1'),
(11, 'E. KOMPETENSI KEAHLIAN', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_kepala_sekolah`
--

CREATE TABLE `mst_kepala_sekolah` (
  `id_kepala_sekolah` int(11) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `nik` varchar(50) NOT NULL,
  `nama_kepala_sekolah` varchar(60) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `foto` varchar(100) NOT NULL,
  `aktif_kepala_sekolah` char(1) DEFAULT '1',
  `id_jabatan` int(11) DEFAULT NULL,
  `ttd_image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_kepala_sekolah`
--

INSERT INTO `mst_kepala_sekolah` (`id_kepala_sekolah`, `nip`, `nik`, `nama_kepala_sekolah`, `password`, `email`, `hp`, `foto`, `aktif_kepala_sekolah`, `id_jabatan`, `ttd_image`) VALUES
(4, '2010070122101990', '35081922101900011', 'Taufik Kurohman, S.Pd.', '2010070122101990', 'taufik@gmail.com', '085257792459', 'e7b7e45e3d90417e9a1d9e99fc57b12e.png', '0', NULL, NULL),
(5, '1230', '1230', 'Coba', '1230', 'Coba@gmail.com', '0821432424', 'e24fe74a6919c8dd631bb03efb17d179.jpg', '0', NULL, NULL),
(6, '2', '2', '2', '2', 'admin@johansoft.com', '1', '29367a484d062a2618ee1df25df977c0.jpg', '0', NULL, NULL),
(7, '99988766', '99864544', 'kepsek', '99988766', 'johansmart325@gmail.com', '085773685687', '', '0', NULL, NULL),
(8, '778899', '121212122123444', 'kepsek baru', '778899', 'johansmart325@gmail.com', '085773685687', '', '0', NULL, NULL),
(9, '8928928', '829892', 'nana', '8928928', 'admin@johansoft.com', '0', '', '0', NULL, NULL),
(10, '9292929', '22', 'jojo', '9292929', 'johansmart325@gmail.com', '0', 'af2b26501a53e0f072a013fd5b7106d4.png', '0', NULL, NULL),
(11, '55667788', '66778899', 'Kepala Sekolah', '55667788', 'johansmart325@gmail.com', '085773685687', '5b5f069b8f2c6aaef12483be7269dfb4.png', '0', NULL, NULL),
(12, '14433221', '1261627', 'Fahyur (Kepala Sekolah)', '14433221', 'johansmart325@gmail.com', '085773685687', 'dcc18080b598cd916281ee437b9e4422.png', '0', NULL, NULL),
(13, '17', '17', 'dodi', '17', 'admin@johansoft.com', '17', '', '0', NULL, NULL),
(14, '1891891', '19109091', 'kepalasekolahcek', '1891891', 'admin@johansoft.com', '082136068256', '7d29313a01933071857dd8563bc862d6.jpg', '0', 19, NULL),
(15, '9393939', '993939', 'irfan', '123456', 'johansmart325@gmail.com', '0', '572d26cac7faa0139a73e02a7f9a50fc.jpg', '0', 19, NULL),
(18, '1267126', '121826712', 'Sutoro, MSi', '1267126', 'johansmart325@gmail.com', '085773685687', 'e14d6480f18cd47633acb4ad628af853.jpg', '0', 19, 'ttd2.png'),
(19, '123344545', '128378237823', 'Panji Suroso, M.Pd', '123344545', 'johansmart325@gmail.com', '085773685687', 'f54b9d7252beb1f2a5e60ac8bee2d639.png', '1', 19, 'b8264f8ad7dd7e1820807e5116e75ff4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mst_lemari`
--

CREATE TABLE `mst_lemari` (
  `id_lemari` int(11) NOT NULL,
  `nama_lemari` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_lemari`
--

INSERT INTO `mst_lemari` (`id_lemari`, `nama_lemari`) VALUES
(2, 'tes');

-- --------------------------------------------------------

--
-- Table structure for table `mst_loker`
--

CREATE TABLE `mst_loker` (
  `id_loker` int(11) NOT NULL,
  `judul_loker` varchar(200) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `gambar` varchar(200) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_loker`
--

INSERT INTO `mst_loker` (`id_loker`, `judul_loker`, `isi`, `gambar`, `tanggal`) VALUES
(1, 'Lowongan Di PT. Austral Byna', 'Dibutuhkan ajsgdhjahsdhasdhasklhfhasifghaiofguoas', '507974aab718764f6b0d1fbaa34af5de.jpg', '2022-02-19 05:57:40');

-- --------------------------------------------------------

--
-- Table structure for table `mst_map`
--

CREATE TABLE `mst_map` (
  `id_map` int(11) NOT NULL,
  `nama_map` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_map`
--

INSERT INTO `mst_map` (`id_map`, `nama_map`) VALUES
(3, '01');

-- --------------------------------------------------------

--
-- Table structure for table `mst_mapel`
--

CREATE TABLE `mst_mapel` (
  `id_mapel` int(11) NOT NULL,
  `id_kelompok_pelajaran` int(11) DEFAULT NULL,
  `kode_mapel` varchar(25) DEFAULT NULL,
  `nama_mapel` varchar(50) DEFAULT NULL,
  `kkm` int(2) DEFAULT NULL,
  `aktif_mapel` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_mapel`
--

INSERT INTO `mst_mapel` (`id_mapel`, `id_kelompok_pelajaran`, `kode_mapel`, `nama_mapel`, `kkm`, `aktif_mapel`) VALUES
(4, 7, 'B1', 'SENI BUDAYA', 100, '1'),
(5, 8, 'A1', 'PENDIDIKAN AGAMA', 78, '1'),
(6, 9, 'C1', 'SIMULASI DAN KOMUNIKASI DIGITAL', 75, '1'),
(7, 10, 'D1', 'ETIKA PROFESI', 70, '1'),
(8, 11, 'E1', 'AKUNTANSI KEUANGAN', 70, '1'),
(9, 9, 'C_PM', 'PM 2', 80, '1'),
(10, 9, 'CTKJ', 'TKJ', 75, '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_merk`
--

CREATE TABLE `mst_merk` (
  `id_merk` int(11) NOT NULL,
  `nama_merk` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mst_pengumuman_alumni`
--

CREATE TABLE `mst_pengumuman_alumni` (
  `id_pengumuman` int(11) NOT NULL,
  `judul_pengumuman` varchar(200) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `gambar` varchar(200) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mst_poin_pelanggaran`
--

CREATE TABLE `mst_poin_pelanggaran` (
  `id_poin_pelanggaran` int(11) NOT NULL,
  `nama_poin_pelanggaran` text DEFAULT NULL,
  `poin` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_poin_pelanggaran`
--

INSERT INTO `mst_poin_pelanggaran` (`id_poin_pelanggaran`, `nama_poin_pelanggaran`, `poin`) VALUES
(1, ' Bolos', 5),
(2, ' Seragam Tidak Sesuai', 5),
(3, ' Berkelahi Disekolah', 25),
(4, ' Tawuran', 50);

-- --------------------------------------------------------

--
-- Table structure for table `mst_pos_keuangan`
--

CREATE TABLE `mst_pos_keuangan` (
  `id_pos_keuangan` int(11) NOT NULL,
  `nama_pos_keuangan` varchar(100) DEFAULT NULL,
  `aktif_pos_keuangan` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_pos_keuangan`
--

INSERT INTO `mst_pos_keuangan` (`id_pos_keuangan`, `nama_pos_keuangan`, `aktif_pos_keuangan`) VALUES
(1, 'SPP', '1'),
(2, 'UJIAN PTS GANJIL', '1'),
(3, 'Daftar Ulang', '1'),
(4, 'PPDB', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_predikat`
--

CREATE TABLE `mst_predikat` (
  `id_predikat` int(11) NOT NULL,
  `dari_nilai` float DEFAULT NULL,
  `sampai_nilai` float DEFAULT NULL,
  `grade` char(1) DEFAULT NULL,
  `keterangan` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_predikat`
--

INSERT INTO `mst_predikat` (`id_predikat`, `dari_nilai`, `sampai_nilai`, `grade`, `keterangan`) VALUES
(1, 1, 74, 'D', 'Kurang'),
(2, 75, 83, 'C', 'Cukup'),
(3, 84, 92, 'B', 'Baik'),
(4, 93, 100, 'A', 'Sangat Baik');

-- --------------------------------------------------------

--
-- Table structure for table `mst_rak`
--

CREATE TABLE `mst_rak` (
  `id_rak` int(11) NOT NULL,
  `nama_rak` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_rak`
--

INSERT INTO `mst_rak` (`id_rak`, `nama_rak`) VALUES
(3, '01');

-- --------------------------------------------------------

--
-- Table structure for table `mst_ruangan`
--

CREATE TABLE `mst_ruangan` (
  `id_ruangan` int(11) NOT NULL,
  `nama_ruangan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_ruangan`
--

INSERT INTO `mst_ruangan` (`id_ruangan`, `nama_ruangan`) VALUES
(3, '01');

-- --------------------------------------------------------

--
-- Table structure for table `mst_sanksi`
--

CREATE TABLE `mst_sanksi` (
  `id_sanksi` int(11) NOT NULL,
  `dari_poin` int(3) DEFAULT NULL,
  `sampai_poin` int(3) DEFAULT NULL,
  `sanksi` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_sanksi`
--

INSERT INTO `mst_sanksi` (`id_sanksi`, `dari_poin`, `sampai_poin`, `sanksi`) VALUES
(1, 10, 29, 'Teguran lisan ke siswa'),
(2, 30, 49, 'Teguran tertulis ke Orang Tua'),
(3, 50, 74, 'Panggilan Orang Tua ke-1 '),
(4, 75, 99, 'Panggilan Orang Tua ke-2, dan siswa disekors selama 3 hari'),
(5, 76, 100, 'Pemanggilan Orang Tua ke-3, dan siswa disekors selama 7 hari'),
(6, 101, 125, 'Pemanggilan Orang Tua ke-4, dan siswa disekors selama 10 hari'),
(7, 126, 150, 'Dikembalikan kepada orang tua (Drop Out).');

-- --------------------------------------------------------

--
-- Table structure for table `mst_sekolah`
--

CREATE TABLE `mst_sekolah` (
  `id` int(11) NOT NULL,
  `nama_sekolah` varchar(100) DEFAULT NULL,
  `npsn` varchar(50) DEFAULT NULL,
  `nss` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kodepos` varchar(15) DEFAULT NULL,
  `no_telepon` varchar(20) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `wa` varchar(100) NOT NULL,
  `fb` varchar(100) NOT NULL,
  `ig` varchar(150) NOT NULL,
  `youtube` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_sekolah`
--

INSERT INTO `mst_sekolah` (`id`, `nama_sekolah`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `website`, `email`, `logo`, `wa`, `fb`, `ig`, `youtube`) VALUES
(1, 'SMKN 1 LEUWIMUNDING', '69944965', '-', 'JL. Raya Parapatan - Rajagaluh KM.02', 'Parungjaya', 'Leuwimunding', 'Majalengka', NULL, '45473', '0878211204641', 'https://asis.leuwimunding.my.id/', 'leuwimundingasis@gmail.com', '2539096b4dfb80fdb7b0fa4afb8c8fab.png', '0878211204641', 'www.facebook.com/', 'www.instagram.com/', 'www.youtube.com/');

-- --------------------------------------------------------

--
-- Table structure for table `mst_siswa`
--

CREATE TABLE `mst_siswa` (
  `id_siswa` int(11) NOT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `nisn` varchar(20) DEFAULT NULL,
  `nama_siswa` varchar(200) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` enum('Islam','Katolik','Protestan','Budha','Hindu','Konghucu') DEFAULT NULL,
  `alamat_jalan` varchar(200) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kode_pos` varchar(15) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `angkatan` varchar(4) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nama_ayah` varchar(50) DEFAULT NULL,
  `pendidikan_ayah` varchar(25) DEFAULT NULL,
  `pekerjaan_ayah` varchar(25) DEFAULT NULL,
  `no_hp_ayah` varchar(15) DEFAULT NULL,
  `nama_Ibu` varchar(50) DEFAULT NULL,
  `pendidikan_ibu` varchar(25) DEFAULT NULL,
  `pekerjaan_ibu` varchar(25) DEFAULT NULL,
  `no_hp_ibu` varchar(15) DEFAULT NULL,
  `nama_wali` varchar(50) DEFAULT NULL,
  `pendidikan_wali` varchar(25) DEFAULT NULL,
  `pekerjaan_wali` varchar(25) DEFAULT NULL,
  `no_hp_wali` varchar(15) DEFAULT NULL,
  `nama_sekolah` varchar(50) DEFAULT NULL,
  `status_sekolah` varchar(15) DEFAULT NULL,
  `alamat_sekolah` varchar(250) DEFAULT NULL,
  `tahun_lulus` varchar(4) DEFAULT NULL,
  `id_jurusan` int(11) DEFAULT NULL,
  `aktif_siswa` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_siswa`
--

INSERT INTO `mst_siswa` (`id_siswa`, `nis`, `nisn`, `nama_siswa`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat_jalan`, `kelurahan`, `kecamatan`, `kode_pos`, `telepon`, `hp`, `email`, `foto`, `angkatan`, `id_kelas`, `password`, `nama_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `no_hp_ayah`, `nama_Ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `no_hp_ibu`, `nama_wali`, `pendidikan_wali`, `pekerjaan_wali`, `no_hp_wali`, `nama_sekolah`, `status_sekolah`, `alamat_sekolah`, `tahun_lulus`, `id_jurusan`, `aktif_siswa`) VALUES
(2, '789', '458101956', 'abdullah', 'Laki-Laki', 'Lumajang', '2007-10-22', 'Islam', 'Jl. Kalipocang', 'Darungan', 'Klakah', NULL, '', '085257792489', '', 'cd1112621139165a97583f4b4a1c58a7.jpg', '2020', 10, '789', 'Adnan', 'SD', 'Tani', '08525779279', 'Siti', 'SMP', 'Tani', '08525779856', '', '', '', '', 'SDN Mlawang 03', 'NEGERI', 'Jl. Dawuhan', '2020', NULL, '1'),
(30, '801', '801', 'ADZRA TARTILAS TAFADA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '801', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(31, '802', '802', 'ALFIYA NUR INSIROH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '802', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(32, '803', '803', 'ALIVIA ANGGRAENI', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '803', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(33, '804', '804', 'AZKY NURIL ILMIYAH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '804', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(34, '805', '805', 'Dinul Qoyimah', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '805', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(35, '806', '806', 'ELLA ANDINI', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '806', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(36, '807', '807', 'Fania Izmi Rofiqoh', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '807', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(37, '808', '808', 'FIRDA FIRNANDA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '808', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(38, '809', '809', 'IRODETUL KARIMAH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '809', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(39, '810', '810', 'IZZA AFKARINA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '810', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(40, '811', '811', 'LULUK IL KOMARIYAH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '811', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(41, '812', '812', 'MAULIDIA PUTRI AZZAHRA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '812', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(42, '814', '814', 'Nur Azizah', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '814', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(43, '815', '815', 'NUR HALIMA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '815', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(44, '816', '816', 'RATNA SULISTYA NINGSIH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '816', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(45, '817', '817', 'REFA AULYA SYAHFA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '817', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(46, '818', '818', 'RODIAH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '818', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(47, '819', '819', 'Shafa Berlian Aisyah', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '819', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(48, '820', '820', 'SILVI MAQVIROH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '820', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(49, '821', '821', 'SITI AISYAH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '821', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(50, '822', '822', 'SITI MUNAWAROH', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '822', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(51, '823', '823', 'SITI RAHAYU', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '823', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(52, '824', '824', 'SRIWAHYU HARTATIK', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '824', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(53, '825', '825', 'Uzlifatil Jannah', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '825', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(54, '826', '826', 'WAHYUDA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '826', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(55, '827', '827', 'YULIANA', 'Laki-Laki', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020', 11, '827', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(56, '0008302579', '0008302579', 'Dian Fitoko', 'Laki-Laki', 'JAKARTA', '2000-02-19', 'Islam', 'KAMAL', 'KALIDERES', 'KALIDERES', NULL, '0000000000', '00000000000', 'MUHAMMAD@GMAIL.COM', NULL, '2020', 9, '12', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 6, '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_slideshow`
--

CREATE TABLE `mst_slideshow` (
  `id_slideshow` int(11) NOT NULL,
  `file_gambar` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_slideshow`
--

INSERT INTO `mst_slideshow` (`id_slideshow`, `file_gambar`) VALUES
(5, '44585c956406393e3eeb3037790577ee.jpg'),
(6, '7019017315d295f6b02790c8053ccbe3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mst_staff`
--

CREATE TABLE `mst_staff` (
  `id_staff` int(11) NOT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nama_staff` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `tempat_lahir` varchar(150) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` enum('ISLAM','KATOLIK','PROTESTAN','HINDU','BUDHA','KONGHUCU') DEFAULT NULL,
  `alamat_jalan` varchar(255) DEFAULT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kode_pos` int(10) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `kewarganegaraan` enum('WNI','WNA') DEFAULT NULL,
  `id_jabatan` int(11) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `aktif_staff` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_staff`
--

INSERT INTO `mst_staff` (`id_staff`, `nip`, `nama_staff`, `password`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat_jalan`, `rt`, `rw`, `kelurahan`, `kecamatan`, `kode_pos`, `telepon`, `hp`, `email`, `kewarganegaraan`, `id_jabatan`, `foto`, `aktif_staff`) VALUES
(7, '55667743434', 'hass', '55667743434', 'Laki-Laki', 'jj', '2020-05-12', 'ISLAM', 'kk', NULL, NULL, 'll', 'hh', NULL, '085654365434', '082136068256', 'pterasalvindo@gmail.com', 'WNI', 25, '4b1026d1a7e3e27f8c85a2638039d693.jpg', '1'),
(8, '36345364', 'stafcek', '1234', 'Laki-Laki', 'a', '1970-01-01', 'ISLAM', 'a', NULL, NULL, 'a', 'a', NULL, '098e3', '082136068256', 'admin@johansoft.com', 'WNI', 7, 'b9a6f376ca296de9a7cd053ea4a89873.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_sumber`
--

CREATE TABLE `mst_sumber` (
  `id_sumber` int(11) NOT NULL,
  `nama_sumber` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_sumber`
--

INSERT INTO `mst_sumber` (`id_sumber`, `nama_sumber`) VALUES
(4, 'Dinas Pendidikan'),
(5, 'Buku Dunia');

-- --------------------------------------------------------

--
-- Table structure for table `mst_surat_aktif_sekolah`
--

CREATE TABLE `mst_surat_aktif_sekolah` (
  `id_surat` int(11) NOT NULL,
  `no_surat` varchar(255) DEFAULT NULL,
  `tanggal_surat` date DEFAULT NULL,
  `no_rek_kjp` varchar(255) DEFAULT NULL,
  `tahun_pelajaran` varchar(255) DEFAULT NULL,
  `id_siswa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_surat_aktif_sekolah`
--

INSERT INTO `mst_surat_aktif_sekolah` (`id_surat`, `no_surat`, `tanggal_surat`, `no_rek_kjp`, `tahun_pelajaran`, `id_siswa`) VALUES
(2, '002/B/Tadika-Mesrah/V/2020', '2020-05-29', '312454364564623252', '2018/2019', 1),
(4, 'test', '2020-05-31', 'test', '2019/2020', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mst_surat_panggilan_siswa`
--

CREATE TABLE `mst_surat_panggilan_siswa` (
  `id_surat_panggilan` int(11) NOT NULL,
  `no_surat_panggilan` varchar(255) DEFAULT NULL,
  `tanggal_surat_panggilan` date DEFAULT NULL,
  `perihal` varchar(255) DEFAULT NULL,
  `id_guru` int(11) DEFAULT NULL,
  `waktu_pertemuan` datetime DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `masalah` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_surat_panggilan_siswa`
--

INSERT INTO `mst_surat_panggilan_siswa` (`id_surat_panggilan`, `no_surat_panggilan`, `tanggal_surat_panggilan`, `perihal`, `id_guru`, `waktu_pertemuan`, `id_siswa`, `masalah`) VALUES
(2, '001/A/Tadika-Mesrah/V/2020', '2020-05-30', 'Kenakalan Remaja', 1, '2020-06-18 13:00:00', 1, 'Merokok di dalam kelas'),
(3, '111/A/Tadika-Mesrah/V/2020', '2020-05-31', 'Kenakalan Remaja', 1, '2020-06-27 13:00:00', 1, 'Merokok di dalam kelas'),
(4, 'test', '2020-05-31', 'test', 1, '2020-05-31 07:11:00', 1, 'test'),
(5, '00000', '2020-06-01', 'Pelanggaran Tata Tertib Sekolah', 1, '2020-06-16 10:11:00', 0, 'siswa membolos pada saat KBM');

-- --------------------------------------------------------

--
-- Table structure for table `mst_tahun_ajaran`
--

CREATE TABLE `mst_tahun_ajaran` (
  `id_tahun_ajaran` int(11) NOT NULL,
  `tahun_ajaran` char(9) DEFAULT NULL,
  `semester` int(1) DEFAULT NULL,
  `aktif_tahun_ajaran` char(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_tahun_ajaran`
--

INSERT INTO `mst_tahun_ajaran` (`id_tahun_ajaran`, `tahun_ajaran`, `semester`, `aktif_tahun_ajaran`) VALUES
(3, '2019/2020', 2, '0'),
(4, '2020/2021', 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `mst_urut`
--

CREATE TABLE `mst_urut` (
  `id_urut` int(11) NOT NULL,
  `nama_urut` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_urut`
--

INSERT INTO `mst_urut` (`id_urut`, `nama_urut`) VALUES
(1, '001'),
(2, '002'),
(3, '003');

-- --------------------------------------------------------

--
-- Table structure for table `mst_user`
--

CREATE TABLE `mst_user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `id_jabatan` int(11) DEFAULT NULL,
  `level` char(1) DEFAULT '1',
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_user`
--

INSERT INTO `mst_user` (`id_user`, `nama`, `username`, `password`, `id_jabatan`, `level`, `foto`) VALUES
(7, 'Admin KASIR', 'kasir', 'kasir', 8, '1', NULL),
(8, 'Admin Akademik', 'akademik', '19112014', 14, '1', NULL),
(9, 'Waka Kesiswaan', 'hendi', '123', 13, '1', NULL),
(10, 'Waka Humas', 'idrus', 'idrus', 16, '1', NULL),
(12, 'Kejuruan', 'kejuruan', 'kejuruan', 17, '1', NULL),
(13, 'Sarpras', 'sarpras', '123', 15, '1', NULL),
(14, 'Bendahara', 'bendahara', '456', 11, '1', NULL),
(16, 'Admin Perpus', 'perpus', '123456', 20, '1', NULL),
(17, 'Admin Alumni', 'alumni', '123456', 21, '1', NULL),
(20, 'Rizkiyatul Hasanah', 'rizki', '12345678', 3, '1', NULL),
(22, 'Ika Fitriah', 'TU', '123456', 7, '1', NULL),
(32, 'hass', 'operator', 'operator', 25, '1', NULL),
(40, 'Guru Piket', 'PIKET', 'PIKET', 22, '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mst_walikelas`
--

CREATE TABLE `mst_walikelas` (
  `id_walikelas` int(11) NOT NULL,
  `id_guru` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mst_walikelas`
--

INSERT INTO `mst_walikelas` (`id_walikelas`, `id_guru`, `id_kelas`, `tahun_ajaran`) VALUES
(7, 1, 9, '2019/2020'),
(8, 2, 10, '2019/2020'),
(9, 34, 16, '2019/2020');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_capaian_hasil_belajar`
--

CREATE TABLE `nilai_capaian_hasil_belajar` (
  `id_nilai_capaian_hasil_belajar` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_tahun_ajaran` int(11) DEFAULT NULL,
  `spiritual_predikat` char(1) DEFAULT NULL,
  `spiritual_deskripsi` text DEFAULT NULL,
  `sosial_predikat` char(1) DEFAULT NULL,
  `sosial_deskripsi` text DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nilai_capaian_hasil_belajar`
--

INSERT INTO `nilai_capaian_hasil_belajar` (`id_nilai_capaian_hasil_belajar`, `id_siswa`, `id_kelas`, `id_tahun_ajaran`, `spiritual_predikat`, `spiritual_deskripsi`, `sosial_predikat`, `sosial_deskripsi`, `tanggal`) VALUES
(1, 1, 9, 3, '9', 'bagus', '9', 'bagus', '2020-06-12 17:37:42'),
(2, 3, 9, 3, '9', 'bagus', '9', 'bagus', '2020-06-12 17:37:42'),
(4, 56, 16, 3, 'A', 'good', 'B', 'boleh', '2020-06-19 14:11:33');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_ekstrakulikuler`
--

CREATE TABLE `nilai_ekstrakulikuler` (
  `id_nilai_ekstrakulikuler` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_tahun_ajaran` int(11) DEFAULT NULL,
  `kegiatan` text DEFAULT NULL,
  `nilai` float DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `tanggal` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nilai_ekstrakulikuler`
--

INSERT INTO `nilai_ekstrakulikuler` (`id_nilai_ekstrakulikuler`, `id_siswa`, `id_kelas`, `id_tahun_ajaran`, `kegiatan`, `nilai`, `deskripsi`, `tanggal`) VALUES
(2, 56, 16, 3, 'futsal', 100, 'good', '2020-06-19 14:11:15');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_harian`
--

CREATE TABLE `nilai_harian` (
  `id_nilai_harian` int(11) NOT NULL,
  `kategori` varchar(200) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `id_jadwal_pelajaran` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nilai_harian`
--

INSERT INTO `nilai_harian` (`id_nilai_harian`, `kategori`, `keterangan`, `tanggal`, `id_jadwal_pelajaran`) VALUES
(6, 'a', 'a', '2020-06-12', 1),
(7, 'matematika', '', '2020-06-13', 2),
(8, 'test', '', '2020-06-19', 3);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_harian_detail`
--

CREATE TABLE `nilai_harian_detail` (
  `id_nilai_harian_detail` int(11) NOT NULL,
  `id_nilai_harian` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `nilai` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nilai_harian_detail`
--

INSERT INTO `nilai_harian_detail` (`id_nilai_harian_detail`, `id_nilai_harian`, `id_siswa`, `nilai`) VALUES
(151, 6, 1, NULL),
(152, 6, 3, NULL),
(154, 8, 56, 100);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_prestasi`
--

CREATE TABLE `nilai_prestasi` (
  `id_nilai_prestasi` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_tahun_ajaran` int(11) DEFAULT NULL,
  `kegiatan` text DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `tanggal` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nilai_prestasi`
--

INSERT INTO `nilai_prestasi` (`id_nilai_prestasi`, `id_siswa`, `id_kelas`, `id_tahun_ajaran`, `kegiatan`, `keterangan`, `tanggal`) VALUES
(51, 1, 9, 3, NULL, NULL, '2020-06-12 17:36:49'),
(52, 3, 9, 3, NULL, NULL, '2020-06-12 17:36:49'),
(54, 56, 16, 3, 'bela diri', 'test', '2020-06-19 14:10:46');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_raport`
--

CREATE TABLE `nilai_raport` (
  `id_nilai_raport` int(11) NOT NULL,
  `id_jadwal_pelajaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `kkm` float DEFAULT NULL,
  `nilai_pengetahuan` float DEFAULT NULL,
  `predikat_pengetahuan` char(1) DEFAULT NULL,
  `deskripsi_pengetahuan` text DEFAULT NULL,
  `nilai_keterampilan` float DEFAULT NULL,
  `predikat_keterampilan` char(1) DEFAULT NULL,
  `deskripsi_keterampilan` text DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nilai_raport`
--

INSERT INTO `nilai_raport` (`id_nilai_raport`, `id_jadwal_pelajaran`, `id_siswa`, `kkm`, `nilai_pengetahuan`, `predikat_pengetahuan`, `deskripsi_pengetahuan`, `nilai_keterampilan`, `predikat_keterampilan`, `deskripsi_keterampilan`, `tanggal`) VALUES
(2, 1, 1, 100, 100, NULL, NULL, 100, NULL, NULL, '2020-06-12 17:37:49'),
(3, 3, 1, 100, 80.3, NULL, NULL, 80, NULL, NULL, '2020-06-12 17:37:49'),
(6, 3, 56, 100, 50, NULL, NULL, 100, NULL, NULL, '2020-06-19 14:12:07');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_uts`
--

CREATE TABLE `nilai_uts` (
  `id_nilai_uts` int(11) NOT NULL,
  `id_jadwal_pelajaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `kkm` int(2) DEFAULT NULL,
  `nilai_pengetahuan` float DEFAULT NULL,
  `nilai_keterampilan` float DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `nilai_uts`
--

INSERT INTO `nilai_uts` (`id_nilai_uts`, `id_jadwal_pelajaran`, `id_siswa`, `kkm`, `nilai_pengetahuan`, `nilai_keterampilan`, `tanggal`) VALUES
(1, 1, 1, 100, 100, 100, '2020-06-12 17:36:01'),
(2, 1, 3, 100, 100, 100, '2020-06-12 17:36:01'),
(4, 3, 56, 100, 100, 100, '2020-06-19 14:10:33');

-- --------------------------------------------------------

--
-- Table structure for table `organisasi`
--

CREATE TABLE `organisasi` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `organisasi`
--

INSERT INTO `organisasi` (`id`, `nama`, `keterangan`, `gambar`) VALUES
(3, 'Music Class', 'Decor ostdcaer urabitur ultrices posuere mattis. Nam ullamcorper, diam sit amet euismod pelleontesque, eros risus rhoncus libero, invest tibulum nisl ligula', '09f8de51cd97016a829a1f46e2565d06.jpg'),
(4, 'Yoga Class', 'Rabitur ultrices posuere mattis. Nam ullamcorper, diam sit euismod pelleo ntesque, eros risus rhoncus libero, invest tibulum nisl gedretu osterftra ligula', '2ec08abb9d6c977f7dd568cbab1ba54c.jpg'),
(5, 'Kung fu Class', 'Curabitur ultrices posuere mattis. Nam ullamcorper, diam sit amet euismod pelleo ntesque, eros risus rhoncus libero, invest tibulum nisl ligula', '7cd0722772411a2a6b9e5943ddf953b3.jpg'),
(6, 'Active Learning', 'Curabitur ultrices posuere mattis. Nam ullamcorper, diam sit amet euismod pelleo ntesque, eros risus rhoncus libero, invest tibulum nisl ligula', 'e6269a6f6f8f1360bb7d8ef79d6a19d5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `tgl_posting` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`id`, `judul`, `isi`, `author`, `tgl_posting`) VALUES
(1, 'Struktur Organisasi', '<p><img alt=\"\" src=\"/supercms/asset/plugins/kcfinder/upload/images/Struktur%20Organisasi.png\" style=\"height:290px; width:1039px\" /></p>\r\n', 'admin', '2016-05-09'),
(2, 'Visi dan Misi', '<h2 style=\"text-align:center\"><strong>VISI</strong></h2>\r\n\r\n<h2 style=\"text-align:center\"><strong>MENJADI SEKOLAH ISLAMI DAN UNGGUL</strong></h2>\r\n\r\n<h2 style=\"text-align:center\"><strong>MISI</strong></h2>\r\n\r\n<div style=\"background:transparent; border:0px; padding:0px; text-align:center\">Mewujudkan nilai-nilai islam melalui penyelenggaraan sekolah.</div>\r\n\r\n<div style=\"background:transparent; border:0px; padding:0px; text-align:center\">Menumbuhkan kesadaran siswa untuk mengaplikasikan nilai-nilai islam dalam kehidupan sehari-hari</div>\r\n\r\n<div style=\"background:transparent; border:0px; padding:0px; text-align:center\">Menumbuhkan semangat membaca dan menghafal Al Qur&rsquo;an.</div>\r\n\r\n<div style=\"background:transparent; border:0px; padding:0px; text-align:center\">Melaksanakan pembelajaran dan bimbingan yang islami secara efektif sehingga setiap siswa berkembang secara optimal sesuai dengan potensi yang dimiliki.</div>\r\n\r\n<div style=\"background:transparent; border:0px; padding:0px; text-align:center\">Menumbuhkan semangat siswa untuk berkompetisi dan berdaya saing</div>\r\n\r\n<div style=\"background:transparent; border:0px; padding:0px; text-align:center\">Menumbuhkan semangat keunggulan secara intensif kepada seluruh warga sekolah</div>\r\n', 'admin', '2016-05-09'),
(3, 'Profil Singkat', '<p style=\"text-align:justify\"><strong>Profil Sekolah SDIT Permata Bunda II</strong></p>\r\n\r\n<p style=\"text-align:justify\">SDIT Permata Bunda II adalah SIT ( Sekolah Islam Terpadu ) pertama yang berada di kecamatan Teluk Betung Selatan. SDIT Permata Bunda II berdiri sejak tanggal 12 Juli 2010 dan merupakan cabang dari SDIT Permata Bunda I Rajabasa. Sekolah ini sudah mendapat izin operasional sejak tahun 2012 dan mendapatkan Bantuan Operasional Sekolah (BOS) pada tahun 2013.</p>\r\n\r\n<p style=\"text-align:justify\">Latar belakang didirikan sekolah ini adalah untuk memenuhi kebutuhan masyarakat yang berdomilisi di wilayah Teluk dan sekitarnya yang ingin menyekolahkan anaknya di Sekolah Islam Terpadu (SIT).</p>\r\n\r\n<p style=\"text-align:justify\">SDIT Permata Bunda II berada di lokasi yang strategis, sangat dekat dengan pusat kota dan perkantoran, walaupun belum ada akses fasilitas kendaraan umum yang melintas dijalan sekitar sekolah. Animo masyarakat untuk menyekolahkan anaknya di SDIT Peramata Bunda II sangat tinggi. Hal ini terbukti dengan meningkatnya pendaftaran calon siswa baru di setiap tahunnya.</p>\r\n\r\n<p style=\"text-align:justify\">Saat ini, SDIT Permata Bunda II sudah memasuki tahun ke- 5, dan sudah ada 5 jenjang kelas dan mulai meluluskan siswa kelas VI ditahun 2016</p>\r\n\r\n<p style=\"text-align:justify\"><strong>&ldquo; Menjadi Sekolah Islami Dan Unggul&rdquo;</strong>&nbsp;menjadi visi sekolah saat ini, dan harapannya bias menjadi ruh seluruh warga sekolah untuk selalu menjadi sekolah islami dan unggul. Sekolah masih dalam kondisi pembangunan yang dilaksanakan secara bertahap, sudah banyak prestasi sekolah yang diraih, baik dari tingkat kecamatan, kabupaten, hingga tingkat propinsi, dalam bidang akademik, pidato, tahfidz, olahraga, dan seni.</p>\r\n\r\n<p style=\"text-align:justify\">Program unggulan di SDIT Permata Bunda II adalah program Tahsin- Tahfidz dengan target bias membaca alquran dengan baik dan benar dan hafalan 2 juz (juz 29 dan 30).</p>\r\n', 'admin', '2016-05-09');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggaran_siswa`
--

CREATE TABLE `pelanggaran_siswa` (
  `id_pelanggaran_siswa` int(11) NOT NULL,
  `id_poin_pelanggaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) NOT NULL,
  `poin_minus` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `id_absen` int(11) DEFAULT NULL,
  `id_penginput` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pelanggaran_siswa`
--

INSERT INTO `pelanggaran_siswa` (`id_pelanggaran_siswa`, `id_poin_pelanggaran`, `id_siswa`, `id_kelas`, `poin_minus`, `tanggal`, `tahun_ajaran`, `id_absen`, `id_penginput`) VALUES
(1, 1, 2, 10, 5, '2021-08-20', '2020/2021', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_bebas`
--

CREATE TABLE `pembayaran_bebas` (
  `id_pembayaran_bebas` int(11) NOT NULL,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `tagihan` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pembayaran_bebas`
--

INSERT INTO `pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`) VALUES
(1, 1, 1, 9, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_bebas_dt`
--

CREATE TABLE `pembayaran_bebas_dt` (
  `id_pembayaran_bebas_dt` int(11) NOT NULL,
  `id_pembayaran_bebas` int(11) DEFAULT NULL,
  `bayar` float DEFAULT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_bulanan`
--

CREATE TABLE `pembayaran_bulanan` (
  `id_pembayaran_bulanan` int(11) NOT NULL,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `bulan` varchar(15) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `bayar` float DEFAULT 0,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pembayaran_bulanan`
--

INSERT INTO `pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`) VALUES
(1, 1, 1, 9, 'Juli', 200000, 0, '0000-00-00'),
(2, 1, 1, 9, 'Agustus', 200000, 0, '0000-00-00'),
(3, 1, 1, 9, 'September', 200000, 0, '0000-00-00'),
(4, 1, 1, 9, 'Oktober', 200000, 0, '0000-00-00'),
(5, 1, 1, 9, 'November', 200000, 0, '0000-00-00'),
(6, 1, 1, 9, 'Desember', 200000, 0, '0000-00-00'),
(7, 1, 1, 9, 'Januari', 200000, 0, '0000-00-00'),
(8, 1, 1, 9, 'Febuari', 200000, 0, '0000-00-00'),
(9, 1, 1, 9, 'Maret', 200000, 0, '0000-00-00'),
(10, 1, 1, 9, 'April', 200000, 0, '0000-00-00'),
(11, 1, 1, 9, 'Mei', 200000, 0, '0000-00-00'),
(12, 1, 1, 9, 'Juni', 200000, 200000, '2020-06-01');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman_buku`
--

CREATE TABLE `peminjaman_buku` (
  `id_peminjaman` int(11) NOT NULL,
  `no_peminjaman` varchar(15) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `status_input` char(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `peminjaman_buku`
--

INSERT INTO `peminjaman_buku` (`id_peminjaman`, `no_peminjaman`, `id_siswa`, `id_kelas`, `status_input`) VALUES
(3, 'NP.210821.001', 56, 9, '1'),
(5, 'NP.210821.002', 56, 9, '1');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman_buku_dt`
--

CREATE TABLE `peminjaman_buku_dt` (
  `id_peminjaman_dt` int(11) NOT NULL,
  `id_peminjaman` int(11) DEFAULT NULL,
  `id_buku` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `tanggal_pinjam` date DEFAULT NULL,
  `tanggal_kembali` date DEFAULT NULL,
  `durasi` int(11) DEFAULT NULL,
  `tanggal_kembali_asli` date DEFAULT NULL,
  `telat` int(11) DEFAULT NULL,
  `denda` float DEFAULT NULL,
  `status_input_dt` char(1) DEFAULT '0',
  `status_pinjam_dt` char(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `peminjaman_buku_dt`
--

INSERT INTO `peminjaman_buku_dt` (`id_peminjaman_dt`, `id_peminjaman`, `id_buku`, `jumlah`, `tanggal_pinjam`, `tanggal_kembali`, `durasi`, `tanggal_kembali_asli`, `telat`, `denda`, `status_input_dt`, `status_pinjam_dt`) VALUES
(3, 3, 2, 1, '2021-08-21', '2021-08-23', 2, NULL, NULL, NULL, '1', '0'),
(5, 5, 1, 1, '2021-08-21', '2021-08-23', 2, NULL, NULL, NULL, '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman_piket`
--

CREATE TABLE `peminjaman_piket` (
  `id_peminjaman_piket` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `keterangan_pinjam` text DEFAULT NULL,
  `tanggal_pinjam` date DEFAULT NULL,
  `tahun_ajaran` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman_siswa`
--

CREATE TABLE `peminjaman_siswa` (
  `id_peminjaman_siswa` int(11) NOT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `keterangan_pinjam` text DEFAULT NULL,
  `tanggal_pinjam` date DEFAULT NULL,
  `tahun_ajaran` varchar(10) DEFAULT NULL,
  `id_penginput` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `penerimaan`
--

CREATE TABLE `penerimaan` (
  `id_penerimaan` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `jumlah` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan_kelulusan`
--

CREATE TABLE `pengaturan_kelulusan` (
  `id` int(11) NOT NULL,
  `banner_header` varchar(150) NOT NULL,
  `tanggal_pengumuman` datetime DEFAULT NULL,
  `tahun` varchar(5) DEFAULT NULL,
  `informasi_kelulusan` text NOT NULL,
  `informasi_lain` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pengaturan_kelulusan`
--

INSERT INTO `pengaturan_kelulusan` (`id`, `banner_header`, `tanggal_pengumuman`, `tahun`, `informasi_kelulusan`, `informasi_lain`) VALUES
(1, '8196a77a4e3ad335d28efe136d00c1ce.png', '2021-08-23 12:13:00', '2021', '<a href=\"https://www.youtube.com\">Disini</a>', 'Contohasasa');

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan_perpus`
--

CREATE TABLE `pengaturan_perpus` (
  `id` int(11) NOT NULL,
  `denda` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pengaturan_perpus`
--

INSERT INTO `pengaturan_perpus` (`id`, `denda`) VALUES
(1, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `jumlah` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id_pengumuman` int(11) NOT NULL,
  `judul` varchar(80) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `gambar` varchar(100) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pengumuman`
--

INSERT INTO `pengumuman` (`id_pengumuman`, `judul`, `isi`, `gambar`, `tanggal`) VALUES
(5, 'Tes Informasi Pengumuman', 'ini bagian deskripsi\r\nini deskripsi sebelum gambar', '8bdeafeb00a515fc88faa5778a5f8885.jpg', '2020-03-08 05:31:03'),
(6, 'Tes no Gambar', 'oke lah kalau begitu', NULL, '2020-03-08 05:49:58');

-- --------------------------------------------------------

--
-- Table structure for table `pengunjung_perpus`
--

CREATE TABLE `pengunjung_perpus` (
  `id_pengunjung` int(11) NOT NULL,
  `nis` varchar(25) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `keperluan` varchar(80) DEFAULT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pengunjung_perpus`
--

INSERT INTO `pengunjung_perpus` (`id_pengunjung`, `nis`, `id_kelas`, `keperluan`, `tanggal`) VALUES
(1, '0008302579', 9, 'Pinjam Buku', '2021-08-21 05:06:27');

-- --------------------------------------------------------

--
-- Table structure for table `pesan_admin`
--

CREATE TABLE `pesan_admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subjek` varchar(250) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `tgl_kirim` date DEFAULT NULL,
  `baca` enum('Y','N') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

CREATE TABLE `photo` (
  `id` int(11) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `tgl_upload` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `tgl_posting` date DEFAULT NULL,
  `visited` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `judul`, `isi`, `author`, `gambar`, `id_kategori`, `tgl_posting`, `visited`) VALUES
(5, 'Activities Improves Mind', '<p>Roin bibendum nibhsds. Nuncsdsd fermdada msit ametadasd consequat. Praes porr nulla sit amet dui lobortis, id venenatis nibh accums. Proin lobortis tempus odio eget venenatis. Proin fermentum ut massa at bibendum. Proin bibendum non est quis egestas. Pellentesque at enim id enim tempus placerat. Etiam tempus gravida leo, et gravida justo bibendum non. Suspendisse vitae fermentum sapien.</p>\r\n', 'admin', 'af8a9fed4ae770914e7a8133f555baf4.jpg', 1, '2016-04-30', '12'),
(6, 'MUNAQOSAH HIFZIL QURAN', '<p>SDIT Permata Bunda II mengadakan MUNAQOSAH HIFZIL QURAN JUZ 30 &nbsp;yang dilaksanakan pada pada hari Sabtu tanggal 5 Maret dan 12 Maret 2016 kemarin, dengan jumlah peserta 108 siswa yang terdiri dari &nbsp;siswa-siswi&nbsp; kelas 3, 4, 5, dan 6 &nbsp;yang mengajukan diri mengikuti munaqosah melalui pendaftaran yang dilakukan oleh panitia munaqosah.</p>\r\n\r\n<p>Sudah menjadi salah satu target kelulusan sekolah bahwa siswa-siswi SDIT Permata Bunda bisa memiliki hafalan Quran sebanyak 2 juz yaitu juz 29 dan juz 30 setelah mereka lulus&nbsp; dengan kualitas hafalan yang baik. Namun untuk mencapai itu semua tidaklah mudah, diperlukan program yang mendukung serta kerjasama yang baik antara guru dan orangtua di rumah.</p>\r\n\r\n<p>Salah satu program yang digulirkan sekolah dalam rangka menjaga &nbsp;hafalan yang sudah dicapai siswa-siswi SDIT Permata Bunda II adalah Munaqosah Hifzil Quran Juz 30.&nbsp; Dalam kegiatan munaqosah ini peserta akan diuji hafalannya mulai dari surat An Naas sampai surat An Naba oleh dua orang guru penguji. Nilai minimum kelulusan munaqosah adalah 75 dari seluruh rata-rata nilai ujian hafalan juz 30 yang diambil dengan predikat&nbsp;<em>jayyid</em>&nbsp;sedang nilai tertinggi mendapat predikat&nbsp;<em>mumtaz</em>. Siswa yang &nbsp;mendapat nilai di bawah 75 maka dinyatakan tidak lulus dan diharuskan mengikuti munaqosah periode berikutnya.</p>\r\n\r\n<p>Orangtua siswa dalam kegiatan ini juga diajak kerjasama dengan membimbing dan memotivasi putra-putrinya untuk mengulang-ulang hafalan juz 30 di rumah yang &nbsp;dikontrol melalui kartu kendali yang dibagikan dari sekolah. Sehingga siswa benar-benar mempersiapkan dengan baik hafalan Qurannya sebelum mengikuti munaqosah.</p>\r\n', 'admin', 'dc8b43062cd9a67924955aec6d7bb361.jpg', 1, '2016-05-02', '15'),
(7, '4 LANGKAH CARA CEPAT BELAJAR MEMBACA AL QURAN', '<h3><span style=\"font-size:13px; line-height:1.6em\">Adalah luar biasa, jika Anda mau membaca artikel Cara Cepat Belajar Membaca Al Quran ini. Tahukah Anda, 60% penduduk Indonesia masih belum bisa membaca Al Quran. Miris memang, padahal Indonesia adalah negara Muslim terbesar di dunia.</span></h3>\r\n\r\n<p>Anda tidak perlu malu, jika saat ini masih belum bisa membaca Al Quran, selama Anda masih mau belajar. Yang perlu malu adalah mereka yang tidak punya niat dalam hatinya mau belajar membaca al Quran. Membuka facebook setiap hari, tepi membuka al Quran begitu jarangnya. Membeli hand phone mahal bisa, membuku Al Quran dan buku cara membaca Al Quran begitu berat.</p>\r\n\r\n<p>Kenapa?</p>\r\n\r\n<p>Niat yang tidak ada. Saya yakin, jika ada niat, dia akan mampu.</p>\r\n\r\n<p>Saya yakin, jika Anda membaca artikel ini, Anda punya niat untuk bisa membaca Al Quran atau punya niat ingin mengajarkan membaca Al Quran. Saya menghargai niat Anda. Baik Anda yang mau belajar atau Anda mau mengajarkan kepada orang lain, maka langkah pertama yang perlu kita tanamkan ke hati orang yang mau belajar adalah memiliki niat yang kuat. Dan terpenting, niat yang ikhlas karena Allah semata.</p>\r\n\r\n<h3>Langkah Kedua Cara Cepat Belajar Membaca Al Quran Adalah Memahami Kebaikannya</h3>\r\n\r\n<p>Mungkin, motivasi orang yang kecil untuk belajar membaca al Quran adalah karena belum memahami kebaikan yang akan dia dapatkan jika mau membaca Al Quran.</p>\r\n\r\n<p>Coba kita simak, beberapa hadist yang menjelaskan kebaikan yang akan didapatkan bagi pembaca Al Quran:</p>\r\n\r\n<p>Sabda Nabi Muhammad saw: &ldquo;<em>Sebaik-baik kalian adalah siapa yang memperlajari al-Qur&rsquo;an dan mengamalkannya</em>.&rdquo; (HR. Bukhari)</p>\r\n\r\n<p>Sabda Nabi Muhammad saw: &ldquo;<em>Siapa saja membaca satu huruf dari Kitab Allah (Al-Qur&rsquo;an), maka baginya satu kebaikan, dan satu kebaikan itu dibalas dengan sepuluh kali lipatnya</em>.&rdquo; (HR. At-Tirmidzi).</p>\r\n\r\n<p>Sabda Nabi Muhammad saw: &ldquo;<em>Perumpamaan orang yang membaca al-Qur&rsquo;an sedang ia hafal dengannya bersama para malaikat yang suci dan mulia, sedang perumpamaan orang yang membaca al-Qur&rsquo;an sedang ia senantiasa melakukannya meskipun hal itu sulit baginya maka baginya dua pahala</em>.&rdquo; (Muttafaq &lsquo;alaih).</p>\r\n\r\n<p>&ldquo;<em>Siapa saja membaca al-Qur&rsquo;an, mempelajarinya dan mengamalkannya, maka dipakaikan kepada kedua orang tuanya pada hari kiamat mahkota dari cahaya dan sinarnya bagaikan sinar matahari, dan dikenakan pada kedua orang tuanya dua perhiasan yang nilainya tidak tertandingi oleh dunia. Keduanya pun bertanya, &lsquo;bagaimana dipakaikan kepda kami semuanya itu?&rsquo; Dijawab, &lsquo;karena anakmu telah membawa al-Qur&rsquo;an</em>&rdquo;. (HR. Al-Hakim).</p>\r\n\r\n<p>Sabda Nabi Muhammad saw: &ldquo;<em>Bacalah al-Qur&rsquo;an karena ia akan datang pada hari kiamat sebagai pemberi syafa&rsquo;at kepada para ahlinya</em>.&rdquo; (HR. Muslim) Dan sabda beliau Nabi Muhammad saw: &ldquo;<em>Puasa dan Al-Qur&rsquo;an keduanya akan memberikan syafa&rsquo;at kepada seorang hamba pada hari kiamat</em>&hellip;&rdquo; (HR. Ahmad dan Al-Hakim).</p>\r\n\r\n<p>Dan masih banyak lagi, baik Hadist maupun ayat Al Quran yang jika dibahas semua disini akan sangat panjang. Saya cukupkan dulu beberapa hadist yang sudah menggambarkan bagaimana manfaat dari membaca Al Quran.</p>\r\n\r\n<p>Nah, ingat-ingat manfaat ini, hujamkan dalam hati supaya kita mendapatkannya.</p>\r\n\r\n<p>Bukan karena malu, bukan karena ini mendapatkan pujian, tetapi karena ingin mendapatkan balasan dan ridha Allah semata.</p>\r\n\r\n<p>Malu harus. Tapi bukan malu kepada manusia, tetapi malu kepada Allah dimana kita diberikan mata, kemampuan membaca, dan kemampuan secara ekonomi (semua itu nikmat dari Allah) tapi masih belum bisa membaca Al Quran.</p>\r\n\r\n<h3>Langkah Ketiga: Luangkan Waktu Yang Cukup</h3>\r\n\r\n<p>Ironis memang, mengapa banyak orang yang &ldquo;tidak punya waktu&rdquo; untuk belajar membaca al Quran. Padahal waktu yang kita miliki adalah nikmat dari Allah tetapi begitu sulit menyisihkan waktu untuk belajar membaca Al Quran.</p>\r\n\r\n<p>Mungkin Anda berkata, saya membutuhkan metode Cara Cepat Belajar Membaca Al Quran karena waktu saya yang sempit. Ya, tentu saja.</p>\r\n\r\n<p>Mari kita renungkan, waktu milik Allah, diri kita milik Allah, tapi mengapa waktu untuk membaca kalam Allah begitu sulit?</p>\r\n\r\n<p>OK, nanti kita akan bahas cara atau metode agar kita bisa belajar secara cepat. Namun yang terpenting adalah, apakah setelah bisa nanti ada waktu untuk membacanya secara rutin?</p>\r\n\r\n<p>Sebenarnya, bukan tidak ada waktu. Tapi, sejauh mana Anda memprioritaskan hal ini. Jika Anda masih mengatakan tidak ada waktu untuk belajar dan membaca Al Quran, artinya aktivitas lain jauh lebih penting. Sebenarnya&nbsp;<a href=\"http://www.motivasi-islami.com/anda-punya-waktu/\" target=\"_blank\">Anda punya waktu</a>.</p>\r\n\r\n<p>Anda akan lebih cepat pintar atau pandai membaca Al Quran jika waktu yang dialokasikan cukup. Semakin banyak waktu yang dialokasikan, akan semakin cepat lancar atau fasih.</p>\r\n\r\n<h3>Langkah Keempat: Gunakan Metode Cara Cepat Membaca Al Quran</h3>\r\n\r\n<p>Perkembangan teknologi dan ilmu pengetahuan saat ini, sangat memungkinkan untuk melahirkan sebuah metode atau cara yang mempercepat proses belajar membaca. Saya tidak menafikan metode lama, yang saya lakukan waktu masih kecil dulu. Terbukti efektif dan hasilnya cukup melekat.</p>\r\n\r\n<p>Kita juga tidak perlu alergi dengan metode baru, hasil pengembangan ilmu pengetahuan dan teknologi yang memungkinkan kita bisa belajar dengan cepat. Sekarang sudah banyak dikembangkan teknik, cara, metode&nbsp; atau apa pun namanya yang bisa mempermudah cara kita belajar membaca Al Quran.</p>\r\n\r\n<p>Salah satu yang fenomenal adalah metode Iqra. Kemudian dikembangkan lagi menjadi berbagai metode lagi seperti metode Ummi dan metode Albana. Semuanya untuk mempermudah (bukan menyulitkan) umat Islam untuk membaca Al Quran. Kenapa harus alergi?</p>\r\n\r\n<p>Menurut sepengetahuan saya, metode Iqra, Albana, dan Ummi adalah sebuah metode yang memberikan penanaman kebiasaan yang baik dan benar dalam membaca Al Quran. Hasilnya luar biasa, banyak sekolah yang sudah menerapkan metode ini. Anak saya di sekolahnya menggunakan metode Ummi.</p>\r\n\r\n<p>Termasuk yang terbaru adalah metode Rubaiyat. Agak berbeda dengan metode sebelumnya yang fokus menanamkan kebiasaan dan konsistensi, metode Rubaiyat adalah fokusnya pada kecepatan dan kemudahan untuk segera bisa membaca. Nah, jika Anda orang dewasa yang cukup sibuk, metode ini cocok untuk Anda.</p>\r\n\r\n<p>Metode Rubaiyat sudah diuji selama 15 tahun dan baru diluncurkan beberapa tahun ini, bisa menjadi alternatif bagi Anda yang sibut dan ingin cepat bisa membaca Al Quran. Keunggulan lainnya adalah Anda bisa belajar secara mandiri.</p>\r\n\r\n<p>Memang, tidak akan langsung lancar dan fasih benar. Target utamanya adalah bisa dulu. Tentu harus dilanjutkan belajarnya dengan tahsin agar bacaanya tartil, tapi bukan ini tujuan utama metode rubaiyat. Jika Anda mau menggunakan metode rubaiyat, Anda bisa belajar mandiri dengan buku dan video yang bisa Anda putar di rumah.</p>\r\n\r\n<p>Anda bisa memesan&nbsp;<a href=\"http://www.langitcerah.com/buku-rubaiyat.html\" target=\"_blank\">Buku dan DVD Metode Rubaiyat disini</a>&nbsp;jika mau.</p>\r\n\r\n<h3>Penutup</h3>\r\n\r\n<p>Rasulullah saw bersabda: &ldquo;<em>Barang siapa yang membaca satu huruf kitab Allah, maka ia akan mendapatkan satu kebaikan dengan huruf itu, dan satu kebaikan akan dilipatgandakan menjadi sepuluh. Aku tidaklah mengatakan Alif Laam Miim itu satu huruf, tetapi alif satu huruf, lam satu huruf dan Mim satu huruf</em>.&rdquo; (HR. Tirmidzi).</p>\r\n\r\n<p>Bagi yang sudah biasa membaca Al Quran, pertahankan dan tingkatkan. Bagi yang belum biasa, yuk biasakan. Bagi yang belum bisa, yuk kita mulai belajar membaca al Quran.</p>\r\n\r\n<p>Mudah-mudahan artikel 4 Langkah Cara Cepat Belajar Membaca Al Quran ini bermanfaat untuk Anda.</p>\r\n', 'admin', '11af7e5efab467a51663c8f557956237.jpg', 2, '2016-05-02', '0'),
(8, 'Kegiatan Sholat Berjamaah ', '<p>Shalat berjamaah merupakan syiar Islam yang sangat agung, menyerupai shafnya malaikat ketika mereka beribadah, dan ibarat pasukan dalam suatu peperangan. Ia merupakan sebab terjadinya saling mencintai sesama muslim, saling mengenal, saling mengasihi, saling menyayangi, menampakkan kekuatan, dan kesatuan.</p>\r\n\r\n<p>Alhamdulillah sholat berjamaah menjadi agenda penting dan utama di SDIT Permata Bunda II. Shalat berjamaah menjadi bagian dari alur belajar sekolah yang dilaksanakan di seluruh jenjang kelas. Bagi siswa kelas bawah (kelas 1, 2, dan 3), mereka melakukan shalat berjamaah di kelas, dengan dibimbing oleh dua guru kelas. Setiap siswa diwajibkan membawa perlengkapan sholat sendiri dan bertanggung jawab untuk merapikan kembali perlengkapan shalatnya sendiri.</p>\r\n\r\n<p>Untuk siswa kelas atas (kelas 4, 5, dan6), mereka mulai dibiasakan untuk melaksanakan shalat berjamah di masjid bersama bapak dan ibu guru. Kebiasaan untuk tertib saat di masjid sudah dimulai dari mereka berjalan menuju masjid, meletakkan sepatu/sandal dengan rapi, masuk masjid, berwudu, dan di dalam masjid. Seluruh siswa menerapkan &quot;silent operation&quot; yaitu bersikap tenang dan tidak banyak bicara saat beraktivitas di masjid baik&nbsp; dalam persiapan shalat maupun sesudah shalat.</p>\r\n\r\n<p>Shalat berjamaah diharapkan dapat membangun karakter siswa menjadi manusia yang disiplin,tertib, bertanggung jawab, dan berakhlak mulia Insyaallah.</p>\r\n', 'admin', '0fd559cb48d2df65cca8f0ca2a801e6f.jpg', 1, '2016-05-02', '0'),
(9, 'Sisg', '<p>sgsg</p>\r\n', 'admin', 'f00bd74069bd2dc6642c8abda559d975.jpg', 1, '2016-05-10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ppdb_banner`
--

CREATE TABLE `ppdb_banner` (
  `id_banner` int(11) NOT NULL,
  `file_gambar` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ppdb_banner`
--

INSERT INTO `ppdb_banner` (`id_banner`, `file_gambar`) VALUES
(4, '5ec43f10a825cb006f98131b1549cd05.jpg'),
(5, 'fcde425e833c1cf8c090189ade274782.jpg'),
(6, '736c4064b971fc192b8337419dee7db9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ppdb_kelulusan`
--

CREATE TABLE `ppdb_kelulusan` (
  `id_kelulusan` int(11) NOT NULL,
  `no_ujian` varchar(25) DEFAULT NULL,
  `nama_siswa` varchar(100) DEFAULT NULL,
  `nilai_tpa` varchar(5) DEFAULT NULL,
  `nilai_tpd` varchar(5) DEFAULT NULL,
  `keterangan` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ppdb_kelulusan`
--

INSERT INTO `ppdb_kelulusan` (`id_kelulusan`, `no_ujian`, `nama_siswa`, `nilai_tpa`, `nilai_tpd`, `keterangan`) VALUES
(3, '4-19-12-01-0160-0001-8', 'ADELIA SUKMAWATI', '70', '70', 'LULUS'),
(4, '4-19-12-01-0160-0002-7', 'AFIFA OCTIARA', '89', '89', 'TIDAK LULUS');

-- --------------------------------------------------------

--
-- Table structure for table `ppdb_pengaturan`
--

CREATE TABLE `ppdb_pengaturan` (
  `id` int(11) NOT NULL,
  `banner_header` varchar(150) DEFAULT NULL,
  `tentang` text DEFAULT NULL,
  `prosedur` varchar(250) DEFAULT NULL,
  `pengumuman` char(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ppdb_pengaturan`
--

INSERT INTO `ppdb_pengaturan` (`id`, `banner_header`, `tentang`, `prosedur`, `pengumuman`) VALUES
(1, '800e9f8e5750f50d1a5e104a3f599917.png', 'INFO PPDB', 'd5ea929f708c316acabc72ee02ecd77a.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `ppdb_siswa`
--

CREATE TABLE `ppdb_siswa` (
  `id_ppdb` int(11) NOT NULL,
  `no_pendaftaran` varchar(30) DEFAULT NULL,
  `nik` varchar(25) DEFAULT NULL,
  `jenis_pendaftaran` varchar(25) DEFAULT NULL,
  `jalur_pendaftaran` varchar(25) DEFAULT NULL,
  `hobi` varchar(55) DEFAULT NULL,
  `cita_cita` varchar(55) DEFAULT NULL,
  `nama_siswa` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(15) DEFAULT NULL,
  `tempat_lahir` varchar(55) DEFAULT NULL,
  `tanggal_lahir` varchar(15) DEFAULT NULL,
  `agama` varchar(15) DEFAULT NULL,
  `alamat` varchar(155) DEFAULT NULL,
  `rt` varchar(4) DEFAULT NULL,
  `rw` varchar(4) DEFAULT NULL,
  `dusun` varchar(55) DEFAULT NULL,
  `kelurahan` varchar(55) DEFAULT NULL,
  `kabupaten` varchar(55) DEFAULT NULL,
  `kode_pos` varchar(15) DEFAULT NULL,
  `tempat_tinggal` varchar(55) DEFAULT NULL,
  `transportasi` varchar(15) DEFAULT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `kewarganegaraan` varchar(15) DEFAULT NULL,
  `foto` varchar(155) DEFAULT NULL,
  `tinggi_badan` varchar(3) DEFAULT NULL,
  `berat_badan` varchar(3) DEFAULT NULL,
  `jarak_ke_sekolah` varchar(4) DEFAULT NULL,
  `waktu_tempuh_ke_sekolah` varchar(4) DEFAULT NULL,
  `jumlah_saudara` varchar(2) DEFAULT NULL,
  `asal_sekolah` varchar(255) NOT NULL,
  `alamat_sekolah_asal` varchar(255) NOT NULL,
  `nama_ayah` varchar(55) DEFAULT NULL,
  `tahun_lahir_ayah` varchar(4) DEFAULT NULL,
  `pendidikan_ayah` varchar(15) DEFAULT NULL,
  `pekerjaan_ayah` varchar(55) DEFAULT NULL,
  `penghasilan_ayah` varchar(55) DEFAULT NULL,
  `nama_ibu` varchar(55) DEFAULT NULL,
  `tahun_lahir_ibu` varchar(4) DEFAULT NULL,
  `pendidikan_ibu` varchar(15) DEFAULT NULL,
  `pekerjaan_ibu` varchar(55) DEFAULT NULL,
  `penghasilan_ibu` varchar(55) DEFAULT NULL,
  `nama_wali` varchar(55) DEFAULT NULL,
  `tahun_lahir_wali` varchar(4) DEFAULT NULL,
  `pendidikan_wali` varchar(15) DEFAULT NULL,
  `pekerjaan_wali` varchar(55) DEFAULT NULL,
  `penghasilan_wali` varchar(50) DEFAULT NULL,
  `status` char(1) DEFAULT '0',
  `tanggal_daftar` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ppdb_siswa`
--

INSERT INTO `ppdb_siswa` (`id_ppdb`, `no_pendaftaran`, `nik`, `jenis_pendaftaran`, `jalur_pendaftaran`, `hobi`, `cita_cita`, `nama_siswa`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat`, `rt`, `rw`, `dusun`, `kelurahan`, `kabupaten`, `kode_pos`, `tempat_tinggal`, `transportasi`, `no_hp`, `email`, `kewarganegaraan`, `foto`, `tinggi_badan`, `berat_badan`, `jarak_ke_sekolah`, `waktu_tempuh_ke_sekolah`, `jumlah_saudara`, `asal_sekolah`, `alamat_sekolah_asal`, `nama_ayah`, `tahun_lahir_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nama_ibu`, `tahun_lahir_ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nama_wali`, `tahun_lahir_wali`, `pendidikan_wali`, `pekerjaan_wali`, `penghasilan_wali`, `status`, `tanggal_daftar`) VALUES
(1, 'PPDB.20200407.001', '1234567890101112', 'Baru', 'Umum', 'makan', 'makan', 'johan', 'Laki-laki', 'jakarta', '29-07-1992', 'Islam', 'villa ciomas indah blok h 3 no 6', '1', '1', '1', '1', '1', '1', 'Rumah Sendiri', 'Jalan Kaki', '085773685687', 'johansmart325@gmail.com', 'Warga Negara In', '3cbb121f912670e4bc8e10ebf1b7fc5b.jpg', '1', '1', '1', '1', '1', '1', '1', '1', '1', 'D1', 'Buruh', '1 Juta - 1.999.999 Juta', '1', '1', 'D1', 'Buruh', '1 Juta - 1.999.999 Juta', 'lala', '2001', 'D1', 'Buruh', '1 Juta - 1.999.999 Juta', '1', '2020-04-07 08:38:03'),
(2, 'PPDB.20200523.001', '12097000', 'Baru', 'Umum', 'admin\'#', 'admin\'#', 'admin\'#', 'Laki-laki', 'admin\'#', '25-05-1989', 'Islam', 'admin\'#', 'admi', 'admi', 'admin\'#', 'admin\'#', 'admin\'#', 'admin\'#', 'Asrama', 'Jalan Kaki', '021', 'jj@gmail.com', 'Warga Negara In', '3893aa16bc84733a7a7daf0374bc3a1e.jpg', '11', '11', '11', '11', '1', 'admin\'#', 'admin\'#', 'admin\'#', '01', 'D1', 'Buruh', '1 Juta - 1.999.999 Juta', 'admin\'#', '1989', 'D1', 'Buruh', '1 Juta - 1.999.999 Juta', 'aa', '2020', 'D1', 'Buruh', '1 Juta - 1.999.999 Juta', '1', '2020-05-23 12:36:30');

-- --------------------------------------------------------

--
-- Table structure for table `ppdb_slideshow`
--

CREATE TABLE `ppdb_slideshow` (
  `id_slideshow` int(11) NOT NULL,
  `file_gambar` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ppdb_slideshow`
--

INSERT INTO `ppdb_slideshow` (`id_slideshow`, `file_gambar`) VALUES
(4, '0b01214b952e23773ebfbf0213d15e37.jpg'),
(6, '05506443543680df3bf4b35b07592375.jpg'),
(7, '16cfd561dda800ac92744ad01ee7979b.png');

-- --------------------------------------------------------

--
-- Table structure for table `raport`
--

CREATE TABLE `raport` (
  `id_raport` bigint(20) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_tahun_ajaran` int(11) NOT NULL,
  `tgl_upload` date NOT NULL,
  `jam_upload` time NOT NULL,
  `pts` varchar(40) NOT NULL,
  `pas` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `raport`
--

INSERT INTO `raport` (`id_raport`, `id_guru`, `id_siswa`, `id_tahun_ajaran`, `tgl_upload`, `jam_upload`, `pts`, `pas`) VALUES
(1, 1, 56, 3, '2020-06-23', '01:39:47', '20062301394773564.pdf', '20062301394764572.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `slideshow`
--

CREATE TABLE `slideshow` (
  `id` int(11) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `tgl_upload` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `slideshow`
--

INSERT INTO `slideshow` (`id`, `keterangan`, `gambar`, `tgl_upload`) VALUES
(3, 'Slide 2', '55130a42732029bbea6e494aaec5a0b6.jpg', '2016-05-02'),
(4, 'Slide 1', 'b98fa376e178a39ca8d950dc7e5b67aa.jpg', '2016-05-02'),
(5, 'Slide 3', 'bb3c3421eeea4f946e881975293d9b53.jpg', '2016-05-02');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `aktif` enum('Y','N') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `nama`, `jabatan`, `keterangan`, `gambar`, `aktif`) VALUES
(2, 'Jack Daniels', 'Senior Supervisor', 'Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus.', 'af30df2029a96bd9843ad451bca54bff.jpg', 'Y'),
(3, 'Linda Glendell', 'Teaching Professor', 'Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus.', '7aa98284a5351d3bbc9effc486970c4b.jpg', 'Y'),
(4, 'Kate Dennings', 'Children Diet', 'Phasellus lorem augue, vulputate vel orci id, ultricies aliquet risus.', '256a56c3a3ca96b6c08b7b87bc662004.jpg', 'Y'),
(5, 'Kristof Slinghot', 'Management', 'hasellus lorem augue, vulputate vel orci id, ultricies aliquet risus.', 'f4fcba66aa0852f2d9f608f5bbdd591f.jpg', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tentang_web`
--

CREATE TABLE `tentang_web` (
  `id` int(11) NOT NULL,
  `nama_situs` varchar(100) DEFAULT NULL,
  `tentang` text DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `instagram` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `gambar` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `level` enum('admin','tes') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`) VALUES
(1, 'Admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `video_display`
--

CREATE TABLE `video_display` (
  `id_video` int(11) NOT NULL,
  `judul_video` varchar(100) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `video_display`
--

INSERT INTO `video_display` (`id_video`, `judul_video`, `link`) VALUES
(1, '5 Cara Melindungi Diri Dari Covid-19', './videox/VID3.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `vw_ajar_guru`
--

CREATE TABLE `vw_ajar_guru` (
  `nama_mapel` varchar(50) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL,
  `tahun_ajaran` char(9) DEFAULT NULL,
  `semester` int(1) DEFAULT NULL,
  `id_guru` int(11) DEFAULT NULL,
  `id_jadwal_pelajaran` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_bayar_siswa`
--

CREATE TABLE `vw_bayar_siswa` (
  `id_pembayaran_bulanan` int(11) DEFAULT NULL,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `bayar` float DEFAULT NULL,
  `bulan` varchar(15) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `nama_pos_keuangan` varchar(100) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `tipe_pembayaran` enum('Bulanan','Bebas') DEFAULT NULL,
  `nama_siswa` varchar(200) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_bayar_siswa_bebas`
--

CREATE TABLE `vw_bayar_siswa_bebas` (
  `nama_pos_keuangan` varchar(100) DEFAULT NULL,
  `id_pembayaran_bebas` int(11) DEFAULT NULL,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `tipe_pembayaran` enum('Bulanan','Bebas') DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `nama_siswa` varchar(200) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_guru`
--

CREATE TABLE `vw_guru` (
  `id_guru` int(11) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nik` varchar(50) DEFAULT NULL,
  `nama_guru` varchar(150) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `aktif_guru` char(1) DEFAULT NULL,
  `nama_jabatan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_guru_dt`
--

CREATE TABLE `vw_guru_dt` (
  `nip` varchar(30) DEFAULT NULL,
  `nik` varchar(50) DEFAULT NULL,
  `nuptk` varchar(30) DEFAULT NULL,
  `nama_guru` varchar(150) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `tempat_lahir` varchar(150) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` enum('ISLAM','KATOLIK','PROTESTAN','HINDU','BUDHA','KONGHUCU') DEFAULT NULL,
  `alamat_jalan` varchar(255) DEFAULT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kode_pos` int(10) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `kewarganegaraan` enum('WNI','WNA') DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `nama_jabatan` varchar(100) DEFAULT NULL,
  `id_guru` int(11) DEFAULT NULL,
  `id_jabatan` int(11) DEFAULT NULL,
  `aktif_guru` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_jadwal_pelajaran`
--

CREATE TABLE `vw_jadwal_pelajaran` (
  `id_jadwal_pelajaran` int(11) DEFAULT NULL,
  `id_tahun_ajaran` int(11) DEFAULT NULL,
  `tahun_ajaran` char(9) DEFAULT NULL,
  `semester` int(1) DEFAULT NULL,
  `nama_guru` varchar(150) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL,
  `nama_mapel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_jenis_bayar`
--

CREATE TABLE `vw_jenis_bayar` (
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `tipe_pembayaran` enum('Bulanan','Bebas') DEFAULT NULL,
  `aktif_jenis_pembayaran` char(1) DEFAULT NULL,
  `nama_pos_keuangan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_kepala_sekolah`
--

CREATE TABLE `vw_kepala_sekolah` (
  `id_kepala_sekolah` int(11) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nik` varchar(50) DEFAULT NULL,
  `nama_kepala_sekolah` varchar(60) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `aktif_kepala_sekolah` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_kepala_sekolah_dt`
--

CREATE TABLE `vw_kepala_sekolah_dt` (
  `id_kepala_sekolah` int(11) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nik` varchar(50) DEFAULT NULL,
  `nama_kepala_sekolah` varchar(60) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `aktif_kepala_sekolah` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_mapel`
--

CREATE TABLE `vw_mapel` (
  `id_mapel` int(11) DEFAULT NULL,
  `kode_mapel` varchar(25) DEFAULT NULL,
  `nama_mapel` varchar(50) DEFAULT NULL,
  `aktif_mapel` char(1) DEFAULT NULL,
  `kkm` int(2) DEFAULT NULL,
  `nama_kelompok_pelajaran` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_pelanggaran_siswa`
--

CREATE TABLE `vw_pelanggaran_siswa` (
  `nama_siswa` varchar(200) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL,
  `nama_poin_pelanggaran` text DEFAULT NULL,
  `id_pelanggaran_siswa` int(11) DEFAULT NULL,
  `id_penginput` int(11) DEFAULT NULL,
  `id_poin_pelanggaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `poin_minus` int(11) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_siswa`
--

CREATE TABLE `vw_siswa` (
  `nis` varchar(20) DEFAULT NULL,
  `nama_siswa` varchar(200) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `aktif_siswa` char(1) DEFAULT NULL,
  `angkatan` varchar(4) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_siswa_dt`
--

CREATE TABLE `vw_siswa_dt` (
  `id_kelas` int(11) DEFAULT NULL,
  `nis` varchar(20) DEFAULT NULL,
  `nisn` varchar(20) DEFAULT NULL,
  `nama_siswa` varchar(200) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` enum('Islam','Katolik','Protestan','Budha','Hindu','Konghucu') DEFAULT NULL,
  `alamat_jalan` varchar(200) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kode_pos` varchar(15) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `angkatan` varchar(4) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL,
  `nama_ayah` varchar(50) DEFAULT NULL,
  `pendidikan_ayah` varchar(25) DEFAULT NULL,
  `pekerjaan_ayah` varchar(25) DEFAULT NULL,
  `no_hp_ayah` varchar(15) DEFAULT NULL,
  `nama_ibu` varchar(50) DEFAULT NULL,
  `pendidikan_ibu` varchar(25) DEFAULT NULL,
  `pekerjaan_ibu` varchar(25) DEFAULT NULL,
  `no_hp_ibu` varchar(15) DEFAULT NULL,
  `nama_wali` varchar(50) DEFAULT NULL,
  `pendidikan_wali` varchar(25) DEFAULT NULL,
  `pekerjaan_wali` varchar(25) DEFAULT NULL,
  `no_hp_wali` varchar(15) DEFAULT NULL,
  `nama_sekolah` varchar(50) DEFAULT NULL,
  `status_sekolah` varchar(15) DEFAULT NULL,
  `alamat_sekolah` varchar(250) DEFAULT NULL,
  `tahun_lulus` varchar(4) DEFAULT NULL,
  `aktif_siswa` char(1) DEFAULT NULL,
  `id_jurusan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_staff`
--

CREATE TABLE `vw_staff` (
  `id_staff` int(11) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nama_staff` varchar(150) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `aktif_staff` char(1) DEFAULT NULL,
  `nama_jabatan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_staff_dt`
--

CREATE TABLE `vw_staff_dt` (
  `id_staff` int(11) DEFAULT NULL,
  `nip` varchar(30) DEFAULT NULL,
  `nama_staff` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `tempat_lahir` varchar(150) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` enum('ISLAM','KATOLIK','PROTESTAN','HINDU','BUDHA','KONGHUCU') DEFAULT NULL,
  `alamat_jalan` varchar(255) DEFAULT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kode_pos` int(10) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `hp` varchar(15) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `kewarganegaraan` enum('WNI','WNA') DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `aktif_staff` char(1) DEFAULT NULL,
  `id_jabatan` int(11) DEFAULT NULL,
  `nama_jabatan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_tarif_kelas`
--

CREATE TABLE `vw_tarif_kelas` (
  `nis` varchar(20) DEFAULT NULL,
  `nama_siswa` varchar(200) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_tarif_kelas2`
--

CREATE TABLE `vw_tarif_kelas2` (
  `nis` varchar(20) DEFAULT NULL,
  `nama_siswa` varchar(200) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vw_walikelas`
--

CREATE TABLE `vw_walikelas` (
  `nama_kelas` varchar(50) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_walikelas` int(11) DEFAULT NULL,
  `nama_guru` varchar(150) DEFAULT NULL,
  `id_guru` int(11) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
