-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 26, 2024 at 09:09 AM
-- Server version: 10.3.39-MariaDB-cll-lve
-- PHP Version: 8.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leub2483_cbtzya`
--

-- --------------------------------------------------------

--
-- Table structure for table `cbt_jawaban`
--

CREATE TABLE `cbt_jawaban` (
  `jawaban_id` bigint(20) UNSIGNED NOT NULL,
  `jawaban_soal_id` bigint(20) UNSIGNED NOT NULL,
  `jawaban_detail` text NOT NULL,
  `jawaban_benar` tinyint(1) NOT NULL DEFAULT 0,
  `jawaban_aktif` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_jawaban`
--

INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES
(186, 57, '<p>1 Syawal</p>\r\n', 1, 1),
(187, 57, '<p>1 Agustus</p>', 0, 1),
(188, 57, '<p>1 Januari</p>', 0, 1),
(189, 57, '<p>1 Desember</p>', 0, 1),
(190, 57, '<p>14 Februari</p>', 0, 1),
(191, 56, '<p>Nazril Irham</p>', 1, 1),
(192, 56, '<p>Joko Susilo</p>', 0, 1),
(193, 56, '<p>Wahyu Saputra</p>\r\n', 0, 1),
(194, 56, '<p>Aril Piterpen</p>', 0, 1),
(195, 56, 'Joko Wow', 0, 1),
(196, 55, '<p>Soekarno</p>', 1, 1),
(197, 55, '<p>Soeharto</p>\r\n', 0, 1),
(198, 55, '<p>Susilo Bambang Yudhoyono</p>\r\n', 0, 1),
(199, 55, '<p>BJ. Habibie</p>\r\n', 0, 1),
(200, 55, '<p>Joko Widodo</p>\r\n', 0, 1),
(201, 54, '<p>Sun East Mall</p>', 1, 1),
(202, 54, '<p>Matahari</p>', 0, 1),
(203, 54, '<p>Bulan</p>', 0, 1),
(204, 54, '<p>Tanah Abang</p>', 0, 1),
(205, 54, '<p>Tanah Lempong</p>', 0, 1),
(206, 53, '<p>Sekolah Menengah Kejuruan</p>', 1, 1),
(207, 53, '<p>Sekolah Menengah Kejujuran</p>', 0, 1),
(208, 53, '<p>Sekolah Maju Sendiri</p>', 0, 1),
(209, 53, '<p>Sekolah Mak Ku</p>', 0, 1),
(210, 53, '<p>Sekolah Memilih Kekasih</p>', 0, 1),
(211, 64, 'Akhirnya aku menemukanmu', 1, 1),
(212, 64, 'Akhir dirimu', 0, 1),
(213, 64, 'Susahnya jadi dia', 0, 1),
(214, 64, 'Jones', 0, 1),
(215, 64, 'Josan - Jomblo Pas Pasan', 0, 1),
(621, 161, '<p>Aksi bela Jomblo</p>\r\n', 1, 1),
(622, 161, '<p>Aksi bela cewek</p>\r\n', 0, 1),
(623, 161, '<p>14 Februari</p>\r\n', 0, 1),
(624, 161, '<p>Hari Valentine</p>\r\n', 0, 1),
(625, 161, '<p>Turun ke jalan</p>\r\n', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_konfigurasi`
--

CREATE TABLE `cbt_konfigurasi` (
  `konfigurasi_id` int(11) NOT NULL,
  `konfigurasi_kode` varchar(50) NOT NULL,
  `konfigurasi_isi` varchar(500) NOT NULL,
  `konfigurasi_keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cbt_konfigurasi`
--

INSERT INTO `cbt_konfigurasi` (`konfigurasi_id`, `konfigurasi_kode`, `konfigurasi_isi`, `konfigurasi_keterangan`) VALUES
(1, 'link_login_operator', 'ya', 'Menampilkan Link Login Operator'),
(2, 'cbt_nama', 'CBT SKAONELMD', 'Nama Penyelenggara ZYACBT'),
(3, 'cbt_keterangan', 'Ujian Online Berbasis Komputer', 'Keterangan Penyelenggara ZYACBT'),
(4, 'cbt_mobile_lock_xambro', 'ya', 'Melakukan Lock pada browser mobile agar menggunakan Xambro Saja'),
(5, 'cbt_informasi', '<p>Silahkan pilih Tes yang diikuti dari daftar tes yang tersedia dibawah ini. Apabila tes tidak muncul, silahkan menghubungi Operator yang bertugas.</p>\r\n', 'Informasi yang diberika di Dashboard peserta tes\'');

-- --------------------------------------------------------

--
-- Table structure for table `cbt_modul`
--

CREATE TABLE `cbt_modul` (
  `modul_id` bigint(20) UNSIGNED NOT NULL,
  `modul_nama` varchar(255) NOT NULL,
  `modul_aktif` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_modul`
--

INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES
(9, 'Default', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_sessions`
--

CREATE TABLE `cbt_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `cbt_sessions`
--

INSERT INTO `cbt_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('043d354f3c71c0c1f6373a3e5e66db2bae3c5ba7', '180.251.224.147', 1697093010, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039333031303b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('0f38070190c1a976be0abf4d99f122a18ff19df1', '180.251.224.147', 1697092903, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039323734393b),
('1068225841a5b3e56b8f2f414e7ec1bad44aac44', '2a0d:5600:24:1500:1012:cef4:e15d:d6a8', 1697111930, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131313933303b),
('148a5899c7aa40e03b3f05c5ea6d0465908d6853', '54.78.1.51', 1699596666, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639393539363636363b),
('14d2b3280d86f9ea65b513ed976db8a6f32441dd', '54.156.251.192', 1697112381, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131323338313b),
('16dbbc266e97faadadf50f69e4e0d56767ed29f2', '176.53.222.126', 1702485685, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323438353638353b),
('1f0285601f74192f6b15b2bf1c701d363c3087af', '129.153.125.162', 1697111182, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131313138323b),
('27f6faad1f0b1af007a0bd96b0b3bed9d20a761a', '2001:550:1d05:1::13', 1697109775, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373130393737353b),
('2b1f4fbf21e7da061ebd6951ec8b5422aac98748', '65.21.65.198', 1702360240, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323336303234303b),
('2c37b923c4cb9731166d493de08478184d20fe62', '146.70.200.212', 1702360194, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323336303139343b),
('2de32ffe1171e0fd744ce4d2a944c8e5322e4d97', '129.153.125.162', 1697554579, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373535343537393b),
('2f8f9a909a377b8f8a6990dd01dc86bf2c084126', '18.212.217.48', 1702324864, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323332343836343b),
('32528618768e43bf70507dbfcbe6255adbc00b8e', '34.254.53.125', 1697100388, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373130303338383b),
('3d80f3ca88a391d42167e1f91c272d41298cfcdc', '54.164.51.14', 1702324870, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323332343837303b),
('3p29jbime34jis7a5em13qm2epfq90na', '::1', 1599377882, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393337373634313b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('435b97c2ee93c2ec071f57c20fa5217b626c1d0d', '180.251.224.147', 1697092343, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039323334333b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('4732778447a9fbcbb98ac80b0e6f3af13fb7680e', '65.21.65.198', 1702360241, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323336303234313b),
('48668865bfde85dd023ff84efbb7cb795830fe5e', '129.153.125.162', 1697507693, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373530373639333b),
('541fa6babf98c2072a9209bf557e8092a0716406', '171.244.43.14', 1697118092, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131383039323b),
('589853f6dd9f9faa0850d3a3caa095cf303d5a80', '180.251.224.147', 1697091186, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039313138363b),
('5a2f375e25939fcbdaa01d8315b3fec204a2dac9', '129.153.125.162', 1697159246, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373135393234363b),
('6145afdf3e118c46f055cac00790e34394205f9f', '180.251.224.147', 1697091418, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039313431383b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('6a071a04dab0cc5c274d4bbce37adb84ff697855', '129.153.125.162', 1697289133, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373238393133333b),
('6d253800afab7138e650cc1a3f7255cf63af3ad3', '176.53.218.34', 1702496094, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323439363039343b),
('723d33d524b2c1f1e8d17ea964112a5d0bf017b1', '34.235.48.77', 1697109861, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373130393836313b),
('786be4fb91335f3857b1b4fea0c05ecef0b5805d', '3.249.207.154', 1702122098, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323132323039383b),
('7e742n3jq70q4g577qpfdth4fdk4j02p', '127.0.0.1', 1604182994, 0x5f5f63695f6c6173745f726567656e65726174657c693a313630343138323939343b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('8b29f96b6a67a2d76c69d3fad40361a3fef7180d', '129.153.125.162', 1697247990, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373234373939303b),
('8cdde1e9302656dfc01d4b74faa99194b258c537', '129.153.125.162', 1697115872, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131353837323b),
('8pcnsa8ojtp08a04kaojglv011u1p9vp', '::1', 1599379422, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393337393134313b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('91277d8a2bc6f65bb3bb58e2a4e1a76ba9a72425', '180.251.224.147', 1697093266, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039333031303b),
('93121ccd985a419cd99d009060ab1e13e136bab4', '3.253.139.38', 1704793057, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730343739333035373b),
('96120d1895081faa68d86746691f7075e57cdf7a', '180.251.224.147', 1697090211, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039303231313b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('982d7d8ab0700e9b0816196049591c96a4b5468d', '54.156.251.192', 1697114744, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131343734343b),
('a1dbf9be11427baff3ec0432c44ce4e709230923', '205.169.39.192', 1697136961, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373133363936313b),
('a9cca3fe1cc3d4ffc411109e9619efb5aedaef1b', '180.251.224.147', 1697092968, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039323936383b6362745f7465735f757365725f69647c733a343a226a6f6b6f223b6362745f7465735f6e616d617c733a31323a224a6f6b6f20537573616e746f223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('ace5hlacs61k06r3bhl6dgb2kvjmkset', '::1', 1599379011, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393337383732303b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('adeb1663115a45305b5c8e70b14e8294765f6cb3', '3.249.120.10', 1704758497, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730343735383439373b),
('b81088a9f40417b11f27e21f050d14f2e125879c', '180.251.224.147', 1697092646, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039323634363b6362745f7465735f757365725f69647c733a343a226a6f6b6f223b6362745f7465735f6e616d617c733a31323a224a6f6b6f20537573616e746f223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('b8ls2vctk6rsjiiuvpv1pq9apvmb5bos', '::1', 1599381132, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393338313031383b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b6362745f7465735f757365725f69647c733a353a226c75746669223b6362745f7465735f6e616d617c733a32323a224d7568616d6d6164204c75746669616c2048616b696d223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('ba68133a93a55c100dc41da48e096785f2995191', '205.169.39.192', 1697136967, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373133363936373b),
('bbtk0oq94r7dnqkcitjidi135e2n7jet', '::1', 1599380892, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393338303633363b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b6362745f7465735f757365725f69647c733a343a226a6f6b6f223b6362745f7465735f6e616d617c733a31323a224a6f6b6f20537573616e746f223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('bc75415557fc08c149641804d4937c3e05fbd9f2', '171.244.43.14', 1702382275, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323338323237353b),
('bc9aejgjbhihf9rq8vm7t8j5anr7j7hc', '::1', 1599382972, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393338323937313b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b6362745f7465735f757365725f69647c733a353a226c75746669223b6362745f7465735f6e616d617c733a32323a224d7568616d6d6164204c75746669616c2048616b696d223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('be7d7a4e0f7c282f4b0249a4861980b38174f5b8', '2600:3c03::f03c:93ff:fe4f:f48b', 1697267339, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373236373333393b),
('c63b67a6241dbdc90d2b1b37b059a7016457af68', '2001:448a:3000:4281:a444:996:88f7:9a80', 1706234900, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730363233343930303b),
('c7145a3216902ed26e2261c4d9eb752b11cc3aea', '2602:ffc8:2:104::7', 1697114667, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131343636373b),
('caac6efa549e145e28271a45800fd6cfb5c75dea', '2600:3c03::f03c:93ff:fe4f:f48b', 1697094489, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039343438393b),
('cc3975d32ea9e2ad6151225ed5fd6274c04dc428', '180.251.224.147', 1697092659, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039323635393b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('cc5ad278a3c1280e6efc1894126675c9df017485', '176.53.218.151', 1697171693, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373137313639333b),
('cfe0c0d9d47ffb8444ed7f510b6681c9ddc245ad', '176.53.216.236', 1697279051, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373237393035313b),
('d094ea18e9eabeab1834f316f9304c23051ae82e', '133.242.174.119', 1697100326, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373130303332363b),
('d194738c37fc7180959f0131abf0aba86f3d8e19', '176.53.221.0', 1697142167, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373134323136373b),
('d608a4b4f5af980becadf4b738e1acd856000b05', '2a01:4f8:10a:2d6::2', 1702360349, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323336303334393b),
('d69548bdc41c0ba93f5a11ee564581c0b031613d', '133.242.174.119', 1702370940, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323337303934303b),
('d6dfc2a555c8f830dfe768f72b62bf237bd6bfed', '34.254.53.125', 1697100353, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373130303335333b),
('dc544e1c13b73e3c143248cb95b822895b95131d', '65.154.226.166', 1697161487, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373136313438373b),
('defcc2c30c225be010170fc8fc16854501231a09', '89.104.110.150', 1697304599, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373330343539393b),
('e3b50567870cd82ad55dc212ecf1883057c97db8', '183.129.153.157', 1697234807, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373233343830373b),
('e4982b9b2754b788d0f668c97cbc933ab433279d', '66.115.189.164', 1702360193, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323336303139333b),
('f39scdhganmqqot28k62lbc3rmo1lsce', '::1', 1599386485, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393338363138373b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b6362745f7465735f757365725f69647c733a353a226c75746669223b6362745f7465735f6e616d617c733a32323a224d7568616d6d6164204c75746669616c2048616b696d223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('f802287eeb204ad5c9b227850b70988bf6bc146d', '129.153.125.162', 1702796305, 0x5f5f63695f6c6173745f726567656e65726174657c693a313730323739363330353b),
('f9235dec0d60b0fce591b673f81a8fb34b367312', '103.172.70.163', 1697201809, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373230313830393b),
('f97ca561d2988c0b16ac799588cd76ddfea49574', '2a03:2880:30ff:8::face:b00c', 1697564758, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373536343735383b),
('fabff951a717baaf38471ac8a114fcc23855c112', '180.251.224.147', 1697092996, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039323936383b),
('faca7ba73cee4044cbb8031d10a032c144626a0a', '180.251.224.147', 1697091491, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373039313439313b6362745f7465735f757365725f69647c733a343a226a6f6b6f223b6362745f7465735f6e616d617c733a31323a224a6f6b6f20537573616e746f223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('fff25cabca7cecf8d7ffa54c39a7e7fbe5bb0d3a', '129.153.125.162', 1697112100, 0x5f5f63695f6c6173745f726567656e65726174657c693a313639373131323130303b),
('fthkcg5hasehthcqlfjmeogf3eedm9ef', '127.0.0.1', 1599454747, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393435343734373b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('h7rpp3igk9lt3tu4vbi28jia5jkfv524', '::1', 1599454890, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393435343832303b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('ha55u3amhkachu4cfa34mvkgcj97vrdi', '::1', 1599381616, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393338313534363b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b6362745f7465735f757365725f69647c733a353a226c75746669223b6362745f7465735f6e616d617c733a32323a224d7568616d6d6164204c75746669616c2048616b696d223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('kkolosfo49t3vu9of56viv7u5r25rfks', '::1', 1599378656, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393337383431393b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('mt3ddutslgt5rtbqq22i9g8qigcjdpva', '::1', 1599386603, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393338363536303b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b6362745f7465735f757365725f69647c733a353a226c75746669223b6362745f7465735f6e616d617c733a32323a224d7568616d6d6164204c75746669616c2048616b696d223b6362745f7465735f67726f75707c733a353a225849204d4d223b6362745f7465735f67726f75705f69647c733a313a2235223b),
('p5q7f07bavkq326a2ddftl0ggc9c5g6q', '127.0.0.1', 1604183005, 0x5f5f63695f6c6173745f726567656e65726174657c693a313630343138323939343b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('ph4kvrn03c7gh4pishmsg9a0vhi1i8e5', '::1', 1599377617, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393337373333323b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('qg6n9mljb7oo6a9809pcl686s9mjm87m', '::1', 1599455121, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393435353131353b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('rhafjlpmrr6dbsi05f24tl39qv9250e9', '::1', 1599378268, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393337373935373b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b),
('ro5m2p8h2ikbdm0fltah1tkegn1vj00p', '127.0.0.1', 1599455011, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539393435343734373b6362745f757365725f69647c733a353a2261646d696e223b6362745f6e616d617c733a31323a224163686d6164204c75746669223b6362745f6c6576656c7c733a353a2261646d696e223b6362745f6f707369317c733a303a22223b6362745f6f707369327c733a303a22223b);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_soal`
--

CREATE TABLE `cbt_soal` (
  `soal_id` bigint(20) UNSIGNED NOT NULL,
  `soal_topik_id` bigint(20) UNSIGNED NOT NULL,
  `soal_detail` text NOT NULL,
  `soal_tipe` smallint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT '1=Pilihan ganda, 2=essay, 3=jawaban singkat',
  `soal_kunci` text DEFAULT NULL COMMENT 'Kunci untuk soal jawaban singkat',
  `soal_difficulty` smallint(6) NOT NULL DEFAULT 1,
  `soal_aktif` tinyint(1) NOT NULL DEFAULT 0,
  `soal_audio` varchar(200) DEFAULT NULL,
  `soal_audio_play` int(11) NOT NULL DEFAULT 0,
  `soal_timer` smallint(10) DEFAULT NULL,
  `soal_inline_answers` tinyint(1) NOT NULL DEFAULT 0,
  `soal_auto_next` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_soal`
--

INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES
(53, 7, 'Apakah kepanjangan dari SMK ?', 1, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(54, 7, '<p>Nama salah satu Mall yang ada di kota genteng adalah ...<br></p>', 1, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(55, 7, '<p>Siapakah nama tokoh berikut ?</p><p><img src=\"[base_url]uploads/topik_7/soekarno.jpg\" style=\"max-width: 600px;\"><br></p>', 1, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(56, 7, '<p>Siapakah vokalis band NOAH ?<br></p>', 1, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(57, 7, '<p>Tanggal berapakah hari raya Idul Fitri ?</p>\r\n', 1, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(61, 7, 'Jelaskan apa yang dimaksud dengan Jomblo ?', 2, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(62, 7, '<p>PT. Tiar Perkasa ingin melebarkan sayap usaha di bidang kuliner.</p><p>Dari pernyataan tersebut, sebutkan siapa kekasih mas Tiar ?</p>', 2, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(63, 7, '<p>Jelaskan kenapa Liverpool FC susah sekali untuk juara Premiere Leage !</p>\r\n', 2, NULL, 1, 1, NULL, 1, NULL, 0, 0),
(64, 7, '<p>Apakah judul lagu berikut ini?</p>', 1, NULL, 1, 1, 'naff_-_akhirnya_ku_menemukanmu.mp3', 1, NULL, 0, 0),
(161, 7, '<p>Jelaskan arti poster dibawah ini ?</p>\r\n\r\n<p><img src=\"[base_url]uploads/topik_7/5a49b252e7aea.jpeg\" style=\"height:283px; width:300px\" /></p>\r\n', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0),
(214, 7, '<p>Berapakah 5x10 ?</p>\r\n', 3, '50', 1, 1, NULL, 0, NULL, 0, 0),
(215, 7, '<p>aaaa</p>\r\n', 1, '', 1, 1, NULL, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_tes`
--

CREATE TABLE `cbt_tes` (
  `tes_id` bigint(20) UNSIGNED NOT NULL,
  `tes_nama` varchar(255) NOT NULL,
  `tes_detail` text NOT NULL,
  `tes_begin_time` datetime DEFAULT NULL,
  `tes_end_time` datetime DEFAULT NULL,
  `tes_duration_time` smallint(10) UNSIGNED NOT NULL DEFAULT 0,
  `tes_ip_range` varchar(255) NOT NULL DEFAULT '*.*.*.*',
  `tes_results_to_users` tinyint(1) NOT NULL DEFAULT 0,
  `tes_detail_to_users` tinyint(1) NOT NULL DEFAULT 0,
  `tes_score_right` decimal(10,2) DEFAULT 1.00,
  `tes_score_wrong` decimal(10,2) DEFAULT 0.00,
  `tes_score_unanswered` decimal(10,2) DEFAULT 0.00,
  `tes_max_score` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tes_token` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_tes`
--

INSERT INTO `cbt_tes` (`tes_id`, `tes_nama`, `tes_detail`, `tes_begin_time`, `tes_end_time`, `tes_duration_time`, `tes_ip_range`, `tes_results_to_users`, `tes_detail_to_users`, `tes_score_right`, `tes_score_wrong`, `tes_score_unanswered`, `tes_max_score`, `tes_token`) VALUES
(5, 'Tes Uji Coba', 'Tes Uji Coba', '2023-10-11 13:36:00', '2023-10-13 13:36:00', 30, '*.*.*.*', 1, 0, 1.00, 0.00, 0.00, 10.00, 0),
(6, 'tes', 'tes', '2023-10-12 13:13:00', '2023-10-13 13:13:00', 30, '*.*.*.*', 1, 0, 1.00, 0.00, 0.00, 0.00, 0),
(7, 'tes2', 'tes2', '2023-10-12 13:14:00', '2023-10-13 13:14:00', 30, '*.*.*.*', 1, 0, 1.00, 0.00, 0.00, 0.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_tesgrup`
--

CREATE TABLE `cbt_tesgrup` (
  `tstgrp_tes_id` bigint(20) UNSIGNED NOT NULL,
  `tstgrp_grup_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_tesgrup`
--

INSERT INTO `cbt_tesgrup` (`tstgrp_tes_id`, `tstgrp_grup_id`) VALUES
(5, 5),
(6, 5),
(7, 5);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_tes_soal`
--

CREATE TABLE `cbt_tes_soal` (
  `tessoal_id` bigint(20) UNSIGNED NOT NULL,
  `tessoal_tesuser_id` bigint(20) UNSIGNED NOT NULL,
  `tessoal_user_ip` varchar(39) DEFAULT NULL,
  `tessoal_soal_id` bigint(20) UNSIGNED NOT NULL,
  `tessoal_jawaban_text` text DEFAULT NULL,
  `tessoal_nilai` decimal(10,2) DEFAULT NULL,
  `tessoal_creation_time` datetime DEFAULT NULL,
  `tessoal_display_time` datetime DEFAULT NULL,
  `tessoal_change_time` datetime DEFAULT NULL,
  `tessoal_reaction_time` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `tessoal_ragu` int(1) NOT NULL DEFAULT 0 COMMENT '1=ragu, 0=tidak ragu',
  `tessoal_order` smallint(6) NOT NULL DEFAULT 1,
  `tessoal_num_answers` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `tessoal_comment` text DEFAULT NULL,
  `tessoal_audio_play` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_tes_soal`
--

INSERT INTO `cbt_tes_soal` (`tessoal_id`, `tessoal_tesuser_id`, `tessoal_user_ip`, `tessoal_soal_id`, `tessoal_jawaban_text`, `tessoal_nilai`, `tessoal_creation_time`, `tessoal_display_time`, `tessoal_change_time`, `tessoal_reaction_time`, `tessoal_ragu`, `tessoal_order`, `tessoal_num_answers`, `tessoal_comment`, `tessoal_audio_play`) VALUES
(31, 4, NULL, 54, NULL, 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:48', '2023-10-12 13:37:47', 0, 0, 1, 0, NULL, 0),
(32, 4, NULL, 62, 'sdfs', 0.00, '2023-10-12 13:37:36', '2023-10-12 13:37:57', '2023-10-12 13:37:58', 0, 0, 2, 0, NULL, 0),
(33, 4, NULL, 53, NULL, 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:19', '2023-10-12 13:37:55', 0, 0, 3, 0, NULL, 0),
(34, 4, NULL, 215, NULL, 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:19', NULL, 0, 1, 4, 0, NULL, 0),
(35, 4, NULL, 63, 'sffafa', 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:37', '2023-10-12 13:38:13', 0, 0, 5, 0, NULL, 0),
(36, 4, NULL, 55, NULL, 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:35', '2023-10-12 13:38:16', 0, 0, 6, 0, NULL, 0),
(37, 4, NULL, 214, '555', 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:34', '2023-10-12 13:42:28', 0, 0, 7, 0, NULL, 0),
(38, 4, NULL, 64, NULL, 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:52', '2023-10-12 13:38:21', 0, 0, 8, 0, NULL, 1),
(39, 4, NULL, 61, '4546', 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:41', '2023-10-12 13:42:33', 0, 0, 9, 0, NULL, 0),
(40, 4, NULL, 56, NULL, 0.00, '2023-10-12 13:37:36', '2023-10-12 13:42:41', '2023-10-12 13:42:16', 0, 0, 10, 0, NULL, 0),
(41, 5, NULL, 214, '50', 1.00, '2023-10-12 13:39:51', '2023-10-12 13:40:09', '2023-10-12 13:40:14', 0, 0, 1, 0, NULL, 0),
(42, 5, NULL, 53, NULL, 0.00, '2023-10-12 13:39:51', '2023-10-12 13:40:26', '2023-10-12 13:40:28', 0, 0, 2, 0, NULL, 0),
(43, 5, NULL, 64, NULL, 1.00, '2023-10-12 13:39:51', '2023-10-12 13:40:22', '2023-10-12 13:40:24', 0, 0, 3, 0, NULL, 0),
(44, 5, NULL, 161, NULL, 1.00, '2023-10-12 13:39:51', '2023-10-12 13:40:17', '2023-10-12 13:40:19', 0, 0, 4, 0, NULL, 0),
(45, 5, NULL, 54, NULL, 0.00, '2023-10-12 13:39:51', '2023-10-12 13:40:29', '2023-10-12 13:40:30', 0, 0, 5, 0, NULL, 0),
(46, 5, NULL, 56, NULL, 0.00, '2023-10-12 13:39:51', '2023-10-12 13:40:31', '2023-10-12 13:40:33', 0, 0, 6, 0, NULL, 0),
(47, 5, NULL, 215, NULL, 0.00, '2023-10-12 13:39:51', '2023-10-12 13:40:52', NULL, 0, 0, 7, 0, NULL, 0),
(48, 5, NULL, 61, 'Sdd', 0.00, '2023-10-12 13:39:51', '2023-10-12 13:40:46', '2023-10-12 13:40:51', 0, 0, 8, 0, NULL, 0),
(49, 5, NULL, 62, 'Df', 0.00, '2023-10-12 13:39:51', '2023-10-12 13:40:43', '2023-10-12 13:40:44', 0, 0, 9, 0, NULL, 0),
(50, 5, NULL, 55, NULL, 1.00, '2023-10-12 13:39:51', '2023-10-12 13:40:00', '2023-10-12 13:40:05', 0, 0, 10, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_tes_soal_jawaban`
--

CREATE TABLE `cbt_tes_soal_jawaban` (
  `soaljawaban_tessoal_id` bigint(20) UNSIGNED NOT NULL,
  `soaljawaban_jawaban_id` bigint(20) UNSIGNED NOT NULL,
  `soaljawaban_selected` smallint(6) NOT NULL DEFAULT -1,
  `soaljawaban_order` smallint(6) NOT NULL DEFAULT 1,
  `soaljawaban_position` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_tes_soal_jawaban`
--

INSERT INTO `cbt_tes_soal_jawaban` (`soaljawaban_tessoal_id`, `soaljawaban_jawaban_id`, `soaljawaban_selected`, `soaljawaban_order`, `soaljawaban_position`) VALUES
(31, 201, 0, 5, NULL),
(31, 202, 0, 2, NULL),
(31, 203, 0, 3, NULL),
(31, 204, 1, 4, NULL),
(31, 205, 0, 1, NULL),
(33, 206, 0, 5, NULL),
(33, 207, 0, 2, NULL),
(33, 208, 0, 4, NULL),
(33, 209, 0, 1, NULL),
(33, 210, 1, 3, NULL),
(36, 196, 0, 2, NULL),
(36, 197, 0, 5, NULL),
(36, 198, 0, 1, NULL),
(36, 199, 0, 4, NULL),
(36, 200, 1, 3, NULL),
(38, 211, 0, 5, NULL),
(38, 212, 0, 4, NULL),
(38, 213, 1, 3, NULL),
(38, 214, 0, 1, NULL),
(38, 215, 0, 2, NULL),
(40, 191, 0, 3, NULL),
(40, 192, 0, 4, NULL),
(40, 193, 0, 1, NULL),
(40, 194, 1, 5, NULL),
(40, 195, 0, 2, NULL),
(42, 206, 0, 1, NULL),
(42, 207, 0, 5, NULL),
(42, 208, 0, 3, NULL),
(42, 209, 0, 2, NULL),
(42, 210, 1, 4, NULL),
(43, 211, 1, 4, NULL),
(43, 212, 0, 1, NULL),
(43, 213, 0, 2, NULL),
(43, 214, 0, 3, NULL),
(43, 215, 0, 5, NULL),
(44, 621, 1, 3, NULL),
(44, 622, 0, 4, NULL),
(44, 623, 0, 1, NULL),
(44, 624, 0, 5, NULL),
(44, 625, 0, 2, NULL),
(45, 201, 0, 2, NULL),
(45, 202, 0, 1, NULL),
(45, 203, 0, 5, NULL),
(45, 204, 0, 3, NULL),
(45, 205, 1, 4, NULL),
(46, 191, 0, 5, NULL),
(46, 192, 0, 2, NULL),
(46, 193, 0, 3, NULL),
(46, 194, 0, 1, NULL),
(46, 195, 1, 4, NULL),
(50, 196, 1, 1, NULL),
(50, 197, 0, 5, NULL),
(50, 198, 0, 4, NULL),
(50, 199, 0, 2, NULL),
(50, 200, 0, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_tes_token`
--

CREATE TABLE `cbt_tes_token` (
  `token_id` int(11) NOT NULL,
  `token_isi` varchar(20) NOT NULL,
  `token_user_id` int(11) NOT NULL,
  `token_ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `token_aktif` int(11) NOT NULL DEFAULT 1 COMMENT 'Umur Token dalam menit, 1 = 1 hari penuh',
  `token_tes_id` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cbt_tes_token`
--

INSERT INTO `cbt_tes_token` (`token_id`, `token_isi`, `token_user_id`, `token_ts`, `token_aktif`, `token_tes_id`) VALUES
(12, '299403', 5, '2019-12-12 02:53:22', 1, 0),
(13, '5F3BB6', 1, '2023-10-12 06:12:54', 1, 0),
(14, '91C4CB', 1, '2023-10-12 06:20:09', 1, 6),
(15, '634AE0', 1, '2023-10-12 06:37:42', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_tes_topik_set`
--

CREATE TABLE `cbt_tes_topik_set` (
  `tset_id` bigint(20) UNSIGNED NOT NULL,
  `tset_tes_id` bigint(20) UNSIGNED NOT NULL,
  `tset_topik_id` bigint(20) UNSIGNED NOT NULL,
  `tset_tipe` smallint(6) NOT NULL DEFAULT 1,
  `tset_difficulty` smallint(6) NOT NULL DEFAULT 1,
  `tset_jumlah` smallint(6) NOT NULL DEFAULT 1,
  `tset_jawaban` smallint(6) NOT NULL DEFAULT 0,
  `tset_acak_jawaban` int(11) NOT NULL DEFAULT 1,
  `tset_acak_soal` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_tes_topik_set`
--

INSERT INTO `cbt_tes_topik_set` (`tset_id`, `tset_tes_id`, `tset_topik_id`, `tset_tipe`, `tset_difficulty`, `tset_jumlah`, `tset_jawaban`, `tset_acak_jawaban`, `tset_acak_soal`) VALUES
(5, 5, 7, 0, 1, 10, 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_tes_user`
--

CREATE TABLE `cbt_tes_user` (
  `tesuser_id` bigint(20) UNSIGNED NOT NULL,
  `tesuser_tes_id` bigint(20) UNSIGNED NOT NULL,
  `tesuser_user_id` bigint(20) UNSIGNED NOT NULL,
  `tesuser_status` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `tesuser_creation_time` datetime NOT NULL,
  `tesuser_comment` text DEFAULT NULL,
  `tesuser_token` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_tes_user`
--

INSERT INTO `cbt_tes_user` (`tesuser_id`, `tesuser_tes_id`, `tesuser_user_id`, `tesuser_status`, `tesuser_creation_time`, `tesuser_comment`, `tesuser_token`) VALUES
(4, 5, 2, 4, '2023-10-12 13:37:36', NULL, NULL),
(5, 5, 1, 4, '2023-10-12 13:39:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_topik`
--

CREATE TABLE `cbt_topik` (
  `topik_id` bigint(20) UNSIGNED NOT NULL,
  `topik_modul_id` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `topik_nama` varchar(255) NOT NULL,
  `topik_detail` text DEFAULT NULL,
  `topik_aktif` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_topik`
--

INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES
(7, 9, 'Soal Uji Coba', 'Kumpulan Soal untuk Uji Coba ', 1),
(8, 9, 'Testing', 'testing', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cbt_user`
--

CREATE TABLE `cbt_user` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `user_grup_id` bigint(20) UNSIGNED NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_regdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_ip` varchar(39) DEFAULT NULL,
  `user_firstname` varchar(255) DEFAULT NULL,
  `user_birthdate` date DEFAULT NULL,
  `user_birthplace` varchar(255) DEFAULT NULL,
  `user_level` smallint(3) UNSIGNED NOT NULL DEFAULT 1,
  `user_detail` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_user`
--

INSERT INTO `cbt_user` (`user_id`, `user_grup_id`, `user_name`, `user_password`, `user_email`, `user_regdate`, `user_ip`, `user_firstname`, `user_birthdate`, `user_birthplace`, `user_level`, `user_detail`) VALUES
(1, 5, 'lutfi', 'lutfi', '', '2018-01-11 04:38:27', NULL, 'Muhammad Lutfial Hakim', NULL, NULL, 1, 'Ruang 1, Sesi 1'),
(2, 5, 'joko', 'joko', '', '2018-08-11 03:49:25', NULL, 'Joko Susanto', NULL, NULL, 1, 'Ruang 1, Sesi 2');

-- --------------------------------------------------------

--
-- Table structure for table `cbt_user_grup`
--

CREATE TABLE `cbt_user_grup` (
  `grup_id` bigint(20) UNSIGNED NOT NULL,
  `grup_nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbt_user_grup`
--

INSERT INTO `cbt_user_grup` (`grup_id`, `grup_nama`) VALUES
(5, 'XI MM');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `opsi1` varchar(75) NOT NULL,
  `opsi2` varchar(75) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  `level` varchar(50) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `nama`, `opsi1`, `opsi2`, `keterangan`, `level`, `ts`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Achmad Lutfi', '', '', '', 'admin', '2015-07-29 18:12:03'),
(4, 'operator', 'fe96dd39756ac41b74283a9292652d366d73931f', 'Operator', '', '', 'Operator', 'operator-soal', '2018-03-30 12:58:55'),
(5, 'joko', '97c358728f7f947c9a279ba9be88308395c7cc3a', 'Joko', '', '', 'Haloo', 'admin', '2019-12-12 02:53:12');

-- --------------------------------------------------------

--
-- Table structure for table `user_akses`
--

CREATE TABLE `user_akses` (
  `id` int(11) NOT NULL,
  `level` varchar(75) NOT NULL,
  `kode_menu` varchar(50) NOT NULL,
  `add` int(2) NOT NULL DEFAULT 1 COMMENT '0=false, 1=true',
  `edit` int(2) NOT NULL DEFAULT 1 COMMENT '0=false, 1=true'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_akses`
--

INSERT INTO `user_akses` (`id`, `level`, `kode_menu`, `add`, `edit`) VALUES
(254, 'operator-soal', 'modul-daftar', 1, 1),
(255, 'operator-soal', 'modul-filemanager', 1, 1),
(256, 'operator-soal', 'modul-import', 1, 1),
(257, 'operator-soal', 'modul-soal', 1, 1),
(258, 'operator-soal', 'modul-topik', 1, 1),
(259, 'operator-tes', 'tes-hasil-operator', 1, 1),
(260, 'operator-tes', 'tes-token', 1, 1),
(481, 'admin', 'laporan-analisis-butir-soal', 1, 1),
(482, 'admin', 'peserta-kartu', 1, 1),
(483, 'admin', 'peserta-group', 1, 1),
(484, 'admin', 'peserta-daftar', 1, 1),
(485, 'admin', 'modul-daftar', 1, 1),
(486, 'admin', 'tes-daftar', 1, 1),
(487, 'admin', 'tool-backup', 1, 1),
(488, 'admin', 'tes-evaluasi', 1, 1),
(489, 'admin', 'tool-exportimport-soal', 1, 1),
(490, 'admin', 'modul-filemanager', 1, 1),
(491, 'admin', 'tes-hasil', 1, 1),
(492, 'admin', 'peserta-import', 1, 1),
(493, 'admin', 'modul-import', 1, 1),
(494, 'admin', 'modul-import-word', 1, 1),
(496, 'admin', 'user_level', 1, 1),
(497, 'admin', 'user_menu', 1, 1),
(498, 'admin', 'user_atur', 1, 1),
(499, 'admin', 'user-zyacbt', 1, 1),
(500, 'admin', 'laporan-rekap', 1, 1),
(501, 'admin', 'modul-soal', 1, 1),
(502, 'admin', 'tes-tambah', 1, 1),
(503, 'admin', 'tes-token', 1, 1),
(504, 'admin', 'modul-topik', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_level`
--

CREATE TABLE `user_level` (
  `id` int(11) NOT NULL,
  `level` varchar(50) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_level`
--

INSERT INTO `user_level` (`id`, `level`, `keterangan`) VALUES
(1, 'admin', 'Administrator'),
(7, 'operator-soal', 'Operator Soal'),
(8, 'operator-tes', 'Operator Tes');

-- --------------------------------------------------------

--
-- Table structure for table `user_log`
--

CREATE TABLE `user_log` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `log` varchar(250) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `tipe` int(11) NOT NULL DEFAULT 1 COMMENT '0=parent, 1=child',
  `parent` varchar(50) DEFAULT NULL,
  `kode_menu` varchar(50) NOT NULL,
  `nama_menu` varchar(100) NOT NULL,
  `url` varchar(150) NOT NULL DEFAULT '#',
  `icon` varchar(75) NOT NULL DEFAULT 'fa fa-circle-o',
  `urutan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_menu`
--

INSERT INTO `user_menu` (`id`, `tipe`, `parent`, `kode_menu`, `nama_menu`, `url`, `icon`, `urutan`) VALUES
(1, 0, '', 'user', 'Pengaturan', '#', 'fa fa-user', 20),
(3, 1, 'user', 'user_atur', 'Pengaturan User', 'manager/useratur', 'fa fa-circle-o', 5),
(4, 1, 'user', 'user_level', 'Pengaturan Level', 'manager/userlevel', 'fa fa-circle-o', 6),
(5, 1, 'user', 'user_menu', 'Pengaturan Menu', 'manager/usermenu', 'fa fa-circle-o', 7),
(6, 0, '', 'modul', 'Data Modul', '#', 'fa fa-book', 2),
(7, 1, 'modul', 'modul-daftar', 'Daftar Soal', 'manager/modul_daftar', 'fa fa-circle-o', 5),
(8, 1, 'modul', 'modul-topik', 'Topik', 'manager/modul_topik', 'fa fa-circle-o', 2),
(10, 0, '', 'peserta', 'Data Peserta', '#', 'fa fa-users', 3),
(11, 1, 'peserta', 'peserta-daftar', 'Daftar Peserta', 'manager/peserta_daftar', 'fa fa-circle-o', 2),
(12, 1, 'peserta', 'peserta-group', 'Daftar Group', 'manager/peserta_group', 'fa fa-circle-o', 1),
(13, 1, 'peserta', 'peserta-import', 'Import Data Peserta', 'manager/peserta_import', 'fa fa-circle-o', 3),
(14, 0, '', 'tes', 'Data Tes', '#', 'fa fa-tasks', 4),
(15, 1, 'tes', 'tes-tambah', 'Tambah Tes', 'manager/tes_tambah', 'fa fa-circle-o', 1),
(16, 1, 'tes', 'tes-daftar', 'Daftar Tes', 'manager/tes_daftar', 'fa fa-circle-o', 2),
(17, 1, 'tes', 'tes-hasil', 'Hasil Tes', 'manager/tes_hasil', 'fa fa-circle-o', 6),
(18, 1, 'modul', 'modul-soal', 'Soal', 'manager/modul_soal', 'fa fa-circle-o', 3),
(19, 1, 'tes', 'tes-token', 'Token', 'manager/tes_token', 'fa fa-circle-o', 8),
(22, 1, 'modul', 'modul-filemanager', 'File Manager', 'manager/modul_filemanager', 'fa fa-circle-o', 6),
(24, 1, 'modul', 'modul-import', 'Import Soal Spreadsheet', 'manager/modul_import', 'fa fa-circle-o', 4),
(25, 1, 'tes', 'tes-evaluasi', 'Evaluasi Tes', 'manager/tes_evaluasi', 'fa fa-circle-o', 5),
(28, 1, 'tes', 'tes-hasil-operator', 'Hasil Tes Operator', 'manager/tes_hasil_operator', 'fa fa-circle-o', 10),
(30, 0, '', 'tool', 'Tool', '#', 'fa fa-wrench', 6),
(31, 1, 'tool', 'tool-backup', 'Database', 'manager/tool_backup', 'fa fa-database', 1),
(32, 1, 'tes-laporan', 'laporan-rekap', 'Rekap Hasil Tes', 'manager/laporan_rekap_hasil', 'fa fa-circle-o', 7),
(33, 1, 'tool', 'tool-exportimport-soal', 'Export / Import Soal', 'manager/tool_exportimport_soal', 'fa fa-circle-o', 2),
(34, 1, 'user', 'user-zyacbt', 'Pengaturan ZYACBT', 'manager/pengaturan_zyacbt', 'fa fa-circle-o', 1),
(37, 1, 'peserta', 'peserta-kartu', 'Cetak Kartu', 'manager/peserta_kartu', 'fa fa-circle-o', 5),
(38, 0, '', 'tes-laporan', 'Laporan', '#', 'fa fa-print', 5),
(41, 1, 'tes-laporan', 'laporan-analisis-butir-soal', 'Analisis Butir Soal', 'manager/laporan_analisis_butir_soal', 'fa fa-circle-o', 1),
(42, 1, 'tes-laporan', 'laporan-analisis-soal', 'Analisis Soal', 'manager/laporan_analisis_soal', 'fa fa-circle-o', 2),
(43, 1, 'modul', 'modul-import-word', 'Import Soal Word', 'manager/modul_import_word', 'fa fa-circle-o', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cbt_jawaban`
--
ALTER TABLE `cbt_jawaban`
  ADD PRIMARY KEY (`jawaban_id`),
  ADD KEY `p_answer_question_id` (`jawaban_soal_id`);

--
-- Indexes for table `cbt_konfigurasi`
--
ALTER TABLE `cbt_konfigurasi`
  ADD PRIMARY KEY (`konfigurasi_id`),
  ADD UNIQUE KEY `konfigurasi_kode` (`konfigurasi_kode`);

--
-- Indexes for table `cbt_modul`
--
ALTER TABLE `cbt_modul`
  ADD PRIMARY KEY (`modul_id`),
  ADD UNIQUE KEY `ak_module_name` (`modul_nama`);

--
-- Indexes for table `cbt_sessions`
--
ALTER TABLE `cbt_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `cbt_soal`
--
ALTER TABLE `cbt_soal`
  ADD PRIMARY KEY (`soal_id`),
  ADD KEY `p_question_subject_id` (`soal_topik_id`);

--
-- Indexes for table `cbt_tes`
--
ALTER TABLE `cbt_tes`
  ADD PRIMARY KEY (`tes_id`),
  ADD UNIQUE KEY `ak_test_name` (`tes_nama`);

--
-- Indexes for table `cbt_tesgrup`
--
ALTER TABLE `cbt_tesgrup`
  ADD PRIMARY KEY (`tstgrp_tes_id`,`tstgrp_grup_id`),
  ADD KEY `p_tstgrp_test_id` (`tstgrp_tes_id`),
  ADD KEY `p_tstgrp_group_id` (`tstgrp_grup_id`);

--
-- Indexes for table `cbt_tes_soal`
--
ALTER TABLE `cbt_tes_soal`
  ADD PRIMARY KEY (`tessoal_id`),
  ADD UNIQUE KEY `ak_testuser_question` (`tessoal_tesuser_id`,`tessoal_soal_id`),
  ADD KEY `p_testlog_question_id` (`tessoal_soal_id`),
  ADD KEY `p_testlog_testuser_id` (`tessoal_tesuser_id`);

--
-- Indexes for table `cbt_tes_soal_jawaban`
--
ALTER TABLE `cbt_tes_soal_jawaban`
  ADD PRIMARY KEY (`soaljawaban_tessoal_id`,`soaljawaban_jawaban_id`),
  ADD KEY `p_logansw_answer_id` (`soaljawaban_jawaban_id`),
  ADD KEY `p_logansw_testlog_id` (`soaljawaban_tessoal_id`);

--
-- Indexes for table `cbt_tes_token`
--
ALTER TABLE `cbt_tes_token`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `token_user_id` (`token_user_id`);

--
-- Indexes for table `cbt_tes_topik_set`
--
ALTER TABLE `cbt_tes_topik_set`
  ADD PRIMARY KEY (`tset_id`),
  ADD KEY `p_tsubset_test_id` (`tset_tes_id`),
  ADD KEY `tsubset_subject_id` (`tset_topik_id`);

--
-- Indexes for table `cbt_tes_user`
--
ALTER TABLE `cbt_tes_user`
  ADD PRIMARY KEY (`tesuser_id`),
  ADD UNIQUE KEY `ak_testuser` (`tesuser_tes_id`,`tesuser_user_id`,`tesuser_status`),
  ADD KEY `p_testuser_user_id` (`tesuser_user_id`),
  ADD KEY `p_testuser_test_id` (`tesuser_tes_id`);

--
-- Indexes for table `cbt_topik`
--
ALTER TABLE `cbt_topik`
  ADD PRIMARY KEY (`topik_id`),
  ADD UNIQUE KEY `ak_subject_name` (`topik_modul_id`,`topik_nama`);

--
-- Indexes for table `cbt_user`
--
ALTER TABLE `cbt_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `ak_user_name` (`user_name`),
  ADD KEY `user_groups_id` (`user_grup_id`),
  ADD KEY `user_detail` (`user_detail`);

--
-- Indexes for table `cbt_user_grup`
--
ALTER TABLE `cbt_user_grup`
  ADD PRIMARY KEY (`grup_id`),
  ADD UNIQUE KEY `group_name` (`grup_nama`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `user_akses`
--
ALTER TABLE `user_akses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `akses_kode_menu` (`kode_menu`),
  ADD KEY `akses_level` (`level`);

--
-- Indexes for table `user_level`
--
ALTER TABLE `user_level`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `level` (`level`);

--
-- Indexes for table `user_log`
--
ALTER TABLE `user_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_menu` (`kode_menu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cbt_jawaban`
--
ALTER TABLE `cbt_jawaban`
  MODIFY `jawaban_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=626;

--
-- AUTO_INCREMENT for table `cbt_konfigurasi`
--
ALTER TABLE `cbt_konfigurasi`
  MODIFY `konfigurasi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cbt_modul`
--
ALTER TABLE `cbt_modul`
  MODIFY `modul_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cbt_soal`
--
ALTER TABLE `cbt_soal`
  MODIFY `soal_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;

--
-- AUTO_INCREMENT for table `cbt_tes`
--
ALTER TABLE `cbt_tes`
  MODIFY `tes_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cbt_tes_soal`
--
ALTER TABLE `cbt_tes_soal`
  MODIFY `tessoal_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `cbt_tes_token`
--
ALTER TABLE `cbt_tes_token`
  MODIFY `token_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cbt_tes_topik_set`
--
ALTER TABLE `cbt_tes_topik_set`
  MODIFY `tset_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cbt_tes_user`
--
ALTER TABLE `cbt_tes_user`
  MODIFY `tesuser_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cbt_topik`
--
ALTER TABLE `cbt_topik`
  MODIFY `topik_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cbt_user`
--
ALTER TABLE `cbt_user`
  MODIFY `user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cbt_user_grup`
--
ALTER TABLE `cbt_user_grup`
  MODIFY `grup_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_akses`
--
ALTER TABLE `user_akses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=505;

--
-- AUTO_INCREMENT for table `user_level`
--
ALTER TABLE `user_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_log`
--
ALTER TABLE `user_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cbt_jawaban`
--
ALTER TABLE `cbt_jawaban`
  ADD CONSTRAINT `cbt_jawaban_ibfk_1` FOREIGN KEY (`jawaban_soal_id`) REFERENCES `cbt_soal` (`soal_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_soal`
--
ALTER TABLE `cbt_soal`
  ADD CONSTRAINT `cbt_soal_ibfk_1` FOREIGN KEY (`soal_topik_id`) REFERENCES `cbt_topik` (`topik_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_tesgrup`
--
ALTER TABLE `cbt_tesgrup`
  ADD CONSTRAINT `cbt_tesgrup_ibfk_1` FOREIGN KEY (`tstgrp_tes_id`) REFERENCES `cbt_tes` (`tes_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `cbt_tesgrup_ibfk_2` FOREIGN KEY (`tstgrp_grup_id`) REFERENCES `cbt_user_grup` (`grup_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_tes_soal`
--
ALTER TABLE `cbt_tes_soal`
  ADD CONSTRAINT `cbt_tes_soal_ibfk_1` FOREIGN KEY (`tessoal_tesuser_id`) REFERENCES `cbt_tes_user` (`tesuser_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `cbt_tes_soal_ibfk_2` FOREIGN KEY (`tessoal_soal_id`) REFERENCES `cbt_soal` (`soal_id`) ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_tes_soal_jawaban`
--
ALTER TABLE `cbt_tes_soal_jawaban`
  ADD CONSTRAINT `cbt_tes_soal_jawaban_ibfk_1` FOREIGN KEY (`soaljawaban_tessoal_id`) REFERENCES `cbt_tes_soal` (`tessoal_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `cbt_tes_soal_jawaban_ibfk_2` FOREIGN KEY (`soaljawaban_jawaban_id`) REFERENCES `cbt_jawaban` (`jawaban_id`) ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_tes_token`
--
ALTER TABLE `cbt_tes_token`
  ADD CONSTRAINT `cbt_tes_token_ibfk_1` FOREIGN KEY (`token_user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cbt_tes_topik_set`
--
ALTER TABLE `cbt_tes_topik_set`
  ADD CONSTRAINT `cbt_tes_topik_set_ibfk_1` FOREIGN KEY (`tset_tes_id`) REFERENCES `cbt_tes` (`tes_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `cbt_tes_topik_set_ibfk_2` FOREIGN KEY (`tset_topik_id`) REFERENCES `cbt_topik` (`topik_id`) ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_tes_user`
--
ALTER TABLE `cbt_tes_user`
  ADD CONSTRAINT `cbt_tes_user_ibfk_1` FOREIGN KEY (`tesuser_tes_id`) REFERENCES `cbt_tes` (`tes_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cbt_tes_user_ibfk_2` FOREIGN KEY (`tesuser_user_id`) REFERENCES `cbt_user` (`user_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_topik`
--
ALTER TABLE `cbt_topik`
  ADD CONSTRAINT `cbt_topik_ibfk_1` FOREIGN KEY (`topik_modul_id`) REFERENCES `cbt_modul` (`modul_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `cbt_user`
--
ALTER TABLE `cbt_user`
  ADD CONSTRAINT `cbt_user_ibfk_1` FOREIGN KEY (`user_grup_id`) REFERENCES `cbt_user_grup` (`grup_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`level`) REFERENCES `user_level` (`level`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_akses`
--
ALTER TABLE `user_akses`
  ADD CONSTRAINT `user_akses_ibfk_2` FOREIGN KEY (`kode_menu`) REFERENCES `user_menu` (`kode_menu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_akses_ibfk_3` FOREIGN KEY (`level`) REFERENCES `user_level` (`level`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
