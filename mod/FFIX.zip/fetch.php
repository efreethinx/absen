<?php 
	$inp = file_get_contents('https://presensi.skensala.tech/neural');
	$tempArray = json_decode($inp);
	$jsonData = json_encode($tempArray);
	echo $jsonData;
 ?>
